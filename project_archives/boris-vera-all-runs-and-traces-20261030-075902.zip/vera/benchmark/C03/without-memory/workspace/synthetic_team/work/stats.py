import math
def wilson(k, n, z=1.96):
    if n == 0: return None
    p = k/n
    d = 1 + z*z/n
    c = p + z*z/(2*n)
    hw = z*math.sqrt(p*(1-p)/n + z*z/(4*n*n))
    return ((c-hw)/d*100, (c+hw)/d*100)

for rule, k, n in [('R17',2,3), ('R42',1,3)]:
    lo, hi = wilson(k,n)
    print(f'{rule}: precision {k}/{n} = {k/n*100:.1f}%  95% Wilson: [{lo:.1f}%; {hi:.1f}%]')

print()
# coverage CI
for rule, k, n in [('R17',4,7), ('R42',3,7)]:
    lo, hi = wilson(k,n)
    print(f'{rule}: coverage {k}/{n} = {k/n*100:.1f}%  95% Wilson: [{lo:.1f}%; {hi:.1f}%]')

print()
# difference in precision: 2/3 vs 1/3, 1 TP difference out of 3
print('Разница precision R17-R42 = 1 TP на знаменателе 3 с каждой стороны.')
print('Fisher exact two-sided for 2/3 vs 1/3:')
from math import comb
def fisher(a,b,c,d):
    row1, col1, n = a+b, a+c, a+b+c+d
    def p(x):
        return comb(col1,x)*comb(n-col1, row1-x)/comb(n,row1)
    obs = p(a); tot=0
    for x in range(max(0,row1-(n-col1)), min(row1,col1)+1):
        px=p(x)
        if px <= obs + 1e-12: tot += px
    return tot
print('  p =', round(fisher(2,1,1,2),4))

print()
# What happens if A006 label becomes known? R17 precision possible range: 2/4..3/4
print('R17 при раскрытии A006: precision в диапазоне 2/4=50.0% .. 3/4=75.0%')
print('R17 при раскрытии A006 как fraud: 3/4=75.0%; как legit: 2/4=50.0%')
