import csv, os

BASE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'inputs')

for name in ['applications.csv','decision_events.csv','fraud_labels.csv','payments.csv','rule_hits.csv']:
    path = os.path.join(BASE, name)
    with open(path, newline='', encoding='utf-8-sig') as fh:
        rows = list(csv.reader(fh))
    print('===', name)
    for r in rows:
        print('   ', ' | '.join(r))
    print()
