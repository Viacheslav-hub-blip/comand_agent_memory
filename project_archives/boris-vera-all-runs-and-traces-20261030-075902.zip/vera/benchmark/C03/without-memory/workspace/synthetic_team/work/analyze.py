import csv, os, json
from datetime import datetime

BASE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'inputs')
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'outputs', 'C03')

def load(name):
    with open(os.path.join(BASE, name), newline='', encoding='utf-8-sig') as fh:
        return list(csv.DictReader(fh))

def ts(s):
    return datetime.strptime(s.strip(), '%Y-%m-%d %H:%M:%S')

T = ts('2026-10-05 00:00:00')
START = ts('2026-10-01 00:00:00')
END = ts('2026-10-03 00:00:00')  # 1-2 Oct inclusive, upper bound exclusive

apps = load('applications.csv')
labels = load('fraud_labels.csv')
hits = load('rule_hits.csv')

report = {}
lines = []
def p(s=''):
    lines.append(s)
    print(s)

# ---- 1. cohort
cohort = [a for a in apps if a['is_test'] == '0' and START <= ts(a['created_at']) < END]
cohort_ids = {a['application_id'] for a in cohort}
excluded_test = [a['application_id'] for a in apps if a['is_test'] != '0']
out_of_window = [a['application_id'] for a in apps
                 if a['is_test'] == '0' and not (START <= ts(a['created_at']) < END)]

p('=== 1. КОГОРТА')
p(f'Всего строк applications: {len(apps)}')
p(f'Исключено тестовых (is_test=1): {len(excluded_test)} -> {excluded_test}')
p(f'Исключено вне окна создания 1-2 окт: {len(out_of_window)} -> {out_of_window}')
p(f'Когорта (is_test=0, created_at 2026-10-01..2026-10-02): N={len(cohort)}')
for a in cohort:
    p(f"  {a['application_id']}  created={a['created_at']}  channel={a['channel']}  amount={a['requested_amount_rub']}")

# ---- 2. label snapshot at T
by_app = {}
for l in labels:
    by_app.setdefault(l['application_id'], []).append(l)

dups = {a: len(v) for a, v in by_app.items() if len(v) > 1}
same_time = []
for a, v in by_app.items():
    times = [l['recorded_at'] for l in v]
    if len(times) != len(set(times)):
        same_time.append(a)

label_at_T = {}
for a, v in by_app.items():
    known = [l for l in v if ts(l['recorded_at']) < T]
    if not known:
        label_at_T[a] = None
    else:
        last = sorted(known, key=lambda l: (ts(l['recorded_at']), int(l['label_id'][1:])), reverse=True)[0]
        label_at_T[a] = last

p()
p('=== 2. МЕТКИ НА 2026-10-05 00:00:00 UTC')
p(f"Заявок с >1 исторической строкой метки: {len(dups)} -> {dups}")
p(f'Заявок с одинаковым recorded_at: {len(same_time)} -> {same_time}')
p(f"Строк меток, отброшенных как будущие (recorded_at >= T): "
  f"{sum(1 for l in labels if ts(l['recorded_at']) >= T)}")
for l in labels:
    if ts(l['recorded_at']) >= T:
        p(f"  отброшено: {l['label_id']} {l['application_id']} {l['label']} {l['recorded_at']} ({l['reason']})")

labelled, unknown = [], []
for a in cohort:
    lid = a['application_id']
    row = label_at_T.get(lid)
    if row is None:
        unknown.append(lid)
    else:
        labelled.append((lid, row['label'], row['recorded_at']))

p(f'Размечено на T: {len(labelled)} из {len(cohort)}  ({len(labelled)/len(cohort)*100:.1f}%)')
p(f'Неизвестно на T: {len(unknown)}  ({len(unknown)/len(cohort)*100:.1f}%) -> {unknown}')
for lid, lab, rec in labelled:
    p(f'  {lid}: {lab} (recorded_at={rec})')

confirmed = [lid for lid, lab, _ in labelled if lab == 'confirmed_fraud']
legit = [lid for lid, lab, _ in labelled if lab == 'legitimate']
p(f'confirmed_fraud среди размеченных: {len(confirmed)} -> {confirmed}')
p(f'legitimate среди размеченных: {len(legit)} -> {legit}')
p(f'Доля confirmed_fraud среди размеченных: {len(confirmed)/len(labelled)*100:.1f}%')

report['cohort'] = {'N': len(cohort), 'ids': sorted(cohort_ids),
                    'labelled': len(labelled), 'unknown': len(unknown),
                    'unknown_ids': sorted(unknown),
                    'confirmed_fraud': len(confirmed), 'legitimate': len(legit)}

# ---- 3. rule hits suitability
p()
p('=== 3. ПРОВЕРКА rule_hits')
pairs = [(h['rule_id'], h['application_id']) for h in hits]
dupe_pairs = {x for x in pairs if pairs.count(x) > 1}
p(f'Строк rule_hits: {len(hits)}; уникальных пар (rule_id, application_id): {len(set(pairs))}; дубликаты пар: {sorted(dupe_pairs)}')
rules = sorted({h['rule_id'] for h in hits})
p(f'Правила в файле: {rules}')
hits_outside = [h for h in hits if h['application_id'] not in cohort_ids]
p(f'Срабатываний на заявках вне когорты (тест/вне окна): {len(hits_outside)} -> {[(h["rule_id"], h["application_id"]) for h in hits_outside]}')
hits_after_T = [h for h in hits if ts(h['hit_at']) >= T]
p(f'Срабатываний с hit_at >= T: {len(hits_after_T)}')
# hit against application creation and existence
app_by_id = {a['application_id']: a for a in apps}
hits_before_creation = [h for h in hits if h['application_id'] in app_by_id and ts(h['hit_at']) < ts(app_by_id[h['application_id']]['created_at'])]
p(f'Срабатываний раньше создания заявки: {len(hits_before_creation)} -> {[(h["rule_id"], h["application_id"], h["hit_at"]) for h in hits_before_creation]}')
orphan_hits = [h for h in hits if h['application_id'] not in app_by_id]
p(f'Срабатываний на несуществующих заявках: {len(orphan_hits)}')

report['rule_hits_check'] = {'rows': len(hits), 'unique_pairs': len(set(pairs)),
                             'dupe_pairs': sorted(dupe_pairs), 'rules': rules,
                             'outside_cohort': len(hits_outside), 'after_T': len(hits_after_T),
                             'before_creation': len(hits_before_creation), 'orphans': len(orphan_hits)}

# ---- 4. per-rule metrics
p()
p('=== 4. МЕТРИКИ ПРАВИЛ НА КОГОРТЕ (срез меток на T)')
N = len(cohort)
metric = {}
for rule in rules:
    apps_hit = {h['application_id'] for h in hits if h['rule_id'] == rule and h['application_id'] in cohort_ids}
    TP = sorted(x for x in apps_hit if label_at_T.get(x) and label_at_T[x]['label'] == 'confirmed_fraud')
    FP = sorted(x for x in apps_hit if label_at_T.get(x) and label_at_T[x]['label'] == 'legitimate')
    UNK = sorted(x for x in apps_hit if label_at_T.get(x) is None)
    denom = len(TP) + len(FP)
    precision = (len(TP)/denom) if denom else None
    recall = len(TP)/len(confirmed) if confirmed else None
    coverage = len(apps_hit)/N
    metric[rule] = {'hit_apps': sorted(apps_hit), 'n_hit': len(apps_hit),
                    'TP': TP, 'FP': FP, 'unknown': UNK,
                    'precision': precision, 'recall': recall, 'coverage': coverage}
    p(f'-- {rule}')
    p(f'   уникальных заявок со срабатыванием: {len(apps_hit)} ({sorted(apps_hit)})')
    p(f'   TP={len(TP)} {TP} | FP={len(FP)} {FP} | unknown={len(UNK)} {UNK}')
    p(f'   precision = {len(TP)}/{denom} = ' + (f'{precision*100:.1f}%' if precision is not None else 'не определено'))
    p(f'   recall (на размеченной части) = {len(TP)}/{len(confirmed)} = ' + (f'{recall*100:.1f}%' if recall is not None else 'не определено'))
    p(f'   coverage = {len(apps_hit)}/{N} = {coverage*100:.1f}%')

report['rules'] = metric

# overlap
p()
p('=== 5. ПЕРЕСЕЧЕНИЯ')
r17 = {h['application_id'] for h in hits if h['rule_id'] == 'R17' and h['application_id'] in cohort_ids}
r42 = {h['application_id'] for h in hits if h['rule_id'] == 'R42' and h['application_id'] in cohort_ids}
p(f'R17 ∩ R42: {sorted(r17 & r42)} (размер {len(r17 & r42)})')
p(f'R17 ∪ R42: {sorted(r17 | r42)} (размер {len(r17 | r42)} из {N})')
p(f'Ни одно правило не сработало: {sorted(cohort_ids - (r17 | r42))}')
report['overlap'] = {'intersection': sorted(r17 & r42), 'union': sorted(r17 | r42),
                     'uncovered': sorted(cohort_ids - (r17 | r42)), 'jaccard': len(r17 & r42)/len(r17 | r42)}

# ---- 6. sensitivity: future correction L007
p()
p('=== 6. ЧУВСТВИТЕЛЬНОСТЬ: поздняя правка A001 (L007, 2026-10-06, legitimate)')
alt = dict(label_at_T)
alt['A001'] = next(l for l in labels if l['label_id'] == 'L007')
for rule in ['R17', 'R42']:
    apps_hit = {h['application_id'] for h in hits if h['rule_id'] == rule and h['application_id'] in cohort_ids}
    TP = [x for x in apps_hit if alt.get(x) and alt[x]['label'] == 'confirmed_fraud']
    FP = [x for x in apps_hit if alt.get(x) and alt[x]['label'] == 'legitimate']
    d = len(TP)+len(FP)
    p(f'   {rule}: precision={len(TP)}/{d}=' + (f'{len(TP)/d*100:.1f}%' if d else 'н/д') +
      f', recall={len(TP)}/2=' + (f'{len(TP)/2*100:.1f}%' if True else ''))
report['sensitivity_after_correction'] = {'note': 'если бы правка A001 от 2026-10-06 была доступна'}

os.makedirs(OUT, exist_ok=True)
with open(os.path.join(OUT, 'analysis.txt'), 'w', encoding='utf-8') as fh:
    fh.write('\n'.join(lines))
with open(os.path.join(OUT, 'report.json'), 'w', encoding='utf-8') as fh:
    json.dump(report, fh, ensure_ascii=False, indent=2)
