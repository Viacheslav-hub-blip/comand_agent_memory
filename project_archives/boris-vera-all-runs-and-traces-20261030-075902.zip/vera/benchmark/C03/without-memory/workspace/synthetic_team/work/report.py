import csv, os, json, math
from datetime import datetime

BASE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'inputs')
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'outputs', 'C03')
os.makedirs(OUT, exist_ok=True)

def load(n):
    with open(os.path.join(BASE, n), newline='', encoding='utf-8-sig') as f:
        return list(csv.DictReader(f))

def ts(s): return datetime.strptime(s.strip(), '%Y-%m-%d %H:%M:%S')

def wilson(k, n, z=1.96):
    if n == 0: return None
    p = k/n; d = 1+z*z/n; c = p+z*z/(2*n)
    hw = z*math.sqrt(p*(1-p)/n + z*z/(4*n*n))
    return (max(0.0,(c-hw)/d), min(1.0,(c+hw)/d))

apps, labels, hits = load('applications.csv'), load('fraud_labels.csv'), load('rule_hits.csv')
T = ts('2026-10-05 00:00:00'); S = ts('2026-10-01 00:00:00'); E = ts('2026-10-03 00:00:00')

cohort = [a for a in apps if a['is_test'] == '0' and S <= ts(a['created_at']) < E]
cids = {a['application_id'] for a in cohort}
N = len(cohort)

lab = {}
for l in labels:
    prev = lab.get(l['application_id'])
    if ts(l['recorded_at']) >= T: continue
    if prev is None or (ts(l['recorded_at']), int(l['label_id'][1:])) > (ts(prev['recorded_at']), int(prev['label_id'][1:])):
        lab[l['application_id']] = l

labelled = [a['application_id'] for a in cohort if a['application_id'] in lab]
unknown = [a['application_id'] for a in cohort if a['application_id'] not in lab]
fraud = [x for x in labelled if lab[x]['label'] == 'confirmed_fraud']
legit = [x for x in labelled if lab[x]['label'] == 'legitimate']

rules = {}
for rule in ['R17', 'R42']:
    h = {x['application_id'] for x in hits if x['rule_id'] == rule and x['application_id'] in cids}
    TP = sorted(x for x in h if x in lab and lab[x]['label'] == 'confirmed_fraud')
    FP = sorted(x for x in h if x in lab and lab[x]['label'] == 'legitimate')
    UN = sorted(x for x in h if x not in lab)
    den = len(TP)+len(FP)
    rules[rule] = dict(hit=sorted(h), TP=TP, FP=FP, UNK=UN, den=den,
                       prec=(len(TP)/den if den else None),
                       prec_ci=(wilson(len(TP), den) if den else None),
                       rec=(len(TP)/len(fraud) if fraud else None),
                       cov=len(h)/N, cov_ci=wilson(len(h), N))

r17 = set(rules['R17']['hit']); r42 = set(rules['R42']['hit'])

def pct(x): return f'{x*100:.1f}%'

L = []
def w(s=''): L.append(s)

w('# R17 vs R42 — заявки, зарегистрированные 2026-10-01..2026-10-02 (UTC)')
w('Метки: срез знания на 2026-10-05 00:00:00 UTC. Реальные (is_test=0) заявки.')
w()
w('## 0. Окружение')
w('Polars не установлен ни в одном доступном интерпретаторе; пакеты не ставились.')
w('Расчёт выполнен стандартной библиотекой Python 3.10 (csv/datetime/math).')
w('Скрипты: /synthetic_team/work/analyze.py, /synthetic_team/work/stats.py')
w()
w('## 1. Пригодность данных')
w()
w(f'Когорта: {N} реальных заявок (A004 исключена: is_test=1; вне окна создания нет).')
w(f'Заявки когорты: {", ".join(sorted(cids))}')
w()
w(f'Разметка на 2026-10-05 00:00:00: размечено {len(labelled)} из {N} ({pct(len(labelled)/N)}), '
  f'неизвестно {len(unknown)} из {N} ({pct(len(unknown)/N)}) → {", ".join(unknown) or "нет"}.')
w(f'  • confirmed_fraud: {len(fraud)} ({pct(len(fraud)/len(labelled))} от размеченных) → {", ".join(fraud)}')
w(f'  • legitimate: {len(legit)} ({pct(len(legit)/len(labelled))} от размеченных) → {", ".join(legit)}')
w()
w('История меток: у A001 две версии. На срез T действует L001 (confirmed_fraud, 2026-10-03). '
  'L007 (legitimate, 2026-10-06, investigation_corrected) — из будущего и в срез не входит; '
  'если бы её применили, картина изменилась бы (см. §5).')
w('Одинаковых recorded_at у одной заявки нет — правило tie-break label_id DESC не потребовалось.')
w()
w('rule_hits: 7 строк, 7 уникальных пар (rule_id, application_id), дубликатов нет. '
  'Правила только R17 и R42; посторонних правил нет.')
w('  • срабатываний на заявках вне когорты (тест/вне окна): 0')
w('  • срабатываний с hit_at >= T (будущих): 0')
w('  • срабатываний раньше created_at заявки: 0')
w('  • срабатываний на несуществующих application_id: 0')
w()
w('Вывод по пригодности: данные согласованы и пригодны для сравнения правил на этой когорте. '
  'Ограничения: объём 7 заявок, 3 подтверждённых фрода, у одного правила 1 неизвестная заявка — '
  'интервалы оценок широкие, статистическая разница между правилами не устанавливается.')
w()
w('## 2. Итоговая таблица')
w()
w('| Правило | Срабатываний (уник. заявок) | Coverage | TP | FP | Unknown | Размеченных срабатываний | Precision | Recall* | 95% ДИ precision |')
w('|---|---|---|---|---|---|---|---|---|---|')
for r in ['R17', 'R42']:
    m = rules[r]
    ci = f'[{pct(m["prec_ci"][0])}; {pct(m["prec_ci"][1])}]' if m['prec_ci'] else 'не опр.'
    pr = f'{len(m["TP"])}/{m["den"]} = {pct(m["prec"])}' if m['prec'] is not None else 'не определено (0/0)'
    rc = f'{len(m["TP"])}/{len(fraud)} = {pct(m["rec"])}' if m['rec'] is not None else 'не определено'
    w(f'| {r} | {len(m["hit"])} из {N} | {pct(m["cov"])} | {len(m["TP"])} ({", ".join(m["TP"]) or "—"}) | '
      f'{len(m["FP"])} ({", ".join(m["FP"]) or "—"}) | {len(m["UNK"])} ({", ".join(m["UNK"]) or "—"}) | '
      f'{m["den"]} | {pr} | {rc} | {ci} |')
w()
w('\\* Recall — на размеченной части когорты (знаменатель 3 подтверждённых фрода), не оценка полноты по всей популяции.')
w()
w('Coverage 95% ДИ: R17 [25.0%; 84.2%], R42 [15.8%; 75.0%].')
w()
w('## 3. Пояснения по каждой заявке')
w()
w('| Заявка | Метка на T | R17 | R42 |')
w('|---|---|---|---|')
for a in sorted(cids):
    l = lab.get(a)
    lbl = f"{l['label']} ({l['recorded_at']})" if l else 'неизвестно'
    w(f'| {a} | {lbl} | {"hit" if a in r17 else "—"} | {"hit" if a in r42 else "—"} |')
w()
w('## 4. Пересечения и покрытие когорты')
w()
w(f'R17 ∩ R42: {len(r17 & r42)} заявок ({", ".join(sorted(r17 & r42)) or "нет"}) — правила не пересекаются.')
w(f'R17 ∪ R42: {len(r17 | r42)} из {N} ({pct(len(r17|r42)/N)}).')
w(f'Не покрыто ни одним правилом: {len(cids - (r17|r42))} ({", ".join(sorted(cids-(r17|r42))) or "нет"}).')
w()
w('Правила не пересекаются и вместе покрывают всю когорту (7 из 7). '
  'По каналам: R17 сработал на A001, A002, A006 (web) и A005 (partner); '
  'R42 — на A003, A007 (partner) и A008 (web). Жёсткой привязки правила к каналу нет, '
  'но партнёрский канал почти полностью (2 из 3) уходит в R42.')
w()
w('## 5. Чувствительность и интерпретация')
w()
w('1. Неизвестная A006 входит только в R17. Её раскрытие сдвигает precision R17 в диапазон '
  '2/4 = 50.0% (если legitimate) … 3/4 = 75.0% (если confirmed_fraud). Итоговый рейтинг R17 > R42 этим не переворачивается, '
  'но точное значение precision R17 пока не финально.')
w('2. Если бы (ошибочно) применили будущую правку L007 (A001 → legitimate, 2026-10-06), '
  'precision R17 упала бы до 1/3 = 33.3% и совпала бы с R42. Это показывает, насколько вывод зависит от корректного среза знания.')
w('3. Разница precision R17 (2/3 = 66.7%) vs R42 (1/3 = 33.3%) — это разница в 1 TP при знаменателе 3. '
  'Точный критерий Фишера (2/3 vs 1/3): p = 1.0. Статистически правила не различимы.')
w('4. Каждая оценка опирается на 3 размеченных срабатывания; доверительные интервалы пересекаются почти полностью.')
w('5. Нет утверждённого SLA разметки и порогов достаточности выборки (pipeline_notes.md); '
  'обе заметки про D+3 и D+5 — наблюдения/черновики, не SLA. На 2026-10-05 неразмеченной осталась 1 заявка (14.3%), '
  'и её исход может дозаписаться позже.')
w()
w('Практический вывод: на этом снимке R17 выглядит точнее R42 (2/3 против 1/3 подтверждённых фрода среди размеченных), '
  'при сопоставимом покрытии (57.1% против 42.9%) и отсутствии пересечений. Но абсолютные числа малы '
  '(2 и 1 TP), разница статистически не значима, а 1 заявка R17 ещё не размечена — '
  'данные не обосновывают вывод о превосходстве одного правила над другим и тем более внедрение в производство.')
w()
w('ВНИМАНИЕ про decision_events: для метрик правил решения не используются. '
  'Статусы решений (approved/rejected/cancelled) — не метки мошенничества и не должны подменять fraud_labels. '
  'Заявки A002 (cancelled) и A007 (approved, затем rejected) имеют подтверждённые метки legitimate/fraud независимо от статуса.')

text = '\n'.join(L)
with open(os.path.join(OUT, 'summary.md'), 'w', encoding='utf-8') as f:
    f.write(text)
print(text)
