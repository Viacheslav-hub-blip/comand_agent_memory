#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Воспроизводимый расчёт сравнения правил R17 и R42.

Сценарий C03.
  Когорта : заявки is_test=0, created_at в [2026-10-01 00:00:00, 2026-10-03 00:00:00) UTC
  Знание  : T = 2026-10-05 00:00:00 UTC
  Метки   : последняя версия fraud_labels с recorded_at < T
            (при равном recorded_at — label_id DESC; в этом снимке таких случаев нет).
            Строки с recorded_at >= T не используются.

Требования: только стандартная библиотека Python 3 (csv, datetime, math, os, json).
Внешние пакеты (polars/pandas) не нужны и не устанавливаются.

Запуск:
    python3 compute.py            # пишет файлы рядом с собой
    python3 compute.py --print    # плюс печатает таблицу в stdout

Входные данные: ../../inputs/*.csv (относительно этого файла), т.е. /synthetic_team/inputs/
Выходные данные: файлы в каталоге, где лежит сам скрипт (/synthetic_team/outputs/C03/):
    metrics_table.csv      — итоговая таблица R17 vs R42
    labels_snapshot.csv    — метки, действующие на T, по каждой заявке когорты
    hits_evaluation.csv    — каждое срабатывание правила с его классом TP/FP/unknown
    cohort_check.txt       — журнал проверок пригодности данных
    summary.md             — читаемый отчёт (перезаписывается)
"""
import csv
import json
import math
import os
import sys
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
INPUTS = os.path.normpath(os.path.join(HERE, '..', '..', 'inputs'))

T = datetime(2026, 10, 5, 0, 0, 0)          # дата знания (не включается)
COHORT_START = datetime(2026, 10, 1, 0, 0, 0)
COHORT_END = datetime(2026, 10, 3, 0, 0, 0)  # не включается
RULES = ['R17', 'R42']
FMT = '%Y-%m-%d %H:%M:%S'


def ts(s):
    return datetime.strptime(str(s).strip(), FMT)


def load(name):
    with open(os.path.join(INPUTS, name), newline='', encoding='utf-8-sig') as fh:
        return list(csv.DictReader(fh))


def wilson(k, n, z=1.96):
    """95% интервал Уилсона; (lo, hi) в долях или None при n == 0."""
    if n == 0:
        return None
    p = k / n
    d = 1 + z * z / n
    c = p + z * z / (2 * n)
    hw = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return (max(0.0, (c - hw) / d), min(1.0, (c + hw) / d))


def pct(x):
    return '—' if x is None else '%.1f%%' % (x * 100)


def main():
    log = []
    apps = load('applications.csv')
    labels = load('fraud_labels.csv')
    hits = load('rule_hits.csv')

    # ---------- 1. Когорта ----------
    cohort = [a for a in apps
              if a['is_test'].strip() == '0'
              and COHORT_START <= ts(a['created_at']) < COHORT_END]
    cohort.sort(key=lambda a: a['application_id'])
    cids = [a['application_id'] for a in cohort]
    N = len(cohort)
    dropped_test = [a['application_id'] for a in apps if a['is_test'].strip() != '0']
    dropped_window = [a['application_id'] for a in apps
                      if a['is_test'].strip() == '0'
                      and not (COHORT_START <= ts(a['created_at']) < COHORT_END)]

    log.append('=== 1. КОГОРТА')
    log.append('Строк applications: %d' % len(apps))
    log.append('Исключено is_test!=0: %d %s' % (len(dropped_test), dropped_test))
    log.append('Исключено вне окна создания 2026-10-01..2026-10-02: %d %s'
               % (len(dropped_window), dropped_window))
    log.append('Когорта N = %d: %s' % (N, ', '.join(cids)))

    # ---------- 2. Метки на T (последняя версия, известная к T) ----------
    log.append('')
    log.append('=== 2. МЕТКИ НА %s UTC' % T.strftime(FMT))
    versions = {}
    future_dropped = []
    for l in labels:
        if l['application_id'] not in set(cids):
            continue
        versions.setdefault(l['application_id'], []).append(l)
    if any(len(v) > 1 for v in versions.values()):
        log.append('Заявок с несколькими версиями метки: %s'
                   % {k: len(v) for k, v in versions.items() if len(v) > 1})

    label_at_t = {}
    for aid, rows in versions.items():
        known = [r for r in rows if ts(r['recorded_at']) < T]
        for r in rows:
            if ts(r['recorded_at']) >= T:
                future_dropped.append((r['label_id'], aid, r['label'], r['recorded_at']))
        if not known:
            continue
        # последняя известная версия: recorded_at DESC, затем label_id DESC
        known.sort(key=lambda r: (ts(r['recorded_at']), int(r['label_id'][1:])), reverse=True)
        label_at_t[aid] = known[0]
    for item in future_dropped:
        log.append('Отброшено (recorded_at >= T): %s %s %s %s' % item)

    labelled = [a for a in cids if a in label_at_t]
    unknown = [a for a in cids if a not in label_at_t]
    fraud = [a for a in labelled if label_at_t[a]['label'] == 'confirmed_fraud']
    legit = [a for a in labelled if label_at_t[a]['label'] == 'legitimate']

    log.append('Размечено: %d из %d (%s)' % (len(labelled), N, pct(len(labelled) / N)))
    log.append('Неизвестно: %d из %d (%s) -> %s'
               % (len(unknown), N, pct(len(unknown) / N), unknown))
    log.append('confirmed_fraud: %d (%s от размеченных) -> %s'
               % (len(fraud), pct(len(fraud) / len(labelled)), fraud))
    log.append('legitimate: %d (%s от размеченных) -> %s'
               % (len(legit), pct(len(legit) / len(labelled)), legit))
    for aid in cids:
        if aid in label_at_t:
            l = label_at_t[aid]
            log.append('  %s: %s (recorded_at=%s, label_id=%s)'
                       % (aid, l['label'], l['recorded_at'], l['label_id']))

    # ---------- 3. Проверки rule_hits ----------
    log.append('')
    log.append('=== 3. ПРОВЕРКИ rule_hits')
    pairs = [(h['rule_id'], h['application_id']) for h in hits]
    dupes = sorted({p for p in pairs if pairs.count(p) > 1})
    rules_in_file = sorted({h['rule_id'] for h in hits})
    outside = [h['application_id'] for h in hits if h['application_id'] not in set(cids)]
    future_hits = [h['application_id'] for h in hits if ts(h['hit_at']) >= T]
    before_created = []
    created = {a['application_id']: ts(a['created_at']) for a in apps}
    for h in hits:
        if h['application_id'] in created and ts(h['hit_at']) < created[h['application_id']]:
            before_created.append((h['rule_id'], h['application_id'], h['hit_at']))
    dangling = [h['application_id'] for h in hits
                if h['application_id'] not in created]
    log.append('Строк: %d; уникальных пар: %d; дубликатов пар: %s'
               % (len(hits), len(set(pairs)), dupes or 'нет'))
    log.append('Правила в файле: %s' % rules_in_file)
    log.append('Срабатываний вне когорты: %d %s' % (len(outside), outside or ''))
    log.append('Срабатываний с hit_at >= T: %d %s' % (len(future_hits), future_hits or ''))
    log.append('Срабатываний раньше created_at: %d %s' % (len(before_created), before_created or ''))
    log.append('Срабатываний на несуществующих заявках: %d %s' % (len(dangling), dangling or ''))
    checks_ok = not (dupes or outside or future_hits or before_created or dangling)

    # ---------- 4. Метрики правил ----------
    metrics = []
    hits_rows = []
    for rule in RULES:
        h = sorted({x['application_id'] for x in hits if x['rule_id'] == rule})
        TP = [x for x in h if x in label_at_t and label_at_t[x]['label'] == 'confirmed_fraud']
        FP = [x for x in h if x in label_at_t and label_at_t[x]['label'] == 'legitimate']
        UN = [x for x in h if x not in label_at_t]
        den = len(TP) + len(FP)
        for x in h:
            cls = ('TP' if x in TP else 'FP' if x in FP else 'unknown')
            hits_rows.append({'rule_id': rule, 'application_id': x,
                              'label_at_t': label_at_t[x]['label'] if x in label_at_t else 'unknown',
                              'class': cls})
        metrics.append({
            'rule_id': rule,
            'hits_unique': len(h),
            'hit_ids': h,
            'coverage': len(h) / N if N else None,
            'coverage_ci': wilson(len(h), N),
            'tp': len(TP), 'tp_ids': TP,
            'fp': len(FP), 'fp_ids': FP,
            'unknown': len(UN), 'unknown_ids': UN,
            'denominator': den,
            'precision': (len(TP) / den) if den else None,
            'precision_ci': wilson(len(TP), den) if den else None,
            'recall_labelled': (len(TP) / len(fraud)) if fraud else None,
        })

    log.append('')
    log.append('=== 4. МЕТРИКИ ПРАВИЛ (метки на T)')
    for m in metrics:
        log.append('-- %s' % m['rule_id'])
        log.append('   срабатываний: %d из %d = %s, ДИ [%s; %s]'
                   % (m['hits_unique'], N, pct(m['coverage']),
                      pct(m['coverage_ci'][0]), pct(m['coverage_ci'][1])))
        log.append('   TP=%d %s | FP=%d %s | unknown=%d %s'
                   % (m['tp'], m['tp_ids'], m['fp'], m['fp_ids'],
                      m['unknown'], m['unknown_ids']))
        log.append('   precision = %d/%d = %s%s'
                   % (m['tp'], m['denominator'], pct(m['precision']),
                      '' if not m['precision_ci'] else
                      ', ДИ [%s; %s]' % (pct(m['precision_ci'][0]), pct(m['precision_ci'][1]))))
        log.append('   recall (на размеченной части) = %d/%d = %s'
                   % (m['tp'], len(fraud), pct(m['recall_labelled'])))

    # ---------- 5. Запись файлов ----------
    with open(os.path.join(HERE, 'metrics_table.csv'), 'w', newline='', encoding='utf-8') as fh:
        w = csv.writer(fh)
        w.writerow(['rule_id', 'hits_unique', 'cohort_size', 'coverage',
                    'tp', 'tp_ids', 'fp', 'fp_ids', 'unknown', 'unknown_ids',
                    'labelled_hits', 'precision', 'precision_ci_low', 'precision_ci_high',
                    'recall_on_labelled', 'coverage_ci_low', 'coverage_ci_high'])
        for m in metrics:
            w.writerow([m['rule_id'], m['hits_unique'], N, round(m['coverage'], 4),
                        m['tp'], ';'.join(m['tp_ids']),
                        m['fp'], ';'.join(m['fp_ids']),
                        m['unknown'], ';'.join(m['unknown_ids']),
                        m['denominator'],
                        '' if m['precision'] is None else round(m['precision'], 4),
                        '' if not m['precision_ci'] else round(m['precision_ci'][0], 4),
                        '' if not m['precision_ci'] else round(m['precision_ci'][1], 4),
                        '' if m['recall_labelled'] is None else round(m['recall_labelled'], 4),
                        round(m['coverage_ci'][0], 4), round(m['coverage_ci'][1], 4)])

    with open(os.path.join(HERE, 'labels_snapshot.csv'), 'w', newline='', encoding='utf-8') as fh:
        w = csv.writer(fh)
        w.writerow(['application_id', 'label_at_T', 'label_id', 'recorded_at', 'source'])
        for aid in cids:
            if aid in label_at_t:
                l = label_at_t[aid]
                w.writerow([aid, l['label'], l['label_id'], l['recorded_at'], 'fraud_labels'])
            else:
                w.writerow([aid, 'unknown', '', '', 'нет записи с recorded_at < T'])

    with open(os.path.join(HERE, 'hits_evaluation.csv'), 'w', newline='', encoding='utf-8') as fh:
        w = csv.writer(fh)
        w.writerow(['rule_id', 'application_id', 'label_at_T', 'class'])
        for r in hits_rows:
            w.writerow([r['rule_id'], r['application_id'], r['label_at_t'], r['class']])

    with open(os.path.join(HERE, 'cohort_check.txt'), 'w', encoding='utf-8') as fh:
        fh.write('\n'.join(log) + '\n')

    meta = {
        'scenario': 'C03',
        'cohort': {'rule': 'is_test=0 AND 2026-10-01 00:00:00 <= created_at < 2026-10-03 00:00:00',
                   'N': N, 'ids': cids},
        'knowledge_at': T.strftime(FMT),
        'label_rule': 'последняя fraud_labels с recorded_at < T, tie-break label_id DESC',
        'future_label_rows_dropped': [{'label_id': a, 'application_id': b,
                                       'label': c, 'recorded_at': d}
                                      for a, b, c, d in future_dropped],
        'labelled': {'count': len(labelled), 'share': round(len(labelled) / N, 4)},
        'unknown': {'count': len(unknown), 'share': round(len(unknown) / N, 4), 'ids': unknown},
        'confirmed_fraud': {'count': len(fraud), 'ids': fraud},
        'legitimate': {'count': len(legit), 'ids': legit},
        'data_checks_passed': checks_ok,
        'metrics': metrics,
        'environment': 'python stdlib only; polars/pandas not used, nothing installed',
    }
    with open(os.path.join(HERE, 'report.json'), 'w', encoding='utf-8') as fh:
        json.dump(meta, fh, ensure_ascii=False, indent=2)

    # ---------- 6. summary.md ----------
    write_summary(N, cids, labelled, unknown, fraud, legit, label_at_t,
                  future_dropped, metrics, checks_ok, hits_rows)

    if '--print' in sys.argv:
        print(open(os.path.join(HERE, 'metrics_table.csv'), encoding='utf-8').read())
        print('\n'.join(log))


def write_summary(N, cids, labelled, unknown, fraud, legit, label_at_t,
                  future_dropped, metrics, checks_ok, hits_rows):
    m = {x['rule_id']: x for x in metrics}
    L = []
    add = L.append

    add('# C03 — R17 vs R42: сравнение на реальных заявках 2026-10-01..2026-10-02')
    add('')
    add('**Когорта:** заявки `is_test=0`, `created_at` в `[2026-10-01 00:00:00, 2026-10-03 00:00:00)` UTC. '
        '**Дата знания:** `2026-10-05 00:00:00` UTC. Все времена UTC.')
    add('')
    add('## Воспроизводимость')
    add('')
    add('- `compute.py` — весь расчёт, только стандартная библиотека Python 3 (`csv`, `datetime`, `math`, `json`). '
        'Polars/pandas не требуются; ничего не устанавливалось (в окружении Polars отсутствует).')
    add('- Вход: `../../inputs/applications.csv`, `fraud_labels.csv`, `rule_hits.csv`.')
    add('- Запуск: `python3 compute.py` (файлы перезаписываются в этом каталоге).')
    add('- Выходы: `metrics_table.csv` (итог), `labels_snapshot.csv` (метки на T), '
        '`hits_evaluation.csv` (класс каждого срабатывания TP/FP/unknown), '
        '`cohort_check.txt` (журнал проверок пригодности), `report.json` (машинный результат), `summary.md` (этот файл).')
    add('')
    add('## 1. Проверка пригодности данных')
    add('')
    add('| Проверка | Результат |')
    add('|---|---|')
    add('| Когорта после фильтров | %d заявок: %s |' % (N, ', '.join(cids)))
    add('| Тестовые заявки исключены | A004 (`is_test=1`) |')
    add('| Заявки вне окна создания | нет |')
    add('| Дубликаты пар (rule_id, application_id) | нет |')
    add('| Срабатывания на заявках вне когорты | 0 |')
    add('| Срабатывания с `hit_at >= T` (из будущего) | 0 |')
    add('| Срабатывания раньше `created_at` заявки | 0 |')
    add('| Срабатывания на несуществующих `application_id` | 0 |')
    add('| Итог | %s |' % ('данные согласованы, сравнение корректно'
                           if checks_ok else 'есть нарушения — результат требует проверки'))
    add('')
    add('## 2. Разметка на дату знания')
    add('')
    add('Правило метки: последняя версия `fraud_labels` с `recorded_at < 2026-10-05 00:00:00` '
        '(при равном времени — `label_id DESC`; таких случаев в снимке нет). '
        'Строки с `recorded_at >= T` не используются.')
    add('')
    add('| Показатель | Абсолютно | Доля от когорты (%) |')
    add('|---|---|---|')
    add('| Всего заявок в когорте | %d | 100.0%% |' % N)
    add('| **Размечено (известный исход)** | **%d** | **%.1f%%** |' % (len(labelled), 100.0 * len(labelled) / N))
    add('| — из них `confirmed_fraud` | %d (%.1f%% от размеченных) | %.1f%% |'
        % (len(fraud), 100.0 * len(fraud) / len(labelled), 100.0 * len(fraud) / N))
    add('| — из них `legitimate` | %d (%.1f%% от размеченных) | %.1f%% |'
        % (len(legit), 100.0 * len(legit) / len(labelled), 100.0 * len(legit) / N))
    add('| **Неизвестно** | **%d** | **%.1f%%** |' % (len(unknown), 100.0 * len(unknown) / N))
    add('')
    add('Метки по заявкам:')
    add('')
    add('| Заявка | Метка на T | recorded_at | label_id |')
    add('|---|---|---|---|')
    for aid in cids:
        if aid in label_at_t:
            l = label_at_t[aid]
            add('| %s | %s | %s | %s |' % (aid, l['label'], l['recorded_at'], l['label_id']))
        else:
            add('| %s | unknown | — | — |' % aid)
    add('')
    if future_dropped:
        add('Отброшено как будущее (не влияет на срез):')
        for lid, aid, lbl, rec in future_dropped:
            add('- %s: %s `%s` от %s — исключена, т.к. `recorded_at >= T`.' % (aid, lbl, lid, rec))
        add('')
        add('Примечание: если бы эту правку применили (что было бы неверно для даты знания), '
            'метка A001 сменилась бы и показатели R17 упали бы — см. §5.')
        add('')
    add('## 3. Итоговая таблица R17 vs R42')
    add('')
    add('| Правило | Срабатываний (уник. заявок) | Coverage | TP | FP | Unknown | Размеченных срабатываний | Precision | Recall* | 95% ДИ precision |')
    add('|---|---|---|---|---|---|---|---|---|---|')
    for rule in RULES:
        x = m[rule]
        ci = ('[%s; %s]' % (pct(x['precision_ci'][0]), pct(x['precision_ci'][1]))
              if x['precision_ci'] else 'не определено')
        pr = ('%d/%d = %s' % (x['tp'], x['denominator'], pct(x['precision']))
              if x['precision'] is not None else 'не определено (0/0)')
        rc = ('%d/%d = %s' % (x['tp'], len(fraud), pct(x['recall_labelled']))
              if x['recall_labelled'] is not None else 'не определено')
        add('| **%s** | %d из %d | %s | %d (%s) | %d (%s) | %d (%s) | %d | %s | %s | %s |'
            % (rule, x['hits_unique'], N, pct(x['coverage']),
               x['tp'], ', '.join(x['tp_ids']) or '—',
               x['fp'], ', '.join(x['fp_ids']) or '—',
               x['unknown'], ', '.join(x['unknown_ids']) or '—',
               x['denominator'], pr, rc, ci))
    add('')
    add('\\* Recall — на размеченной части когорты: TP / все `confirmed_fraud` среди заявок с известной меткой '
        '(знаменатель = %d). Это не оценка полноты по всей популяции.' % len(fraud))
    add('')
    add('Coverage 95%% ДИ: R17 [%s; %s], R42 [%s; %s].'
        % (pct(m['R17']['coverage_ci'][0]), pct(m['R17']['coverage_ci'][1]),
           pct(m['R42']['coverage_ci'][0]), pct(m['R42']['coverage_ci'][1])))
    add('')
    add('## 4. Классификация каждого срабатывания')
    add('')
    add('| Правило | Заявка | Метка на T | Класс |')
    add('|---|---|---|---|')
    for r in hits_rows:
        add('| %s | %s | %s | %s |' % (r['rule_id'], r['application_id'], r['label_at_t'], r['class']))
    add('')
    r17 = set(m['R17']['hit_ids'])
    r42 = set(m['R42']['hit_ids'])
    add('Пересечение R17 ∩ R42: %d заявок (%s).'
        % (len(r17 & r42), ', '.join(sorted(r17 & r42)) or 'нет'))
    add('Объединение R17 ∪ R42: %d из %d (%.1f%%).'
        % (len(r17 | r42), N, 100.0 * len(r17 | r42) / N))
    add('Не покрыто ни одним правилом: %d заявок (%s).'
        % (len(set(cids) - (r17 | r42)), ', '.join(sorted(set(cids) - (r17 | r42))) or 'нет'))
    add('')
    add('## 5. Ограничения и чувствительность')
    add('')
    a006 = [x for x in m['R17']['unknown_ids']]
    if a006:
        add('1. Неизвестная заявка %s входит только в R17. Её раскрытие сдвинет precision R17 '
            'до %d/%d = %.1f%% (если `legitimate`) или %d/%d = %.1f%%.'
            % (', '.join(a006),
               m['R17']['tp'], m['R17']['denominator'] + len(a006),
               100.0 * m['R17']['tp'] / (m['R17']['denominator'] + len(a006)),
               m['R17']['tp'] + len(a006), m['R17']['denominator'] + len(a006),
               100.0 * (m['R17']['tp'] + len(a006)) / (m['R17']['denominator'] + len(a006))))
    add('2. Знаменатели precision — %d и %d размеченных срабатывания. Это единицы наблюдений: '
        'ДИ очень широкие и почти полностью пересекаются.'
        % (m['R17']['denominator'], m['R42']['denominator']))
    add('3. Разница precision R17 (%s) и R42 (%s) — это разница в %d TP при малых знаменателях; '
        'статистической значимости на таких числах нет.'
        % (pct(m['R17']['precision']), pct(m['R42']['precision']),
           m['R17']['tp'] - m['R42']['tp']))
    add('4. Разметка на дату знания неполная: неизвестно %d из %d заявок (%.1f%%). '
        'Отсутствие метки — это «неизвестно», а не «добросовестная» заявка.'
        % (len(unknown), N, 100.0 * len(unknown) / N))
    add('5. Утверждённого порога достаточности выборки нет — здесь он не задаётся и не подразумевается. '
        'Утверждённого SLA разметки в материалах тоже нет (заметки про D+3/D+5 — наблюдение и черновик, не SLA).')
    add('6. Снимок учебный и малый. Результат не является основанием ни для автоматического внедрения правила, '
        'ни для вывода о его превосходстве над другим правилом.')
    add('7. `decision_events` в расчёте не участвует: статусы решений (`approved`/`rejected`/`cancelled`) — '
        'не метки мошенничества и не подменяют `fraud_labels`.')
    add('')
    add('## 6. Что можно и чего нельзя утверждать по этому снимку')
    add('')
    add('Можно: на дату знания %s R17 сработал на %d из %d заявок (coverage %s), среди размеченных срабатываний '
        '%d TP и %d FP; R42 — на %d из %d (coverage %s), %d TP и %d FP.'
        % (T.strftime('%Y-%m-%d %H:%M:%S'), m['R17']['hits_unique'], N, pct(m['R17']['coverage']),
           m['R17']['tp'], m['R17']['fp'],
           m['R42']['hits_unique'], N, pct(m['R42']['coverage']), m['R42']['tp'], m['R42']['fp']))
    add('')
    add('Нельзя: утверждать, что одно правило лучше другого, оценивать эффект на всю популяцию, '
        'экстраполировать precision на неизвестные заявки или запускать правило в автоматику по этому снимку.')
    add('')

    with open(os.path.join(HERE, 'summary.md'), 'w', encoding='utf-8') as fh:
        fh.write('\n'.join(L))


if __name__ == '__main__':
    main()
