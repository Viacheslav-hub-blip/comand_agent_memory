# Индекс знаний

Область: предметные знания, Cases и Skills по проекту «Север» (анализ антифрода). Личные правила и контекст — в `../AGENTS.md`, `../USER_PREFERENCES.md`, `../user_llm_wiki/`.

## Wiki
- [wiki/evaluation-definitions.md](wiki/evaluation-definitions.md) — когорта, дата знания `T` и срез `fraud_labels`, `TP`/`FP`/`unknown`, precision, recall на размеченной части, coverage, форматы данных.
- [wiki/decision-and-payment-semantics.md](wiki/decision-and-payment-semantics.md) — исторический срез `decision_events` (`occurred_at < T AND loaded_at < T`), смысл `status`, чистая выдача по `payments`.

## Cases
- [cases/label-snapshot-as-of-date.md](cases/label-snapshot-as-of-date.md) — выбор версии метки на дату знания, отбрасывание поздней переклассификации (`L007`/A001), негативный контроль временного среза.
- [cases/rule-evaluation-validity-and-unknowns.md](cases/rule-evaluation-validity-and-unknowns.md) — проверка пригодности и сравнимости до расчёта метрик и выделение неизвестных как отдельной группы при малых знаменателях.
- [cases/rule-metric-change-decomposition.md](cases/rule-metric-change-decomposition.md) — разделение эффекта состава срабатываний и изменения разметки при переоценке правил.

## Skills
- [skills/fraud-rule-evaluation/SKILL.md](skills/fraud-rule-evaluation/SKILL.md) — сквозная воспроизводимая оценка и сравнение правил антифрода по историческому срезу знаний, включая переоценку после переклассификации метки.
  - [references/example-c03-c07.md](skills/fraud-rule-evaluation/references/example-c03-c07.md) — проверенный пример с двумя срезами знания, фрагментами кода, результатами и артефактами.
