"""C03: оценка R17 и R42 на когорте реальных заявок 2026-10-01..2026-10-02 (верхняя граница исключена).

Дата знания T = 2026-10-05 00:00:00 UTC.
Определения: documents/fraud_evaluation.md, documents/data_dictionary.md,
knowledge/wiki/evaluation-definitions.md (reporting v2).
Запуск: python calculate.py  (из каталога synthetic_team/outputs/C03)
Зависимости: только стандартная библиотека Python (Polars недоступен, pandas не требуется).
"""
import csv
import json
import os
from datetime import datetime

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "inputs")
OUT = os.path.dirname(os.path.abspath(__file__))

T = datetime(2026, 10, 5, 0, 0, 0)
WIN_LO = datetime(2026, 10, 1, 0, 0, 0)
WIN_HI = datetime(2026, 10, 3, 0, 0, 0)  # исключается
RULES = ["R17", "R42"]
TS = "%Y-%m-%d %H:%M:%S"


def load(name):
    with open(os.path.join(BASE, name), newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


apps = load("applications.csv")
labels = load("fraud_labels.csv")
hits = load("rule_hits.csv")

problems = []

# --- проверки целостности входов ---
app_ids = [a["application_id"] for a in apps]
if len(app_ids) != len(set(app_ids)):
    problems.append("application_id не уникален в applications")
label_ids = [l["label_id"] for l in labels]
if len(label_ids) != len(set(label_ids)):
    problems.append("label_id не уникален в fraud_labels")
hit_pairs = [(h["rule_id"], h["application_id"]) for h in hits]
if len(hit_pairs) != len(set(hit_pairs)):
    problems.append("пара (rule_id, application_id) не уникальна в rule_hits")
app_set = set(app_ids)
for l in labels:
    if l["application_id"] not in app_set:
        problems.append("сирота в fraud_labels: %s" % l["label_id"])
for h in hits:
    if h["application_id"] not in app_set:
        problems.append("сирота в rule_hits: %s/%s" % (h["rule_id"], h["application_id"]))
for l in labels:
    if l["label"] not in ("confirmed_fraud", "legitimate"):
        problems.append("недопустимая метка: %s" % l["label_id"])

# --- когорта ---
cohort = [a for a in apps if a["is_test"] == "0"
          and WIN_LO <= datetime.strptime(a["created_at"], TS) < WIN_HI]
excluded_test = [a["application_id"] for a in apps if a["is_test"] != "0"]
cohort_ids = [a["application_id"] for a in cohort]
cohort_set = set(cohort_ids)
N = len(cohort_ids)

# --- проверка смещения срабатываний от created_at до T ---
created = {a["application_id"]: datetime.strptime(a["created_at"], TS) for a in apps}
for h in hits:
    hh = datetime.strptime(h["hit_at"], TS)
    if h["application_id"] in created and hh < created[h["application_id"]]:
        problems.append("hit_at раньше created_at: %s" % h["application_id"])
    if hh >= T:
        problems.append("hit_at >= T: %s" % h["application_id"])

# --- срез меток на T ---
# последняя строка recorded_at < T; tie-break label_id DESC
by_app = {}
for l in labels:
    ra = datetime.strptime(l["recorded_at"], TS)
    if ra >= T:
        continue
    cur = by_app.get(l["application_id"])
    key = (ra, l["label_id"])
    if cur is None or key > cur[0]:
        by_app[l["application_id"]] = (key, l)

dropped_future = [(l["label_id"], l["application_id"], l["label"], l["recorded_at"])
                  for l in labels if datetime.strptime(l["recorded_at"], TS) >= T]
if not dropped_future:
    problems.append("негативный контроль: фильтр по T ничего не отбросил (проверить наличие поздних строк)")

label_at_T = {aid: kv[1]["label"] for aid, kv in by_app.items()}
label_src = {aid: kv[1]["label_id"] for aid, kv in by_app.items()}

cohort_label = {aid: label_at_T.get(aid, "unknown") for aid in cohort_ids}
labeled = [aid for aid in cohort_ids if cohort_label[aid] != "unknown"]
unknown_apps = [aid for aid in cohort_ids if cohort_label[aid] == "unknown"]
n_cf = sum(1 for aid in labeled if cohort_label[aid] == "confirmed_fraud")
n_leg = sum(1 for aid in labeled if cohort_label[aid] == "legitimate")

# --- срабатывания ---
hit_apps = {r: set() for r in RULES}
for h in hits:
    if h["rule_id"] in hit_apps and h["application_id"] in cohort_set \
            and datetime.strptime(h["hit_at"], TS) < T:
        hit_apps[h["rule_id"]].add(h["application_id"])

metrics = []
unknowns_rows = []
for r in RULES:
    hs = sorted(hit_apps[r])
    tp = [a for a in hs if cohort_label[a] == "confirmed_fraud"]
    fp = [a for a in hs if cohort_label[a] == "legitimate"]
    un = [a for a in hs if cohort_label[a] == "unknown"]
    assert len(tp) + len(fp) + len(un) == len(hs), "инвариант TP+FP+unknown"
    prec = (len(tp) / (len(tp) + len(fp))) if (len(tp) + len(fp)) else None
    rec = (len(tp) / n_cf) if n_cf else None
    cov = len(hs) / N if N else None
    metrics.append({
        "rule_id": r, "cohort": N, "hits": len(hs),
        "TP": len(tp), "FP": len(fp), "unknown": len(un),
        "precision_num": len(tp), "precision_den": len(tp) + len(fp),
        "recall_num": len(tp), "recall_den": n_cf,
        "coverage_num": len(hs), "coverage_den": N,
        "precision": round(prec, 4) if prec is not None else "",
        "recall": round(rec, 4) if rec is not None else "",
        "coverage": round(cov, 4) if cov is not None else "",
        "tp_apps": ";".join(tp), "fp_apps": ";".join(fp), "unknown_apps": ";".join(un),
    })
    for a in un:
        unknowns_rows.append({"rule_id": r, "application_id": a,
                              "reason": "нет метки на T"})

overlap = sorted(hit_apps["R17"] & hit_apps["R42"])
only17 = sorted(hit_apps["R17"] - hit_apps["R42"])
only42 = sorted(hit_apps["R42"] - hit_apps["R17"])

summary = {
    "T": "2026-10-05 00:00:00",
    "window": "[2026-10-01 00:00:00, 2026-10-03 00:00:00)",
    "cohort": cohort_ids, "N": N,
    "excluded_test": excluded_test,
    "labeled": len(labeled), "labeled_share": round(len(labeled) / N, 4),
    "confirmed_fraud": n_cf, "legitimate": n_leg,
    "unknown_cohort": unknown_apps,
    "dropped_future_labels": dropped_future,
    "hit_sets_overlap": overlap, "hits_only_R17": only17, "hits_only_R42": only42,
    "problems": problems,
    "metrics": metrics,
}
print(json.dumps(summary, ensure_ascii=False, indent=2))


def write_csv(path, rows, fields):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for row in rows:
            w.writerow(row)


write_csv(os.path.join(OUT, "metrics.csv"), metrics,
          ["rule_id", "cohort", "hits", "TP", "FP", "unknown",
           "precision_num", "precision_den", "recall_num", "recall_den",
           "coverage_num", "coverage_den", "precision", "recall", "coverage",
           "tp_apps", "fp_apps", "unknown_apps"])
write_csv(os.path.join(OUT, "cohort_labels.csv"),
          [{"application_id": a, "is_test": 0, "created_at": created[a].strftime(TS),
            "label_at_T": cohort_label[a], "label_source": label_src.get(a, "")}
           for a in cohort_ids],
          ["application_id", "is_test", "created_at", "label_at_T", "label_source"])
write_csv(os.path.join(OUT, "unknowns.csv"), unknowns_rows,
          ["rule_id", "application_id", "reason"])
write_csv(os.path.join(OUT, "eval_2026-10-05.csv"), metrics,
          ["rule_id", "cohort", "hits", "TP", "FP", "unknown",
           "precision_num", "precision_den", "recall_num", "recall_den",
           "coverage_num", "coverage_den", "precision", "recall", "coverage",
           "tp_apps", "fp_apps", "unknown_apps"])
print("OK: файлы записаны в", OUT)
