"""Независимая по-заявочная проверка: ручной перебор без повторного использования логики calculate.py.
Запуск: python verify.py
"""
import csv
import os

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "inputs")
T = "2026-10-05 00:00:00"

# Ручной перебор по фактическим строкам CSV (зафиксирован при чтении файлов)
cohort = ["A001", "A002", "A003", "A005", "A006", "A007", "A008"]
labels_on_T = {
    "A001": "confirmed_fraud",  # L001 2026-10-03 (L007 2026-10-06 отброшен)
    "A002": "legitimate",
    "A003": "confirmed_fraud",
    "A005": "confirmed_fraud",
    "A007": "legitimate",
    "A008": "legitimate",
    # A006 отсутствует -> unknown
}
hits = {"R17": ["A001", "A002", "A005", "A006"],
        "R42": ["A003", "A007", "A008"]}

# Сверка ручных констант с файлами
with open(os.path.join(BASE, "applications.csv"), encoding="utf-8") as f:
    rows = list(csv.DictReader(f))
file_cohort = [r["application_id"] for r in rows
               if r["is_test"] == "0" and "2026-10-01" <= r["created_at"][:10] <= "2026-10-02"]
assert file_cohort == cohort, file_cohort

with open(os.path.join(BASE, "rule_hits.csv"), encoding="utf-8") as f:
    fh = {}
    for r in csv.DictReader(f):
        fh.setdefault(r["rule_id"], []).append(r["application_id"])
assert {k: sorted(v) for k, v in fh.items()} == {k: sorted(v) for k, v in hits.items()}, fh

with open(os.path.join(BASE, "fraud_labels.csv"), encoding="utf-8") as f:
    fl = list(csv.DictReader(f))
man = {}
for r in fl:
    if r["recorded_at"] < T:
        cur = man.get(r["application_id"])
        if cur is None or (r["recorded_at"], r["label_id"]) > cur:
            man[r["application_id"]] = (r["recorded_at"], r["label_id"], r["label"])
manual_labels = {a: v[2] for a, v in man.items()}
assert manual_labels == labels_on_T, manual_labels

n_cf = sum(1 for v in manual_labels.values() if v == "confirmed_fraud")
for r, lst in hits.items():
    tp = sum(1 for a in lst if manual_labels.get(a) == "confirmed_fraud")
    fp = sum(1 for a in lst if manual_labels.get(a) == "legitimate")
    un = sum(1 for a in lst if a not in manual_labels)
    assert tp + fp + un == len(lst)
    print(r, "hits", len(lst), "TP", tp, "FP", fp, "unknown", un,
          "precision", "%d/%d" % (tp, tp + fp), "recall", "%d/%d" % (tp, n_cf),
          "coverage", "%d/%d" % (len(lst), len(cohort)))

# --- сверка с metrics.csv ---
with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "metrics.csv"), encoding="utf-8") as f:
    m = {r["rule_id"]: r for r in csv.DictReader(f)}
for r, lst in hits.items():
    tp = sum(1 for a in lst if manual_labels.get(a) == "confirmed_fraud")
    fp = sum(1 for a in lst if manual_labels.get(a) == "legitimate")
    un = sum(1 for a in lst if a not in manual_labels)
    assert int(m[r]["TP"]) == tp and int(m[r]["FP"]) == fp and int(m[r]["unknown"]) == un
    assert int(m[r]["hits"]) == len(lst)

# --- негативный контроль временного среза: L007 действительно не влияет ---
future = [r for r in fl if r["recorded_at"] >= T]
assert future and all(r["recorded_at"] >= T for r in future)
print("negative control: строки с recorded_at>=T:", [(r["label_id"], r["application_id"], r["label"]) for r in future])
print("ALL CHECKS OK")
