# Новые прогоны Веры

Повтор знакомых задач; по одному опыту на вариант.
Успех — решение модельного тестировщика. Стоимость взята из token_usage.cost; при неполном учёте cost_usd=null.
Построение памяти учитывается отдельно в memory-build/*.metrics.json.

| case | variant | role | state | user_turns | duration_seconds | model_calls | tool_calls | input_tokens | cached_tokens | new_input_tokens | output_tokens | usage_complete | cost_usd | cost_complete |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C03 | with-memory | tested_agent | completed | 2 | 85.03758459998062 | 24 | 29 | 513088 | 471424 | 41664 | 12319 | True | 0.010099852 | True |
| C03 | with-memory | tester | completed | 2 | 16.29900290002115 | 2 | 0 | 28634 | 12160 | 16474 | 2040 | True | 0.0025372 | True |
| C03 | without-memory | tested_agent | completed | 3 | 220.706209499971 | 56 | 56 | 1260271 | 1184640 | 75631 | 31709 | True | 0.024651677999999996 | True |
| C03 | without-memory | tester | completed | 3 | 29.619376899965573 | 3 | 0 | 88049 | 49152 | 38897 | 3762 | True | 0.005574076 | True |
| C07 | with-memory | tested_agent | completed | 2 | 85.78615560004255 | 29 | 48 | 766804 | 702720 | 64084 | 18576 | True | 0.015236792 | True |
| C07 | with-memory | tester | completed | 2 | 47.313407900044695 | 2 | 0 | 31097 | 13824 | 17273 | 6208 | True | 0.006068156999999999 | True |
| C07 | without-memory | tested_agent | completed | 2 | 146.62699299998349 | 38 | 51 | 881721 | 843776 | 37945 | 22264 | True | 0.01679279 | True |
| C07 | without-memory | tester | completed | 2 | 10.00583459995687 | 2 | 0 | 22498 | 7680 | 14818 | 1802 | True | 0.0015024840000000001 | True |
