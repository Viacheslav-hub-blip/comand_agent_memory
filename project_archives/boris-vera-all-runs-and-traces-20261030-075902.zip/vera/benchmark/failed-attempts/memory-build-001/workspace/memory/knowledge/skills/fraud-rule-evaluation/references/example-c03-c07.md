# Пример исполнения: срезы знания 2026-10-05 и 2026-10-07

Проверенный учебный маршрут для `fraud-rule-evaluation`. Числа — контроль примера, не постоянные параметры будущих запусков.

## Входные факты
- Когорта: `applications.is_test = 0`, `created_at` в `[2026-10-01 00:00:00, 2026-10-03 00:00:00)`; 7 заявок: A001, A002, A003, A005, A006, A007, A008; A004 исключена как тестовая.
- `fraud_labels`: `L001, A001, confirmed_fraud, 2026-10-03 09:00:00`; `L007, A001, legitimate, 2026-10-06 12:00:00, investigation_corrected`. Других версий по заявкам когорты нет; A006 без метки.
- `rule_hits` (одинаков на оба среза): R17 → A001, A002, A005, A006; R42 → A003, A007, A008.

## Срез меток на дату знания
```python
def labels_as_of(labels, t, cohort_ids):
    best = {}
    for row in labels:
        if ts(row['recorded_at']) >= t:      # поздние правки отбрасываются
            continue
        app = row['application_id']
        if app not in cohort_ids:
            continue
        cur = best.get(app)
        if cur is None or (ts(row['recorded_at']), row['label_id']) > (
            ts(cur['recorded_at']), cur['label_id']
        ):
            best[app] = row                  # tie-break: label_id DESC
    return {app: row['label'] for app, row in best.items()}
```

## Метрики
```python
tp = [a for a in hit_apps if lab.get(a) == 'confirmed_fraud']
fp = [a for a in hit_apps if lab.get(a) == 'legitimate']
unknown = [a for a in hit_apps if a not in lab]
precision = len(tp) / (len(tp) + len(fp)) if (len(tp) + len(fp)) else None
recall = len(tp) / len(confirmed_fraud_in_cohort) if confirmed_fraud_in_cohort else None
coverage = len(hit_apps) / len(cohort)
```

## Результаты по срезам
| Срез | Размечено | R17 TP/FP/unknown | R17 precision / recall / coverage | R42 TP/FP/unknown | R42 precision / recall / coverage |
|---|---|---|---|---|---|
| 2026-10-05 | 6/7 (85.7%) | 2 / 1 / 1 | 2/3 = 66.7% / 2/3 = 66.7% / 4/7 = 57.1% | 1 / 2 / 0 | 1/3 = 33.3% / 1/3 = 33.3% / 3/7 = 42.9% |
| 2026-10-07 | 6/7 (85.7%) | 1 / 2 / 1 | 1/3 = 33.3% / 1/2 = 50.0% / 4/7 = 57.1% | 1 / 2 / 0 | 1/3 = 33.3% / 1/2 = 50.0% / 3/7 = 42.9% |

Драйверы изменений: `rule_hits` не менялся. У R17 A001 перешла TP → FP из-за `L007`. У R42 TP/FP не менялись; recall выросла только потому, что знаменатель `confirmed_fraud` в когорте уменьшился с 3 до 2. A006 остаётся `unknown` на обоих срезах.

## Выполненные проверки
- `check_data.py` — «данные пригодны»: уникальные ключи, нет «сирот», нет срабатываний раньше `created_at` и позже `T`.
- `verify.py` — независимый по-заявковый перебор совпал, инварианты `TP+FP+unknown` и `TP+FP` выполнены.
- `check_table.py` — сохранённые таблицы совпали с расчётом (в эпизоде: `table.csv` — 2 строки, 14 колонок; `cohort_labels.csv` — 1 строка, 11 колонок).
- `check_temporal.py` — `L007` отброшена на `2026-10-05`, исторический срез отличается от полного текущего снимка.

## Ограничение исполнения в эпизоде
В эпизоде C07 интерпретатор Python был недоступен (exit 9009), поэтому расчёт выполнен вручную и записан файлами; сохранность значений подтверждена повторным чтением `metrics.csv`. Это не обязательный шаг метода, а обход ограничения среды: при доступном Python расчёт ведётся стандартной библиотекой.

## Сохранённые артефакты
- `/synthetic_team/outputs/C03/`: `calculate.py`, `table.csv`, `cohort_labels.csv`, `report.md`, `procedure.md`, проверки `check_data.py`, `verify.py`, `check_table.py`, `check_temporal.py`; все проверки проходят. Более ранний вариант — `/synthetic_team/outputs/r17_vs_r42_2026-10-01_02/`.
- `/synthetic_team/outputs/C07/`: `report.md`, `metrics.csv`, `deltas.csv`, `unknowns.csv`, `labels_snapshot.csv`, `eval_2026-10-05.csv`, `eval_2026-10-07.csv`, `method_addition.md`.

Ссылки на эти пути — сведения о прошлых запусках; наличие файлов перед переиспользованием проверять.
