# Проект «Север»

## Пользователь и роль
- Вера — аналитик антифрода. Учебные материалы, данные и организация команды «Север» вымышлены.

## Структура рабочей области
- `inputs/` — CSV-снимки: `applications`, `decision_events`, `payments`, `fraud_labels`, `rule_hits`.
- `documents/` — определения с указанием дат действия версий (`fraud_evaluation.md`, `data_dictionary.md`).
- `sql/` — `schema.sql`, `legacy_approval.sql`.
- `outputs/<ID сценария>/` — результаты расчётов.

## Схема данных
- `applications`: `application_id` (PK), `is_test`, `created_at`.
- `decision_events`: `event_id` (PK), `occurred_at`, `loaded_at`, статус после события; `status` — не метка мошенничества.
- `payments`: `payment_type` = `disbursement` / `refund`, `booked_at`, сумма; чистая выдача = `disbursement` минус `refund` по `booked_at` (подробнее — [../knowledge/wiki/decision-and-payment-semantics.md](../knowledge/wiki/decision-and-payment-semantics.md)).
- `fraud_labels`: история заключений с `label_id`, `label` (`confirmed_fraud` / `legitimate`), `recorded_at`, `reason`.
- `rule_hits`: PK (`rule_id`, `application_id`), `hit_at`; одна строка на пару в учебном снимке; срабатывание не равно подтверждённому фроду и не равно отказу.
- `application_id` в исторических таблицах намеренно не уникален — на заявку бывает несколько событий.
- Времена во всех данных — UTC, формат `YYYY-MM-DD HH:MM:SS`; суммы в целых рублях; CSV в UTF-8 с разделителем-запятой.

## Определения: где смотреть
- Метрики, когорта, дата знания `T`, срез `fraud_labels`, форматы — [../knowledge/wiki/evaluation-definitions.md](../knowledge/wiki/evaluation-definitions.md).
- Исторический срез `decision_events`, смысл `status`, денежные величины `payments` — [../knowledge/wiki/decision-and-payment-semantics.md](../knowledge/wiki/decision-and-payment-semantics.md).
- `legacy_approval.sql` — старый диагностический запрос, корректность не подтверждена, эталоном не является.

## Сценарии C03 и C07 — оценка и переоценка R17 и R42
- Когорта `is_test = 0`, `created_at` 2026-10-01..2026-10-02 (верхняя граница исключена): 7 реальных заявок — A001, A002, A003, A005, A006, A007, A008; A004 исключена как тестовая. `rule_hits` неизменен между сценариями: R17 → A001, A002, A005, A006; R42 → A003, A007, A008.
- Базовый срез C03, `T = 2026-10-05 00:00:00 UTC`: размечено 6 из 7 (85.7%), `confirmed_fraud` 3, `legitimate` 3, `unknown` 1 (A006). R17: 4/7 срабатываний, TP 2, FP 1, unknown 1, precision 66.7%, recall 66.7%, coverage 57.1%. R42: 3/7, TP 1, FP 2, unknown 0, precision 33.3%, recall 33.3%, coverage 42.9%. Наборы срабатываний не пересекаются, доверительные интервалы перекрываются — по снимку правила статистически неразличимы.
- Переоценка C07, `T_after = 2026-10-07 00:00:00 UTC`, статус завершён: R17 — TP 2→1, FP 1→2, precision 66.7%→33.3%, recall 66.7%→50.0%; R42 — TP/FP и precision без изменений (1/3 = 33.3%), recall 33.3%→50.0% только за счёт уменьшения знаменателя recall 3→2. A006 остаётся `unknown` на обоих срезах; coverage не меняется (R17 4/7, R42 3/7). Расчёт C03 остаётся базовым для среза 2026-10-05, C07 интерпретирует эффект изменения разметки.
- A001: 2026-10-06 переклассифицирована `confirmed_fraud` → `legitimate` (`label_id` L007, `recorded_at` 2026-10-06 12:00:00, `reason` `investigation_corrected`); на срезе 2026-10-05 действует L001. Причина пересмотра не раскрыта.
- Артефакты: `/synthetic_team/outputs/C03/` — `calculate.py`, `table.csv`, `cohort_labels.csv`, `report.md`, `procedure.md`, проверки `check_data.py`, `verify.py`, `check_table.py`, `check_temporal.py` (все проверки проходят); более ранний вариант — `/synthetic_team/outputs/r17_vs_r42_2026-10-01_02/`. Переоценка — `/synthetic_team/outputs/C07/`: `report.md`, `metrics.csv`, `deltas.csv`, `unknowns.csv`, `labels_snapshot.csv`, `eval_2026-10-05.csv`, `eval_2026-10-07.csv`, `method_addition.md`. Это записи о прошлых запусках: наличие файлов проверять перед переиспользованием.
- Порядок выполнения подобных задач закреплён в [../knowledge/skills/fraud-rule-evaluation/SKILL.md](../knowledge/skills/fraud-rule-evaluation/SKILL.md), переносимые приёмы и проверки — в [../knowledge/cases/](../knowledge/cases/). Дополнительные данные для более надёжного вывода (исходы по неизвестным заявкам, утверждённый порядок разметки, пересекающиеся наборы срабатываний, версии правил, стоимость ошибок) в снимке отсутствуют и оформлены как требования, а не как установленные факты.

## Ограничения и открытые вопросы
- Утверждённого SLA разметки нет; заметки «D+3» / «D+5» — наблюдение и черновик, не SLA.
- Порог достаточности выборки для учебного снимка не установлен; не вводить его и не рекомендовать автоматическое внедрение правил по этому снимку.
- Небольшой учебный снимок не обосновывает внедрение правила в производство.
- Расхождение в записях об окружении: в одной части материалов указан Python 3.11.9 и pandas 3.0.3, в другой — что `python` / `python3` недоступны (exit 9009) и расчёт выполнялся файловыми инструментами. Доступность интерпретатора, версию pandas и наличие Polars в конкретном окружении проекта перепроверять перед использованием; при недоступности Python расчёт вести файловыми инструментами.
