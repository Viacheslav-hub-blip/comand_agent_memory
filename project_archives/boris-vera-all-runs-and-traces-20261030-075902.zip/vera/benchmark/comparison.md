# Новая память Веры: C03 и C07

Модель: deepseek/deepseek-v4.1-flash-1017. Все четыре новых опыта завершены; цель подтверждена модельным тестировщиком.
По одному повтору знакомых задач. Перенос и статистическая устойчивость не проверялись. Входные токены включают кешированный контекст.
Исходные файлы, опубликованная память и её копии проверены по байтам. В вариантах without-memory память отсутствует. Число вызовов и токены совпадают с полными трассами. Стоимость всех ролей и подготовки сверена по token_usage.cost и полноте токенов.

## Решающий агент

| Сценарий | Память | Реплики | Время, с | Вызовы модели | Инструменты | Вход | Кеш | Новый вход | Выход | Стоимость, $ |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| C03 | without-memory | 3 | 220.7 | 56 | 56 | 1260271 | 1184640 | 75631 | 31709 | 0.02465168 |
| C03 | with-memory | 2 | 85.0 | 24 | 29 | 513088 | 471424 | 41664 | 12319 | 0.01009985 |
| C07 | without-memory | 2 | 146.6 | 38 | 51 | 881721 | 843776 | 37945 | 22264 | 0.01679279 |
| C07 | with-memory | 2 | 85.8 | 29 | 48 | 766804 | 702720 | 64084 | 18576 | 0.01523679 |

## Тестировщик (отдельные затраты)

| Сценарий | Память | Время, с | Вызовы | Вход | Кеш | Выход | Стоимость, $ |
|---|---|---:|---:|---:|---:|---:|---:|
| C03 | without-memory | 29.6 | 3 | 88049 | 49152 | 3762 | 0.00557408 |
| C03 | with-memory | 16.3 | 2 | 28634 | 12160 | 2040 | 0.00253720 |
| C07 | without-memory | 10.0 | 2 | 22498 | 7680 | 1802 | 0.00150248 |
| C07 | with-memory | 47.3 | 2 | 31097 | 13824 | 6208 | 0.00606816 |

## Агент и тестировщик вместе

| Сценарий | Без памяти, $ | С памятью, $ | Изменение стоимости с памятью |
|---|---:|---:|---:|
| C03 | 0.03022575 | 0.01263705 | -58.19% |
| C07 | 0.01829527 | 0.02130495 | +16.45% |

C07: решающий агент с памятью дешевле, но более дорогая проверка тестировщиком делает весь опыт дороже. Это видно только при раздельном учёте ролей.

## Все четыре трассы

| Сценарий | Вариант | Трасса | JSONL | Метрики | Итог |
|---|---|---|---|---|---|
| C03 | without-memory | [Markdown](C:/Users/Slav4ik/PycharmProjects/comand_agent_memory/data/vera-analysis-20261030/benchmark/C03/without-memory/trace.md) | [JSONL](C:/Users/Slav4ik/PycharmProjects/comand_agent_memory/data/vera-analysis-20261030/benchmark/C03/without-memory/result/transcript.jsonl) | [metrics.json](C:/Users/Slav4ik/PycharmProjects/comand_agent_memory/data/vera-analysis-20261030/benchmark/C03/without-memory/result/metrics.json) | [Ответ](C:/Users/Slav4ik/PycharmProjects/comand_agent_memory/data/vera-analysis-20261030/benchmark/C03/without-memory/result/answer.md) |
| C03 | with-memory | [Markdown](C:/Users/Slav4ik/PycharmProjects/comand_agent_memory/data/vera-analysis-20261030/benchmark/C03/with-memory/trace.md) | [JSONL](C:/Users/Slav4ik/PycharmProjects/comand_agent_memory/data/vera-analysis-20261030/benchmark/C03/with-memory/result/transcript.jsonl) | [metrics.json](C:/Users/Slav4ik/PycharmProjects/comand_agent_memory/data/vera-analysis-20261030/benchmark/C03/with-memory/result/metrics.json) | [Ответ](C:/Users/Slav4ik/PycharmProjects/comand_agent_memory/data/vera-analysis-20261030/benchmark/C03/with-memory/result/answer.md) |
| C07 | without-memory | [Markdown](C:/Users/Slav4ik/PycharmProjects/comand_agent_memory/data/vera-analysis-20261030/benchmark/C07/without-memory/trace.md) | [JSONL](C:/Users/Slav4ik/PycharmProjects/comand_agent_memory/data/vera-analysis-20261030/benchmark/C07/without-memory/result/transcript.jsonl) | [metrics.json](C:/Users/Slav4ik/PycharmProjects/comand_agent_memory/data/vera-analysis-20261030/benchmark/C07/without-memory/result/metrics.json) | [Ответ](C:/Users/Slav4ik/PycharmProjects/comand_agent_memory/data/vera-analysis-20261030/benchmark/C07/without-memory/result/answer.md) |
| C07 | with-memory | [Markdown](C:/Users/Slav4ik/PycharmProjects/comand_agent_memory/data/vera-analysis-20261030/benchmark/C07/with-memory/trace.md) | [JSONL](C:/Users/Slav4ik/PycharmProjects/comand_agent_memory/data/vera-analysis-20261030/benchmark/C07/with-memory/result/transcript.jsonl) | [metrics.json](C:/Users/Slav4ik/PycharmProjects/comand_agent_memory/data/vera-analysis-20261030/benchmark/C07/with-memory/result/metrics.json) | [Ответ](C:/Users/Slav4ik/PycharmProjects/comand_agent_memory/data/vera-analysis-20261030/benchmark/C07/with-memory/result/answer.md) |

## Анализ и подготовка памяти, включая неудачную попытку

| Этап | Ответ получен | Время, с | Вход | Кеш | Выход | Стоимость, $ |
|---|---|---:|---:|---:|---:|---:|
| benchmark\failed-attempts\memory-build-001\consolidation-knowledge.metrics.json | True | 245.6 | 3479900 | 3022464 | 42409 | 0.20625638 |
| benchmark\failed-attempts\memory-build-001\consolidation.metrics.json | True | 84.3 | 864438 | 806272 | 13732 | 0.01310767 |
| benchmark\memory-build\reviews\review-001.metrics.json | True | 1114.6 | 7116698 | 6996992 | 151617 | 0.12918954 |
| results\analysis-runs\20261030T070608727067-eba7ebddac8d\861e11e65ef153f913ee4a038df6cb812dfa4345ca25ad06b671441566eb8efd-context.metrics.json | True | 50.9 | 218105 | 0 | 14044 | 0.02517260 |
| results\analysis-runs\20261030T070608727067-eba7ebddac8d\861e11e65ef153f913ee4a038df6cb812dfa4345ca25ad06b671441566eb8efd-procedures.metrics.json | True | 23.2 | 220777 | 0 | 7277 | 0.01202803 |
| results\analysis-runs\20261030T070608727067-eba7ebddac8d\e228115538449a6f2a0c83e9530f9c258182fd3c2f60864ef934a8d19c9e9efe-context.metrics.json | True | 33.2 | 58929 | 1920 | 5995 | 0.00787333 |
| results\analysis-runs\20261030T070608727067-eba7ebddac8d\e228115538449a6f2a0c83e9530f9c258182fd3c2f60864ef934a8d19c9e9efe-procedures.metrics.json | True | 20.0 | 61601 | 4736 | 5959 | 0.00516405 |

Подготовка: сумма длительностей модельных этапов 1571.7 с; вход 12020448, кеш 10832384, выход 241033; стоимость $0.39879160. Учёт токенов и стоимости полный.

Первая консолидация знаний изменила личные файлы вне своей области. Неудачная попытка сохранена, личная часть восстановлена по полному diff создания, черновик проверен штатным ревью и опубликован при accepted с findings=[]. Повторный анализ и смена модели не потребовались.

Подготовка памяти пока не окупилась на этих двух сценариях.

[Все итоговые файлы](artifacts.md). [Проверки целостности](integrity-checks.json). [Подробные метрики JSON](comparison.json).
