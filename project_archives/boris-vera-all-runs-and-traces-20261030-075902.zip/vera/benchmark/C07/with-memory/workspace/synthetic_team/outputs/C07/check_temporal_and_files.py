# -*- coding: utf-8 -*-
"""Негативный контроль временного среза + сверка сохранённых файлов с пересчётом."""
import csv, os, importlib.util

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "..", "..", "inputs")

def read(name):
    with open(os.path.join(DATA, name), newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

labels = read("fraud_labels.csv")
T_BEFORE = "2026-10-05 00:00:00"
T_AFTER = "2026-10-07 00:00:00"

# 1) L007 должна быть отброшена на 2026-10-05 и учтена на 2026-10-07
kept_before = [r["label_id"] for r in labels if r["recorded_at"] < T_BEFORE]
kept_after = [r["label_id"] for r in labels if r["recorded_at"] < T_AFTER]
print("L007 dropped on 2026-10-05:", "L007" not in kept_before)
print("L007 present on 2026-10-07:", "L007" in kept_after)
print("filter non-empty before:", len(kept_before) > 0, len(kept_before))
print("filter non-empty after:", len(kept_after) > 0, len(kept_after))

# 2) сверка metrics.csv с независимым пересчётом по-заявково
apps = read("applications.csv")
hits = read("rule_hits.csv")
cohort = [a["application_id"] for a in apps
          if a["is_test"] == "0" and "2026-10-01 00:00:00" <= a["created_at"] < "2026-10-03 00:00:00"]
idset = set(cohort)

def lab_as_of(t):
    best = {}
    for r in labels:
        if r["recorded_at"] >= t or r["application_id"] not in idset:
            continue
        cur = best.get(r["application_id"])
        if cur is None or (r["recorded_at"], r["label_id"]) > (cur["recorded_at"], cur["label_id"]):
            best[r["application_id"]] = r
    return {k: v["label"] for k, v in best.items()}

def metrics(t):
    lab = lab_as_of(t)
    cf = sum(1 for a in cohort if lab.get(a) == "confirmed_fraud")
    out = {}
    for rule in ("R17", "R42"):
        hit = []
        for h in hits:
            if h["rule_id"] == rule and h["application_id"] in idset and h["hit_at"] < t \
               and h["application_id"] not in hit:
                hit.append(h["application_id"])
        tp = sum(1 for a in hit if lab.get(a) == "confirmed_fraud")
        fp = sum(1 for a in hit if lab.get(a) == "legitimate")
        unk = sum(1 for a in hit if a not in lab)
        out[rule] = (tp, fp, unk, cf)
    return out

calc = {"2026-10-05 00:00:00": metrics(T_BEFORE), "2026-10-07 00:00:00": metrics(T_AFTER)}

ok = True
with open(os.path.join(HERE, "metrics.csv"), newline="", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        t, rule = row["T"], row["rule_id"]
        tp, fp, unk, cf = calc[t][rule]
        if (int(row["TP"]), int(row["FP"]), int(row["unknown"])) != (tp, fp, unk):
            ok = False
            print("MISMATCH", t, rule, row, (tp, fp, unk))
print("metrics.csv matches recompute:", ok)
print("independent:", calc)
