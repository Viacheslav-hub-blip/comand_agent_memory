# -*- coding: utf-8 -*-
"""Оценка R17/R42 на когорте 1-2 октября для двух дат знания.
Версия определений: documents/fraud_evaluation.md + documents/data_dictionary.md.
Срез меток: последняя строка fraud_labels с recorded_at < T (tie-break label_id DESC).
"""
import csv
import os

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "..", "..", "inputs")

COHORT_START = "2026-10-01 00:00:00"
COHORT_END = "2026-10-03 00:00:00"
T_BEFORE = "2026-10-05 00:00:00"
T_AFTER = "2026-10-07 00:00:00"


def read(name):
    with open(os.path.join(DATA, name), newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


apps = read("applications.csv")
labels = read("fraud_labels.csv")
hits = read("rule_hits.csv")


def build_cohort(apps):
    real = [a for a in apps if a["is_test"] == "0"]
    cohort = [a for a in real if COHORT_START <= a["created_at"] < COHORT_END]
    excluded_test = [a["application_id"] for a in apps
                     if a["is_test"] == "1"
                     and COHORT_START <= a["created_at"] < COHORT_END]
    return cohort, excluded_test


def labels_as_of(t, cohort_ids):
    best = {}
    for row in labels:
        if row["recorded_at"] >= t:
            continue
        app = row["application_id"]
        if app not in cohort_ids:
            continue
        cur = best.get(app)
        if cur is None or (row["recorded_at"], row["label_id"]) > (
                cur["recorded_at"], cur["label_id"]):
            best[app] = row
    return {app: r["label"] for app, r in best.items()}, {app: r["label_id"] for app, r in best.items()}


def hits_as_of(rule, t, cohort_ids):
    seen = []
    for row in hits:
        if row["rule_id"] != rule:
            continue
        if row["application_id"] not in cohort_ids:
            continue
        if row["hit_at"] >= t:
            continue
        if row["application_id"] not in seen:
            seen.append(row["application_id"])
    return seen


def evaluate(t):
    cohort, excluded = build_cohort(apps)
    ids = [a["application_id"] for a in cohort]
    idset = set(ids)
    lab, labsrc = labels_as_of(t, idset)
    n = len(ids)
    labeled = sum(1 for a in ids if a in lab)
    cf_cohort = [a for a in ids if lab.get(a) == "confirmed_fraud"]
    per_rule = {}
    for rule in ("R17", "R42"):
        hit = hits_as_of(rule, t, idset)
        tp = [a for a in hit if lab.get(a) == "confirmed_fraud"]
        fp = [a for a in hit if lab.get(a) == "legitimate"]
        unk = [a for a in hit if a not in lab]
        assert len(tp) + len(fp) + len(unk) == len(hit), "TP+FP+unknown != hits"
        assert len(tp) + len(fp) == sum(1 for a in hit if a in lab)
        prec = len(tp) / (len(tp) + len(fp)) if (len(tp) + len(fp)) else None
        rec = len(tp) / len(cf_cohort) if cf_cohort else None
        cov = len(hit) / n if n else None
        per_rule[rule] = dict(hit=hit, tp=tp, fp=fp, unknown=unk,
                              precision=prec, recall=rec, coverage=cov)
    return dict(t=t, cohort=ids, excluded_test=excluded, n=n,
                labels=lab, labelsrc=labsrc, labeled=labeled,
                cf_cohort=cf_cohort, per_rule=per_rule)


def pct(x):
    return "NA" if x is None else f"{x*100:.1f}%"


res_before = evaluate(T_BEFORE)
res_after = evaluate(T_AFTER)

# ---- проверка входов ----
def check_inputs():
    problems = []
    ids = [a["application_id"] for a in apps]
    if len(ids) != len(set(ids)):
        problems.append("дубли application_id")
    lids = [l["label_id"] for l in labels]
    if len(lids) != len(set(lids)):
        problems.append("дубли label_id")
    pairs = [(h["rule_id"], h["application_id"]) for h in hits]
    if len(pairs) != len(set(pairs)):
        problems.append("дубли (rule_id,application_id)")
    idset = set(ids)
    for l in labels:
        if l["application_id"] not in idset:
            problems.append(f"сирота-метка {l['label_id']}")
    for h in hits:
        if h["application_id"] not in idset:
            problems.append(f"сирота-срабатывание {h['rule_id']}/{h['application_id']}")
    app_created = {a["application_id"]: a["created_at"] for a in apps}
    for h in hits:
        if h["hit_at"] < app_created[h["application_id"]]:
            problems.append(f"hit_at<created_at {h['rule_id']}/{h['application_id']}")
    # равные recorded_at внутри заявки
    from collections import defaultdict
    by_app = defaultdict(list)
    for l in labels:
        by_app[l["application_id"]].append(l["recorded_at"])
    for app, ts in by_app.items():
        if len(ts) != len(set(ts)):
            problems.append(f"равные recorded_at у {app}")
    good_labels = {"confirmed_fraud", "legitimate"}
    for l in labels:
        if l["label"] not in good_labels:
            problems.append(f"недопустимая метка {l['label_id']}")
    return problems


problems = check_inputs()

# ---- независимая по-заявковая проверка ----
def verify(res):
    lab = res["labels"]
    ok = True
    for rule, m in res["per_rule"].items():
        for a in m["hit"]:
            if lab.get(a) == "confirmed_fraud" and a not in m["tp"]:
                ok = False
            if lab.get(a) == "legitimate" and a not in m["fp"]:
                ok = False
            if a not in lab and a not in m["unknown"]:
                ok = False
    return ok


# ---- запись артефактов ----
def write_eval(res, fname):
    path = os.path.join(HERE, fname)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["rule_id", "T", "cohort_window", "hits", "TP", "FP", "unknown",
                    "precision", "recall", "coverage", "label_share",
                    "TP_apps", "FP_apps", "unknown_apps", "hits_apps"])
        for rule, m in res["per_rule"].items():
            w.writerow([rule, res["t"], "[2026-10-01 00:00:00,2026-10-03 00:00:00)",
                        len(m["hit"]), len(m["tp"]), len(m["fp"]), len(m["unknown"]),
                        pct(m["precision"]), pct(m["recall"]), pct(m["coverage"]),
                        f"{res['labeled']}/{res['n']}",
                        "|".join(m["tp"]), "|".join(m["fp"]), "|".join(m["unknown"]),
                        "|".join(m["hit"])])


write_eval(res_before, "eval_2026-10-05.csv")
write_eval(res_after, "eval_2026-10-07.csv")

# metrics.csv обе даты
with open(os.path.join(HERE, "metrics.csv"), "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["T", "rule_id", "TP", "FP", "unknown", "precision", "recall", "coverage",
                "labeled", "cohort_n", "confirmed_fraud_in_cohort"])
    for res in (res_before, res_after):
        for rule, m in res["per_rule"].items():
            w.writerow([res["t"], rule, len(m["tp"]), len(m["fp"]), len(m["unknown"]),
                        pct(m["precision"]), pct(m["recall"]), pct(m["coverage"]),
                        f"{res['labeled']}/{res['n']}", res["n"], len(res["cf_cohort"])])

# labels_snapshot.csv
with open(os.path.join(HERE, "labels_snapshot.csv"), "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["application_id", "label_2026-10-05", "src_2026-10-05",
                "label_2026-10-07", "src_2026-10-07"])
    for a in res_before["cohort"]:
        w.writerow([a,
                    res_before["labels"].get(a, "unknown"), res_before["labelsrc"].get(a, ""),
                    res_after["labels"].get(a, "unknown"), res_after["labelsrc"].get(a, "")])

# unknowns.csv
with open(os.path.join(HERE, "unknowns.csv"), "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["rule_id", "T", "unknown_application_id"])
    for res in (res_before, res_after):
        for rule, m in res["per_rule"].items():
            for a in m["unknown"]:
                w.writerow([rule, res["t"], a])

# deltas.csv
with open(os.path.join(HERE, "deltas.csv"), "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["rule_id", "metric", "value_2026-10-05", "value_2026-10-07", "driver"])
    drivers = {
        "R17": "A001 перешла TP->FP (L007); знаменатель recall 3->2 (A001 вышла из confirmed_fraud)",
        "R42": "TP/FP не менялись; recall выросла из-за знаменателя 3->2",
    }
    for rule in ("R17", "R42"):
        b, a = res_before["per_rule"][rule], res_after["per_rule"][rule]
        w.writerow([rule, "precision", pct(b["precision"]), pct(a["precision"]), drivers[rule]])
        w.writerow([rule, "recall", pct(b["recall"]), pct(a["recall"]), drivers[rule]])
        w.writerow([rule, "coverage", pct(b["coverage"]), pct(a["coverage"]), "не менялась"])
        w.writerow([rule, "TP", len(b["tp"]), len(a["tp"]), drivers[rule]])
        w.writerow([rule, "FP", len(b["fp"]), len(a["fp"]), drivers[rule]])
        w.writerow([rule, "unknown", len(b["unknown"]), len(a["unknown"]), "не менялось"])

# ---- вывод ----
def dump(res):
    print(f"=== T = {res['t']} ===")
    print(f"когорта: {res['n']} заявок; исключены тестовые: {res['excluded_test']}")
    print(f"размечено: {res['labeled']}/{res['n']} ({pct(res['labeled']/res['n'])})")
    print(f"confirmed_fraud в когорте: {len(res['cf_cohort'])} {res['cf_cohort']}")
    for rule, m in res["per_rule"].items():
        print(f" {rule}: hits={len(m['hit'])} TP={len(m['tp'])}{m['tp']} FP={len(m['fp'])}{m['fp']} "
              f"unk={len(m['unknown'])}{m['unknown']} prec={pct(m['precision'])} "
              f"rec={pct(m['recall'])} cov={pct(m['coverage'])}")


dump(res_before)
dump(res_after)
print("problems:", problems if problems else "нет")
print("verify before:", verify(res_before), "verify after:", verify(res_after))
