"""Повтор оценки R17/R42 на когорте 2026-10-01..2026-10-02 (is_test=0).

Срезы знания: 2026-10-05 00:00:00 (воспроизведение) и 2026-10-07 00:00:00
(после переклассификации A001). Правила по documents/fraud_evaluation.md и
documents/data_dictionary.md: метка на срез T — последняя строка fraud_labels
с recorded_at < T (при равенстве label_id DESC); нет строки = unknown.
"""
import csv, os

os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))
apps = list(csv.DictReader(open('inputs/applications.csv')))
coh = [a for a in apps if a['is_test'] == '0' and '2026-10-01 00:00:00' <= a['created_at'] < '2026-10-03 00:00:00']
ids = [a['application_id'] for a in coh]
labels = list(csv.DictReader(open('inputs/fraud_labels.csv')))
hits = list(csv.DictReader(open('inputs/rule_hits.csv')))


def snap(T):
    best = {}
    for l in labels:
        if l['recorded_at'] < T:
            cur = best.get(l['application_id'])
            if cur is None or (l['recorded_at'], l['label_id']) > (cur['recorded_at'], cur['label_id']):
                best[l['application_id']] = l
    return best


print('cohort', len(ids), ids)
for T in ['2026-10-05 00:00:00', '2026-10-07 00:00:00']:
    lab = snap(T)
    nf = sum(1 for i in ids if lab.get(i, {}).get('label') == 'confirmed_fraud')
    nl = sum(1 for i in ids if lab.get(i, {}).get('label') == 'legitimate')
    print()
    print('T =', T, '| labeled', nf + nl, 'of', len(ids), '| fraud', nf, 'legit', nl,
          'unknown', len(ids) - nf - nl)
    print('per-app labels:', {i: lab.get(i, {}).get('label', '--') for i in ids})
    for r in ['R17', 'R42']:
        hit_ids = [h['application_id'] for h in hits if h['rule_id'] == r and h['application_id'] in ids]
        tp = [a for a in hit_ids if lab.get(a, {}).get('label') == 'confirmed_fraud']
        fp = [a for a in hit_ids if lab.get(a, {}).get('label') == 'legitimate']
        un = [a for a in hit_ids if a not in lab]
        prec = (len(tp) / (len(tp) + len(fp))) if (tp or fp) else None
        rec = (len(tp) / nf) if nf else None
        print(' ', r, 'hits', hit_ids, '| TP', tp, '| FP', fp, '| unknown', un,
              '| precision', prec, '| recall', rec, '| coverage', round(len(hit_ids) / len(ids), 4))
