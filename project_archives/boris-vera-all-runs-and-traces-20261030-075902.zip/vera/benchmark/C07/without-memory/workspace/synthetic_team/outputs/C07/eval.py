"""C07 — повторная оценка R17/R42 на когорте 2026-10-01..2026-10-02 (is_test=0).

Два прогона одного и того же расчёта на разных срезах знания:
  1) 2026-10-05 00:00:00 — воспроизведение исторической оценки (A001 ещё
     confirmed_fraud по L001);
  2) 2026-10-07 00:00:00 — та же когорта и правила после переклассификации
     A001 (L007, recorded_at 2026-10-06 12:00:00, legitimate).

Правила расчёта (documents/fraud_evaluation.md, documents/data_dictionary.md):
  - метка на срез T: последняя строка fraud_labels с recorded_at < T,
    при равном времени — label_id DESC; нет строки = unknown (не legitimate);
  - TP = срабатывания с confirmed_fraud, FP = срабатывания с legitimate,
    unknown не входит в TP+FP; precision = TP/(TP+FP), при нулевом
    знаменателе — не определено;
  - recall = TP / число confirmed_fraud среди размеченных заявок когорты
    (оценка на размеченной части, не по всей популяции);
  - coverage = уникальные заявки со срабатыванием / число реальных заявок
    когорты.
"""
import csv
import os

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, '..', '..', 'inputs')


def load(name):
    with open(os.path.join(DATA, name), encoding='utf-8') as f:
        return list(csv.DictReader(f))


apps = load('applications.csv')
labels = load('fraud_labels.csv')
hits = load('rule_hits.csv')

COHORT_START = '2026-10-01 00:00:00'
COHORT_END = '2026-10-03 00:00:00'
CUTOFFS = ['2026-10-05 00:00:00', '2026-10-07 00:00:00']
RULES = ['R17', 'R42']

cohort = [a for a in apps
          if a['is_test'] == '0' and COHORT_START <= a['created_at'] < COHORT_END]
ids = [a['application_id'] for a in cohort]


def snapshot_labels(T):
    """Последняя версия заключения по каждой заявке, известная на срез T."""
    best = {}
    for l in labels:
        if l['recorded_at'] < T:
            cur = best.get(l['application_id'])
            if cur is None or (l['recorded_at'], l['label_id']) > (cur['recorded_at'], cur['label_id']):
                best[l['application_id']] = l
    return best


first = snapshot_labels(CUTOFFS[0])
second = snapshot_labels(CUTOFFS[1])
changed = [i for i in ids if first.get(i, {}).get('label') != second.get(i, {}).get('label')]

rows = []
print('cohort (is_test=0, [%s, %s)): %d -> %s' % (COHORT_START, COHORT_END, len(ids), ids))
print('изменения меток между срезами:', {i: (first.get(i, {}).get('label', 'unknown'),
                                             second.get(i, {}).get('label', 'unknown'))
                                         for i in changed} or 'нет')

for T in CUTOFFS:
    lab = snapshot_labels(T)
    nf = sum(1 for i in ids if lab.get(i, {}).get('label') == 'confirmed_fraud')
    nl = sum(1 for i in ids if lab.get(i, {}).get('label') == 'legitimate')
    print('\n=== срез знания %s ===' % T)
    print('размечено %d из %d (%.1f%%): confirmed_fraud %d, legitimate %d, unknown %d'
          % (nf + nl, len(ids), 100.0 * (nf + nl) / len(ids), nf, nl, len(ids) - nf - nl))
    for r in RULES:
        hit_ids = [h['application_id'] for h in hits
                   if h['rule_id'] == r and h['application_id'] in ids]
        tp = [a for a in hit_ids if lab.get(a, {}).get('label') == 'confirmed_fraud']
        fp = [a for a in hit_ids if lab.get(a, {}).get('label') == 'legitimate']
        un = [a for a in hit_ids if a not in lab]
        prec = (len(tp) / (len(tp) + len(fp))) if (tp or fp) else None
        rec = (len(tp) / nf) if nf else None
        print(' %s: hits %s | TP %s (%d) | FP %s (%d) | unknown %s (%d) | precision %s | recall %s | coverage %d/%d = %.1f%%'
              % (r, hit_ids, tp, len(tp), fp, len(fp), un, len(un),
                 'n/a' if prec is None else '%.4f' % prec,
                 'n/a' if rec is None else '%.4f' % rec,
                 len(hit_ids), len(ids), 100.0 * len(hit_ids) / len(ids)))
        rows.append({'cutoff': T, 'rule_id': r, 'hits': ';'.join(hit_ids),
                     'tp': ';'.join(tp), 'tp_n': len(tp), 'fp': ';'.join(fp), 'fp_n': len(fp),
                     'unknown': ';'.join(un), 'unknown_n': len(un),
                     'precision': '' if prec is None else round(prec, 6),
                     'recall': '' if rec is None else round(rec, 6),
                     'coverage': round(len(hit_ids) / len(ids), 6),
                     'cohort_n': len(ids), 'labeled_n': nf + nl,
                     'confirmed_fraud_n': nf, 'legitimate_n': nl,
                     'label_change_apps': ';'.join(changed)})

with open(os.path.join(BASE, 'metrics.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    w.writeheader()
    w.writerows(rows)
print('\nmetrics.csv записан: %d строк' % len(rows))
