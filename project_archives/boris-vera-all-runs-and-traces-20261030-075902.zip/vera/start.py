"""Полный повтор опыта Веры в отдельном каталоге.

Функции: main — последовательно запускает анализ, затем память и сравнение.
Вход: соседние run.py и benchmark.py; выход: cycle-status.json и их результаты.
"""
import json
from pathlib import Path
import subprocess
import sys


def main() -> None:
    """Без аргументов запускает два этапа и сохраняет статус всего цикла.

    Возвращает None; при ошибке дочернего процесса сохраняет failed
    и повторно вызывает исключение. Модель и сценарии не заменяет.
    """
    root = Path(__file__).resolve().parent
    status = {"state": "running", "stage": "analysis"}
    path = root / "cycle-status.json"
    try:
        for stage, script in (("analysis", "run.py"), ("benchmark", "benchmark.py")):
            status["stage"] = stage
            path.write_text(json.dumps(status), encoding="utf-8")
            subprocess.run([sys.executable, "-X", "utf8", "-u", str(root / script)], check=True)
        status.update(state="completed", stage="finished")
    except BaseException as error:
        status.update(state="failed", error=f"{type(error).__name__}: {error}")
        raise
    finally:
        path.write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
