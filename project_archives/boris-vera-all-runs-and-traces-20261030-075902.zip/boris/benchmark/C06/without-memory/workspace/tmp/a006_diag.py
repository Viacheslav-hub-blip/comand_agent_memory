import csv, sys
from datetime import datetime as D

P = lambda s: D.strptime(s.strip(), "%Y-%m-%d %H:%M:%S")
BASE = "/synthetic_team/inputs/"
ev = list(csv.DictReader(open(BASE + "decision_events.csv", encoding="utf-8-sig")))
apps = list(csv.DictReader(open(BASE + "applications.csv", encoding="utf-8-sig")))
T = P("2026-10-03 00:00:00")

ev = [{**r, "occ": P(r["occurred_at"]), "load": P(r["loaded_at"]), "eid": int(r["event_id"])} for r in ev]
A6 = sorted([r for r in ev if r["application_id"] == "A006"], key=lambda r: (r["occ"], r["eid"]))
print("=== A006 raw rows ===")
for r in A6:
    print(f"  e{r['eid']:>2} {r['status']:<14} occ={r['occurred_at']}  load={r['loaded_at']}")


def as_of(app, t):
    """Воспроизведение знания на T: фильтр по произошедшему И по загруженному, затем последняя строка."""
    c = [r for r in app if r["occ"] < t and r["load"] < t]
    c.sort(key=lambda r: (r["occ"], r["eid"]), reverse=True)
    return c[0] if c else None


def naive_load_only(app, t):
    c = sorted([r for r in app if r["load"] < t], key=lambda r: r["eid"], reverse=True)
    return c[0] if c else None


def naive_occ_only(app, t):
    c = sorted([r for r in app if r["occ"] < t], key=lambda r: (r["occ"], r["eid"]), reverse=True)
    return c[0] if c else None


print("\n=== H1: событие ещё не произошло (occurred_at >= T) ? ===")
n_event9 = [r for r in A6 if r["status"] == "approved"]
for r in n_event9:
    print(f"  e{r['eid']} occurred_at={r['occurred_at']}  >= T ? {r['occ'] >= T}   <=T сдвиг={(r['occ']-T)}")
print("  => событие approve по occurred_at СТРОГО раньше T (на", T - n_event9[0]["occ"], ") -> H1 отвергнута")

print("\n=== H2: событие произошло, но не загружено на T ? ===")
for r in n_event9:
    print(f"  e{r['eid']} occurred_at<T={r['occ']<T}  loaded_at<T={r['load']<T}  лаг={(r['load']-r['occ'])}  загрузка-сдвиг={(r['load']-T)}")
print("  => occ<T True, load<T False -> H2 подтверждена")

print("\n=== H3: запрос неверно выбрал последнюю запись ? ===")
res_asof = as_of(A6, T)
res_full = as_of(A6, P("2030-01-01"))
res_load = naive_load_only(A6, T)
res_occ = naive_occ_only(A6, T)
print(f"  корректный as-of  : e{res_asof['eid']} {res_asof['status']}")
print(f"  пересчёт прошлого : e{res_full['eid']} {res_full['status']}")
print(f"  наивно только loaded_at : e{res_load['eid']} {res_load['status']}")
print(f"  наивно только occurred_at: e{res_occ['eid']} {res_occ['status']}")

print("\n=== Различители: отбор без окна среза на любом T ===")
print("  если бы записи не существовало вовсе, строка отсутствовала бы и в пересчёте.")
print(f"  строк approve в пересчёте: {len(n_event9)} -> запись существует, значит это не 'нет данных навсегда'")

print("\n=== Тай-брейк: одинаковое occurred_at внутри заявки (проверка правила порядка) ===")
from collections import defaultdict
g = defaultdict(list)
for r in ev:
    g[(r["application_id"], r["occ"])].append(r)
ties = {k: v for k, v in g.items() if len(v) > 1}
for k, v in sorted(ties.items()):
    v = sorted(v, key=lambda r: r["eid"])
    print(f"  {k[0]} occ={k[1]} -> " + ", ".join(f"e{r['eid']}={r['status']}" for r in v) + f"  | итог по правилу: {v[-1]['status']}")
if not ties:
    print("  равных occurred_at нет")
print("  A006 в списке равных времен:", any(k[0] == "A006" for k in ties))

print("\n=== Проверка, что событие не отредактировано задним числом ===")
print("  occurred_at approve =", n_event9[0]["occurred_at"], "(раньше loaded_at на", n_event9[0]["load"] - n_event9[0]["occ"], ")")
print("  если бы произошло переписывание бизнес-времени, occurred_at был бы >= loaded_at или менялся бы между снимками")

print("\n=== Прочие строки A006 / отсутствие денег и меток ===")
pay = list(csv.DictReader(open(BASE + "payments.csv", encoding="utf-8-sig")))
lab = list(csv.DictReader(open(BASE + "fraud_labels.csv", encoding="utf-8-sig")))
print("  payments по A006:", [p["payment_type"] for p in pay if p["application_id"] == "A006"] or "нет строк")
print("  fraud_labels по A006:", [(l["label"], l["recorded_at"]) for l in lab if l["application_id"] == "A006"] or "нет строк -> исход неизвестен")
app6 = next(a for a in apps if a["application_id"] == "A006")
print("  created_at:", app6["created_at"], "| lag создать->manual_review:", P("2026-10-02 09:10:00") - P(app6["created_at"]))

print("\n=== Проверка границы среза (строгое <) ===")
print("  occurred_at<T:", n_event9[0]["occ"] < T, "| loaded_at<T:", n_event9[0]["load"] < T)
