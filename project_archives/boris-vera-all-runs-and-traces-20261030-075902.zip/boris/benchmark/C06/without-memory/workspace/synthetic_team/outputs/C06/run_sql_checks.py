#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Проверяет a006_checks.sql на реальных CSV: схема sql/schema.sql -> :memory: -> запросы.

Запуск из любого места:   py -3 run_sql_checks.py
Зависимости: только стандартная библиотека (pandas не требуется).
Код возврата 1, если хотя бы один запрос упал.
"""

import csv
import os
import sqlite3
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
db = sqlite3.connect(":memory:")
db.executescript(open(os.path.join(ROOT, "sql", "schema.sql"), encoding="utf-8-sig").read())

for table in ("applications", "decision_events", "payments", "fraud_labels", "rule_hits"):
    path = os.path.join(ROOT, "inputs", table + ".csv")
    with open(path, encoding="utf-8-sig", newline="") as fh:
        rows = list(csv.reader(fh))
    head, body = rows[0], rows[1:]
    q = "INSERT INTO %s (%s) VALUES (%s)" % (table, ",".join(head), ",".join("?" * len(head)))
    db.executemany(q, body)

sql = open(os.path.join(HERE, "a006_checks.sql"), encoding="utf-8-sig").read()
stmts = []
buf = []
for line in sql.splitlines():
    s = line.strip()
    if s.startswith("--") or not s:
        continue
    buf.append(line)
    if s.endswith(";"):
        stmts.append("\n".join(buf))
        buf = []

print("statements:", len(stmts))
rc = 0
for i, st in enumerate(stmts, 1):
    print("\n===== Q%d =====" % i)
    try:
        cur = db.execute(st)
        cols = [d[0] for d in cur.description]
        rows = cur.fetchall()
        print(" | ".join(cols))
        for r in rows:
            print(" | ".join("" if v is None else str(v) for v in r))
        if not rows:
            print("(0 rows)")
    except Exception as e:
        rc = 1
        print("ERROR:", e)
        print(st[:300])
sys.exit(rc)
