-- =============================================================================
-- a006_checks.sql — SQL-проверки диагностики инцидента A006
-- Учебный снимок команды «Север», SQLite 3.49.1. Все времена UTC, формат
-- 'YYYY-MM-DD HH:MM:SS'; сравнение текстом корректно при едином формате.
--
-- Назначение: воспроизвести проверки из a006_diagnostics.py средствами SQL и
-- дать шаблон для будущих инцидентов того же класса.
--
-- Правило среза НЕ меняется:
--     occurred_at < T AND loaded_at < T
--     затем ORDER BY occurred_at DESC, event_id DESC, ранг 1.
-- Функций и процедур нет: каждый блок самостоятелен.
--
-- Импорт CSV (пример, выполнять в CLI sqlite3):
--     .mode csv
--     .import inputs/applications.csv    applications
--     .import inputs/decision_events.csv decision_events
--     .import inputs/payments.csv        payments
--     .import inputs/fraud_labels.csv    fraud_labels
--     .import inputs/rule_hits.csv       rule_hits
-- Схема: sql/schema.sql
-- =============================================================================

-- =============================================================================
-- Q1. Доступность и свежесть источников.
--     Покрывает ли снимок T и есть ли вообще строки, загруженные после T
--     (без них режим «пересчёт прошлого» ничего не добавит).
-- =============================================================================
WITH params AS (
    SELECT '2026-10-03 00:00:00' AS known_at
)
SELECT
    (SELECT COUNT(*) FROM decision_events)                AS events_total,
    (SELECT MAX(occurred_at) FROM decision_events)        AS max_occurred_at,
    (SELECT MAX(loaded_at)   FROM decision_events)        AS max_loaded_at,
    (SELECT COUNT(*) FROM decision_events, params AS p
      WHERE occurred_at > p.known_at)                     AS rows_after_t_by_business_time,
    (SELECT COUNT(*) FROM decision_events, params AS p
      WHERE loaded_at   > p.known_at)                     AS rows_after_t_by_load_time
FROM params;


-- =============================================================================
-- Q2. Инварианты данных.
--     Нарушение любого из них сделало бы «задержку загрузки» неверной
--     диагностикой: причина была бы в самих данных.
-- =============================================================================
WITH params AS (
    SELECT '2026-10-03 00:00:00' AS known_at
)
SELECT
    -- лаг не может быть отрицательным: запись не появляется до события
    (SELECT COUNT(*) FROM decision_events
      WHERE loaded_at < occurred_at)                      AS rows_loaded_before_occurred,
    -- дубли идентификатора события
    (SELECT COUNT(*) FROM (
        SELECT event_id FROM decision_events
        GROUP BY event_id HAVING COUNT(*) > 1))           AS duplicate_event_ids,
    -- строки ровно на границе: при них важен выбор строгого/нестрогого сравнения
    (SELECT COUNT(*) FROM decision_events, params AS p
      WHERE occurred_at = p.known_at)                     AS rows_exactly_at_t_occurred,
    (SELECT COUNT(*) FROM decision_events, params AS p
      WHERE loaded_at   = p.known_at)                     AS rows_exactly_at_t_loaded,
    -- осиротевшие события (FK не включён по умолчанию в SQLite)
    (SELECT COUNT(*) FROM decision_events d
      LEFT JOIN applications a ON a.application_id = d.application_id
      WHERE a.application_id IS NULL)                     AS orphan_events
FROM params;


-- =============================================================================
-- Q3. Ключевая проверка: у скольких заявок as-of T расходится с пересчётом.
--     Локализация «до записей», а не «вообще».
-- =============================================================================
WITH params AS (
    SELECT '2026-10-03 00:00:00' AS known_at
),
as_of AS (
    SELECT application_id, event_id, status, occurred_at, loaded_at
    FROM (
        SELECT d.*,
               ROW_NUMBER() OVER (
                   PARTITION BY d.application_id
                   ORDER BY d.occurred_at DESC, d.event_id DESC
               ) AS rn
        FROM decision_events AS d
        CROSS JOIN params AS p
        WHERE d.occurred_at < p.known_at
          AND d.loaded_at  < p.known_at
    ) WHERE rn = 1
),
recalc AS (
    SELECT application_id, event_id, status, occurred_at, loaded_at
    FROM (
        SELECT d.*,
               ROW_NUMBER() OVER (
                   PARTITION BY d.application_id
                   ORDER BY d.occurred_at DESC, d.event_id DESC
               ) AS rn
        FROM decision_events AS d
    ) WHERE rn = 1
)
SELECT
    a.application_id,
    a.event_id  AS as_of_event_id,
    a.status    AS as_of_status,
    r.event_id  AS recalc_event_id,
    r.status    AS recalc_status,
    CASE
        WHEN r.occurred_at >= p.known_at THEN 'H1: событие после T'
        WHEN r.loaded_at   >= p.known_at THEN 'H2: поздняя загрузка'
        ELSE 'H3: иное / проверить выбор строки'
    END AS reason
FROM recalc AS r
JOIN as_of  AS a ON a.application_id = r.application_id
CROSS JOIN params AS p
WHERE a.event_id <> r.event_id
ORDER BY a.application_id;


-- =============================================================================
-- Q4. Границы допущения H2: запись существует, лаг конечен.
--     Показывает отсечённые на T строки — то есть те, что «опоздали», а не
--     отсутствуют навсегда.
-- =============================================================================
WITH params AS (
    SELECT '2026-10-03 00:00:00' AS known_at
)
SELECT
    d.event_id,
    d.application_id,
    d.status,
    d.occurred_at,
    d.loaded_at,
    ROUND((julianday(d.loaded_at) - julianday(d.occurred_at)) * 24, 2) AS ingest_lag_hours,
    ROUND((julianday(d.loaded_at) - julianday(p.known_at))  * 24, 2)   AS loaded_after_t_hours
FROM decision_events AS d
CROSS JOIN params AS p
WHERE d.occurred_at <  p.known_at
  AND d.loaded_at  >= p.known_at
ORDER BY d.application_id, d.event_id;


-- =============================================================================
-- Q5. Сравнение вариантов выбора последней строки (проверка H3).
--     Если бы запрос ошибался в выборе строки, варианты расходились бы между
--     собой. Каждый вариант строится на СВОЁМ наборе строк: у вариантов разный
--     фильтр, поэтому общий CTE дал бы ложное совпадение.
--       correct      : occurred_at < T AND loaded_at < T   (правило словаря)
--       occurred_only: только occurred_at < T              (нарушитель: игнор загрузки)
--       loaded_only  : только loaded_at  < T               (нарушитель: игнор бизнес-времени)
--       event_id_only: тот же фильтр, но порядок по event_id
-- =============================================================================
WITH params AS (
    SELECT '2026-10-03 00:00:00' AS known_at
),
v_correct AS (
    SELECT application_id, event_id, status FROM (
        SELECT d.*, ROW_NUMBER() OVER (PARTITION BY d.application_id
                                       ORDER BY d.occurred_at DESC, d.event_id DESC) AS rn
        FROM decision_events AS d CROSS JOIN params AS p
        WHERE d.occurred_at < p.known_at AND d.loaded_at < p.known_at
    ) WHERE rn = 1
),
v_occurred_only AS (
    SELECT application_id, event_id, status FROM (
        SELECT d.*, ROW_NUMBER() OVER (PARTITION BY d.application_id
                                       ORDER BY d.occurred_at DESC, d.event_id DESC) AS rn
        FROM decision_events AS d CROSS JOIN params AS p
        WHERE d.occurred_at < p.known_at
    ) WHERE rn = 1
),
v_loaded_only AS (
    SELECT application_id, event_id, status FROM (
        SELECT d.*, ROW_NUMBER() OVER (PARTITION BY d.application_id
                                       ORDER BY d.loaded_at DESC, d.event_id DESC) AS rn
        FROM decision_events AS d CROSS JOIN params AS p
        WHERE d.loaded_at < p.known_at
    ) WHERE rn = 1
),
v_event_id_only AS (
    SELECT application_id, event_id, status FROM (
        SELECT d.*, ROW_NUMBER() OVER (PARTITION BY d.application_id
                                       ORDER BY d.event_id DESC) AS rn
        FROM decision_events AS d CROSS JOIN params AS p
        WHERE d.occurred_at < p.known_at AND d.loaded_at < p.known_at
    ) WHERE rn = 1
)
SELECT
    c.application_id,
    c.event_id || ' ' || c.status AS correct_as_of,
    o.event_id || ' ' || o.status AS occurred_at_only,
    l.event_id || ' ' || l.status AS loaded_at_only,
    i.event_id || ' ' || i.status AS event_id_only,
    CASE WHEN c.event_id = o.event_id
          AND c.event_id = l.event_id
          AND c.event_id = i.event_id
         THEN 'все совпали' ELSE 'РАСХОЖДЕНИЕ' END AS verdict
FROM v_correct AS c
LEFT JOIN v_occurred_only AS o ON o.application_id = c.application_id
LEFT JOIN v_loaded_only   AS l ON l.application_id = c.application_id
LEFT JOIN v_event_id_only AS i ON i.application_id = c.application_id
ORDER BY c.application_id;


-- =============================================================================
-- Q6. Чувствительность к тай-брейку: группы с одинаковым occurred_at.
--     На A006 таких групп нет, но на A007 выбор event_id DESC решает исход
--     (approved vs rejected при одном и том же occurred_at).
-- =============================================================================
SELECT
    application_id,
    occurred_at,
    COUNT(*)                                   AS rows_in_group,
    GROUP_CONCAT(event_id || '=' || status, ' | ') AS members,
    MAX(event_id)                              AS tiebreak_picks_event_id
FROM decision_events
GROUP BY application_id, occurred_at
HAVING COUNT(*) > 1
ORDER BY application_id, occurred_at;


-- =============================================================================
-- Q7. Бизнес-проверка vs задержка загрузки и vs наивная складская разница.
--     Длительность бизнеса считается только по occurred_at.
-- =============================================================================
WITH first_event AS (
    SELECT application_id, occurred_at, loaded_at
    FROM (
        SELECT d.*, ROW_NUMBER() OVER (PARTITION BY application_id
                                       ORDER BY occurred_at ASC, event_id ASC) AS rn
        FROM decision_events AS d
    ) WHERE rn = 1
),
last_event AS (
    SELECT application_id, occurred_at, loaded_at
    FROM (
        SELECT d.*, ROW_NUMBER() OVER (PARTITION BY application_id
                                       ORDER BY occurred_at DESC, event_id DESC) AS rn
        FROM decision_events AS d
    ) WHERE rn = 1
)
SELECT
    f.application_id,
    ROUND((julianday(l.occurred_at) - julianday(f.occurred_at)) * 24, 2) AS business_hours,
    ROUND((julianday(l.loaded_at)   - julianday(l.occurred_at)) * 24, 2) AS ingest_lag_hours,
    ROUND((julianday(l.loaded_at)   - julianday(f.loaded_at))   * 24, 2) AS naive_warehouse_hours
FROM first_event AS f
JOIN last_event  AS l ON l.application_id = f.application_id
WHERE f.application_id = 'A006';


-- =============================================================================
-- Q8. Смежное по A006: что статус НЕ означает.
--     approved != метка фрода и != выдача денег; отсутствие метки != legitimate.
-- =============================================================================
SELECT 'payments_for_A006' AS check_name,
       COALESCE(GROUP_CONCAT(payment_id || ':' || payment_type, ', '), 'нет строк') AS detail
FROM payments WHERE application_id = 'A006'
UNION ALL
SELECT 'fraud_labels_for_A006',
       COALESCE(GROUP_CONCAT(label_id || ':' || label || '@' || recorded_at, ', '),
                'нет строк -> исход НЕИЗВЕСТЕН')
FROM fraud_labels WHERE application_id = 'A006'
UNION ALL
SELECT 'rule_hits_for_A006',
       COALESCE(GROUP_CONCAT(rule_id || '@' || hit_at, ', '), 'нет срабатываний')
FROM rule_hits WHERE application_id = 'A006'
UNION ALL
SELECT 'earliest_label_in_base',
       COALESCE(MIN(recorded_at), 'меток нет')
FROM fraud_labels;
