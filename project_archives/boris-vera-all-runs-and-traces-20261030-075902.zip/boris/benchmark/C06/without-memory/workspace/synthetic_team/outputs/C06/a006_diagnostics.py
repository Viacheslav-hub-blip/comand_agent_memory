#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
a006_diagnostics.py — диагностика инцидента A006 (исторический отчёт vs пересчёт прошлого).

Запуск:
    python3 a006_diagnostics.py [--root ../..] [--at "2026-10-03 00:00:00"] [--app A006]

Зависимости: только стандартная библиотека (csv, argparse, datetime).
pandas здесь намеренно не используется: скрипт общий, коллегам не нужно
доставлять ничего дополнительно. Если вам лично удобнее pandas — переписывать
этот файл под себя не требуется.

Выход: отчёт в stdout, код возврата 1 при провале любой проверки.
Правило среза НЕ меняется: occurred_at < T AND loaded_at < T,
затем ORDER BY occurred_at DESC, event_id DESC, ранг 1.
"""

import argparse
import csv
import os
import sys
from collections import defaultdict
from datetime import datetime

FMT = "%Y-%m-%d %H:%M:%S"
EVENTS = "decision_events.csv"
APPS = "applications.csv"
PAYMENTS = "payments.csv"
LABELS = "fraud_labels.csv"
HITS = "rule_hits.csv"

failures = []


def ts(value):
    """Разбор бизнес-времени. Пустое/битое значение — ошибка данных, не тихий None."""
    if value is None or not str(value).strip():
        raise ValueError("пустое значение времени")
    return datetime.strptime(str(value).strip(), FMT)


def load(root, name):
    """Читает CSV из inputs. Возвращает None, если файла нет (источник недоступен)."""
    path = os.path.join(root, "inputs", name)
    if not os.path.exists(path):
        return None
    # utf-8-sig: CSV команды в UTF-8, BOM допускаем
    with open(path, encoding="utf-8-sig", newline="") as fh:
        return list(csv.DictReader(fh))


def load_events(root):
    rows = load(root, EVENTS)
    if rows is None:
        return None
    out = []
    for r in rows:
        out.append({
            "event_id": int(r["event_id"]),
            "application_id": r["application_id"].strip(),
            "status": r["status"].strip(),
            "occurred_at": ts(r["occurred_at"]),
            "loaded_at": ts(r["loaded_at"]),
        })
    return out


def pick_last(rows, key):
    """Последняя строка по ключу. Пустой вход -> None (а не исключение)."""
    if not rows:
        return None
    return sorted(rows, key=key, reverse=True)[0]


def state_as_of(rows, t):
    """Штатный режим: знание на момент T."""
    return pick_last([r for r in rows if r["occurred_at"] < t and r["loaded_at"] < t],
                     lambda r: (r["occurred_at"], r["event_id"]))


def state_recalc(rows):
    """Пересчёт прошлого: все загруженные события, без окна по T."""
    return pick_last(rows, lambda r: (r["occurred_at"], r["event_id"]))


def section(title):
    print()
    print(title)
    print("-" * len(title))


def check(label, ok, detail=""):
    mark = "ok  " if ok else "FAIL"
    if not ok:
        failures.append(label)
    print("  [%s] %-46s %s" % (mark, label, detail))


def fmt_delta(delta):
    total = int(delta.total_seconds())
    sign = "-" if total < 0 else ""
    total = abs(total)
    return "%s%dd %02dh %02dm %02ds" % (sign, total // 86400, total % 86400 // 3600,
                                        total % 3600 // 60, total % 60)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
    ap.add_argument("--at", default="2026-10-03 00:00:00", help="граница среза T (UTC)")
    ap.add_argument("--app", default="A006")
    args = ap.parse_args()

    root = os.path.abspath(args.root)
    t = ts(args.at)
    app = args.app

    print("=" * 74)
    print("Диагностика инцидента: заявка %s, граница T = %s UTC" % (app, args.at))
    print("Корень данных: %s" % root)
    print("=" * 74)

    # ---------------------------------------------------------------- Шаг 1
    section("Шаг 1. Доступность и свежесть источников")
    events = load_events(root)
    apps = load(root, APPS)
    payments = load(root, PAYMENTS)
    labels = load(root, LABELS)
    hits = load(root, HITS)

    check("decision_events.csv доступен", events is not None)
    if events is None:
        print("\nИсточник decision_events недоступен — разбор невозможен.")
        return 1
    print("        строк: %d" % len(events))
    for name, rows in ((APPS, apps), (PAYMENTS, payments), (LABELS, labels), (HITS, hits)):
        check("%s доступен" % name, rows is not None,
              "" if rows is None else "строк: %d" % len(rows))

    # Свежесть: докуда доходит хранилище. Нужна, чтобы понимать, покрывает ли
    # снимок момент T и есть ли вообще поздние строки для режима пересчёта.
    occ_max = max(r["occurred_at"] for r in events)
    load_max = max(r["loaded_at"] for r in events)
    print("        max(occurred_at) = %s" % occ_max)
    print("        max(loaded_at)   = %s" % load_max)
    check("снимок покрывает T", occ_max > t,
          "иначе пересчёт нечего добавлять")
    check("есть строки, загруженные после T", load_max > t)

    # ---------------------------------------------------------- инварианты
    section("Инварианты данных (иначе причина может быть в самих данных)")
    check("loaded_at >= occurred_at во всех строках",
          all(r["loaded_at"] >= r["occurred_at"] for r in events),
          "нарушений: %d" % sum(1 for r in events if r["loaded_at"] < r["occurred_at"]))
    ids = [r["event_id"] for r in events]
    check("event_id уникален", len(ids) == len(set(ids)),
          "дублей: %d" % (len(ids) - len(set(ids))))
    on_boundary = [r for r in events if r["occurred_at"] == t or r["loaded_at"] == t]
    check("нет строк ровно на границе T", not on_boundary,
          "строк: %d (иначе важен выбор < vs <=)" % len(on_boundary))

    # is_test: по reporting_v2 тестовые заявки исключаются из числителя и знаменателя.
    # Если спорная заявка тестовая, её нельзя обсуждать в терминах бизнес-метрики.
    if apps:
        meta = {r["application_id"].strip(): r for r in apps}
        row = meta.get(app)
        if row is not None:
            check("разбираемая заявка не тестовая (is_test=0)", row["is_test"].strip() == "0",
                  "%s is_test=%s" % (app, row["is_test"]))
        else:
            check("заявка есть в applications", False, "%s отсутствует" % app)

    # ---------------------------------------------------------------- Шаг 2
    section("Шаг 2. Локализация: где именно расходятся режимы")
    by_app = defaultdict(list)
    for r in events:
        by_app[r["application_id"]].append(r)

    diffs = []
    for aid in sorted(by_app):
        a = state_as_of(by_app[aid], t)
        b = state_recalc(by_app[aid])
        sa = "e%d %s" % (a["event_id"], a["status"]) if a else "NULL"
        sb = "e%d %s" % (b["event_id"], b["status"]) if b else "NULL"
        if sa != sb:
            diffs.append(aid)
        print("  %-6s as-of=%-18s recalc=%-18s %s" % (aid, sa, sb, "<-- DIFFERS" if sa != sb else ""))
    check("расхождение локализовано, а не «вообще»", bool(diffs), "заявки: %s" % (", ".join(diffs) or "нет"))

    app_rows = sorted(by_app.get(app, []), key=lambda r: (r["occurred_at"], r["event_id"]))
    section("История %s (оба времени и лаг загрузки)" % app)
    for r in app_rows:
        print("  e%-3d %-14s occurred_at=%s  loaded_at=%s  lag=%s" % (
            r["event_id"], r["status"], r["occurred_at"], r["loaded_at"],
            fmt_delta(r["loaded_at"] - r["occurred_at"])))
    late = [r for r in app_rows if r["occurred_at"] < t <= r["loaded_at"]]
    for r in late:
        print("  отсекается на T: e%d, occurred_at < T, но loaded_at - T = %s"
              % (r["event_id"], fmt_delta(r["loaded_at"] - t)))

    # ---------------------------------------------------------------- Шаг 3
    section("Шаг 3. Длительность бизнес-проверки vs задержка загрузки")
    if len(app_rows) >= 2:
        first, last = app_rows[0], app_rows[-1]
        business = last["occurred_at"] - first["occurred_at"]
        lag = last["loaded_at"] - last["occurred_at"]
        naive = last["loaded_at"] - first["loaded_at"]
        print("  бизнес-проверка  occurred_at(e%d) - occurred_at(e%d) = %s"
              % (last["event_id"], first["event_id"], fmt_delta(business)))
        print("  лаг загрузки     loaded_at - occurred_at            = %s" % fmt_delta(lag))
        print("  наивно по складу loaded_at(e%d) - loaded_at(e%d)     = %s  (искажена)"
              % (last["event_id"], first["event_id"], fmt_delta(naive)))
        check("величины различаются (лаг не подменяет бизнес)", business != naive)

    # ---------------------------------------------------------------- Шаг 4
    section("Шаг 4. Альтернативные причины (H1 / H2 / H3)")
    target = pick_last(app_rows, lambda r: (r["occurred_at"], r["event_id"]))
    if target is None:
        check("у заявки есть события", False)
    else:
        h1 = target["occurred_at"] >= t
        h2 = target["occurred_at"] < t <= target["loaded_at"]
        print("  проверяемая строка: e%d %s" % (target["event_id"], target["status"]))
        # Внимание: метка ok/FAIL относится к факту проверки, а ВЕРДИКТ гипотезы
        # написан в тексте строки. "H1 отклонена" + ok = проверка выполнена и H1 не проходит.
        check("H1 ОТКЛОНЕНА (occurred_at < T, событие уже произошло)", not h1,
              "occurred_at=%s, на %s раньше T" % (target["occurred_at"],
                                                  fmt_delta(t - target["occurred_at"])))
        check("H2 ПОДТВЕРЖДЕНА (occurred_at < T <= loaded_at)", h2,
              "loaded_at опоздал на %s относительно T" % fmt_delta(target["loaded_at"] - t))

        # H2 не должна означать «данных нет навсегда»
        same = [r for r in app_rows if r["status"] == target["status"]]
        check("запись существует в снимке (не потеряна)", bool(same),
              "строк с этим статусом: %d" % len(same))
        check("лаг загрузки конечен", (target["loaded_at"] - target["occurred_at"]).total_seconds() < 7 * 86400,
              fmt_delta(target["loaded_at"] - target["occurred_at"]))

        # H3: варианты выбора последней строки
        g = app_rows
        variants = [
            ("as-of (occ<T AND load<T)", state_as_of(g, t)),
            ("пересчёт (без окна)", state_recalc(g)),
            ("только loaded_at", pick_last([r for r in g if r["loaded_at"] < t],
                                           lambda r: (r["loaded_at"], r["event_id"]))),
            ("только occurred_at", pick_last([r for r in g if r["occurred_at"] < t],
                                             lambda r: (r["occurred_at"], r["event_id"]))),
            ("только event_id DESC", pick_last([r for r in g if r["occurred_at"] < t and r["loaded_at"] < t],
                                               lambda r: (r["event_id"],))),
        ]
        for name, v in variants:
            print("        %-28s -> %s" % (name, "e%d %s" % (v["event_id"], v["status"]) if v else "NULL"))
        asof = variants[0][1]
        agree = [n for n, v in variants if v is not None and v["event_id"] == asof["event_id"]]
        check("H3 отклонена: корректные варианты дают один ответ",
              len(agree) >= 2 and asof["event_id"] == variants[4][1]["event_id"],
              "совпали: %s" % ", ".join(agree))

    # Тай-брейк: чувствительность к равному occurred_at
    ties = defaultdict(list)
    for aid, rows in by_app.items():
        for r in rows:
            ties[(aid, r["occurred_at"])].append(r)
    tie_groups = {k: sorted(v, key=lambda r: r["event_id"]) for k, v in ties.items() if len(v) > 1}
    print("  группы с равным occurred_at: %d" % len(tie_groups))
    for k in sorted(tie_groups, key=lambda x: (x[0], x[1])):
        v = tie_groups[k]
        print("        %s occ=%s -> %s | event_id DESC выбирает e%d %s" % (
            k[0], k[1], ", ".join("e%d=%s" % (r["event_id"], r["status"]) for r in v),
            v[-1]["event_id"], v[-1]["status"]))
    check("тай-брейк не влияет на разбираемую заявку",
          not any(k[0] == app for k in tie_groups),
          "у %s групп с равным occurred_at нет" % app if not any(k[0] == app for k in tie_groups) else "влияет")

    # Контроль: в том же файле должна быть заявка с ДРУГОЙ причиной (H1),
    # иначе H1 и H2 нечем различить.
    h1_examples = [aid for aid in sorted(by_app)
                   if state_as_of(by_app[aid], t) and state_recalc(by_app[aid])
                   and state_as_of(by_app[aid], t)["event_id"] != state_recalc(by_app[aid])["event_id"]
                   and state_recalc(by_app[aid])["occurred_at"] >= t]
    check("есть контрольный пример H1 (событие после T)", bool(h1_examples),
          "заявки: %s" % (", ".join(h1_examples) or "нет"))

    # ---------------------------------------------------------------- Шаг 5
    section("Шаг 5. Смежные таблицы: что статус НЕ означает")
    if payments is not None:
        p = [r for r in payments if r["application_id"] == app]
        print("  payments: %s" % (("%d строк: %s" % (len(p), ", ".join(
            "%s %s %s" % (r["payment_id"], r["payment_type"], r["booked_at"]) for r in p)))
            if p else "нет строк -> одобрение не сопровождалось выдачей"))
    if labels is not None:
        l = sorted([r for r in labels if r["application_id"] == app], key=lambda r: r["recorded_at"])
        print("  fraud_labels: %s" % ((", ".join("%s %s @%s" % (r["label_id"], r["label"], r["recorded_at"])
                                                for r in l)) if l else "нет строк -> исход НЕИЗВЕСТЕН (не legitimate)"))
        earliest = min((ts(r["recorded_at"]) for r in labels), default=None)
        if earliest:
            print("  самая ранняя метка в базе: %s (метки на T: %s)"
                  % (earliest, "есть" if earliest < t else "отсутствуют"))
    if hits is not None:
        h = [r for r in hits if r["application_id"] == app]
        print("  rule_hits: %s" % ((", ".join("%s @%s" % (r["rule_id"], r["hit_at"]) for r in h))
                                   if h else "нет срабатываний"))
        for r in h:
            print("     -> срабатывание правила = триггер, не решение и не фрод")

    print()
    print("=" * 74)
    if failures:
        print("ИТОГ: провалено проверок — %d: %s" % (len(failures), "; ".join(failures)))
        return 1
    print("ИТОГ: все проверки пройдены.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
