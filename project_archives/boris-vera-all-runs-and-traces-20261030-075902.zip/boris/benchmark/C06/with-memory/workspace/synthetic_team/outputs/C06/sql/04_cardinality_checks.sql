-- 04_cardinality_checks.sql
-- Обязательные проверки кардинальности для среза C06 на T = 2026-10-03 00:00:00.
-- CHECK 01, 02, 03, 05 должны дать PASS; CHECK 04 (негативный контроль на наивном
-- JOIN) обязан показать размножение строк и пометить это как PASS_DETECTED —
-- проверка чувствительна только если наивное соединение действительно ломается.
WITH params AS (
    SELECT '2026-10-01 00:00:00' AS cohort_start_at,
           '2026-10-03 00:00:00' AS cohort_end_at,
           '2026-10-03 00:00:00' AS known_at
),
cohort AS (
    SELECT a.application_id
    FROM applications AS a
    CROSS JOIN params AS p
    WHERE a.created_at >= p.cohort_start_at
      AND a.created_at <  p.cohort_end_at
),
events_known_a AS (
    SELECT d.application_id, d.event_id, d.status, d.occurred_at
    FROM decision_events AS d
    CROSS JOIN params AS p
    WHERE d.occurred_at < p.known_at
      AND d.loaded_at  < p.known_at
),
events_known_b AS (
    SELECT d.application_id, d.event_id, d.status, d.occurred_at
    FROM decision_events AS d
    CROSS JOIN params AS p
    WHERE d.occurred_at < p.known_at
),
slice_a AS (
    SELECT application_id, status, event_id
    FROM (
        SELECT e.application_id, e.status, e.event_id,
               ROW_NUMBER() OVER (
                   PARTITION BY e.application_id
                   ORDER BY e.occurred_at DESC, e.event_id DESC
               ) AS rn
        FROM events_known_a AS e
    )
    WHERE rn = 1
),
slice_b AS (
    SELECT application_id, status, event_id
    FROM (
        SELECT e.application_id, e.status, e.event_id,
               ROW_NUMBER() OVER (
                   PARTITION BY e.application_id
                   ORDER BY e.occurred_at DESC, e.event_id DESC
               ) AS rn
        FROM events_known_b AS e
    )
    WHERE rn = 1
),
counts AS (
    SELECT (SELECT COUNT(*) FROM cohort)                      AS cohort_rows,
           (SELECT COUNT(DISTINCT application_id) FROM cohort) AS cohort_distinct,
           (SELECT COUNT(*) FROM slice_a)                      AS slice_a_rows,
           (SELECT COUNT(DISTINCT application_id) FROM slice_a) AS slice_a_distinct,
           (SELECT COUNT(*) FROM slice_b)                      AS slice_b_rows,
           (SELECT COUNT(DISTINCT application_id) FROM slice_b) AS slice_b_distinct,
           (SELECT COUNT(*) FROM cohort AS c
              LEFT JOIN slice_a AS s ON s.application_id = c.application_id) AS joined_rows_a,
           (SELECT COUNT(*) FROM cohort AS c
              LEFT JOIN slice_b AS s ON s.application_id = c.application_id) AS joined_rows_b,
           (SELECT COUNT(*) FROM applications AS a
              JOIN decision_events AS d ON d.application_id = a.application_id) AS naive_join_rows,
           (SELECT COUNT(*) FROM applications)                     AS applications_rows,
           (SELECT COUNT(*) - COUNT(DISTINCT event_id)
              FROM decision_events)                                AS dup_event_id,
           (SELECT COUNT(*) - COUNT(DISTINCT application_id)
              FROM applications)                                   AS dup_application_id,
           (SELECT COUNT(*)
              FROM decision_events AS d
              LEFT JOIN applications AS a
                     ON a.application_id = d.application_id
             WHERE a.application_id IS NULL)                       AS orphan_events
)
SELECT 'CHECK 01 slice A 1:1' AS check_name,
       slice_a_rows || ' rows / ' || slice_a_distinct || ' applications' AS observed,
       CASE WHEN slice_a_rows = slice_a_distinct THEN 'PASS' ELSE 'FAIL' END AS status
FROM counts
UNION ALL
SELECT 'CHECK 02 slice B 1:1',
       slice_b_rows || ' rows / ' || slice_b_distinct || ' applications',
       CASE WHEN slice_b_rows = slice_b_distinct THEN 'PASS' ELSE 'FAIL' END
FROM counts
UNION ALL
SELECT 'CHECK 03 LEFT JOIN keeps cohort size',
       joined_rows_a || ' / ' || joined_rows_b || ' rows vs cohort ' || cohort_rows,
       CASE WHEN joined_rows_a = cohort_rows
             AND joined_rows_b = cohort_rows THEN 'PASS' ELSE 'FAIL' END
FROM counts
UNION ALL
SELECT 'CHECK 04 negative control naive JOIN',
       naive_join_rows || ' rows on ' || applications_rows || ' applications',
       CASE WHEN naive_join_rows > applications_rows
            THEN 'PASS_DETECTED' ELSE 'FAIL_NOT_SENSITIVE' END
FROM counts
UNION ALL
SELECT 'CHECK 05 keys and orphans',
       'dup_app=' || dup_application_id
       || ', dup_event=' || dup_event_id
       || ', orphan_events=' || orphan_events,
       CASE WHEN dup_application_id = 0
             AND dup_event_id = 0
             AND orphan_events = 0 THEN 'PASS' ELSE 'FAIL' END
FROM counts;
