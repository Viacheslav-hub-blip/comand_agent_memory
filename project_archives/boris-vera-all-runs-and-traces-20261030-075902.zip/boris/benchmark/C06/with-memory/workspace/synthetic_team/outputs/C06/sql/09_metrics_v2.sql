-- 09_metrics_v2.sql
-- Метрики по соглашению отчётности v2 (утверждено руководителем аналитики 2026-10-06).
-- Обязательное сопровождение каждой доли: числитель, знаменатель, период когорты,
-- дата среза, версия определения.
-- v2: is_test=1 исключается и из числителя, и из знаменателя approval_rate.
-- final_decision_approval_rate = approved / (approved + rejected) — отдельная метрика,
-- она НЕ заменяет approval_rate.
WITH params AS (
    SELECT '2026-10-01 00:00:00' AS cohort_start_at,
           '2026-10-03 00:00:00' AS cohort_end_at,
           '2026-10-03 00:00:00' AS known_at
),
cohort AS (
    SELECT a.application_id,
           a.created_at,
           a.is_test
    FROM applications AS a
    CROSS JOIN params AS p
    WHERE a.created_at >= p.cohort_start_at
      AND a.created_at <  p.cohort_end_at
),
events_known AS (
    SELECT d.application_id,
           d.event_id,
           d.status,
           d.occurred_at,
           d.loaded_at,
           ROW_NUMBER() OVER (
               PARTITION BY d.application_id
               ORDER BY d.occurred_at DESC, d.event_id DESC
           ) AS rn
    FROM decision_events AS d
    CROSS JOIN params AS p
    WHERE d.occurred_at < p.known_at
      AND d.loaded_at  < p.known_at
),
state_at_cutoff AS (
    SELECT application_id,
           status AS status_at_cutoff
    FROM events_known
    WHERE rn = 1
),
joined AS (
    SELECT c.application_id,
           c.is_test,
           s.status_at_cutoff
    FROM cohort AS c
    LEFT JOIN state_at_cutoff AS s
           ON s.application_id = c.application_id
)
SELECT 'approval_rate_v2' AS metric,
       'v2' AS definition_version,
       '2026-10-01 00:00:00 .. 2026-10-03 00:00:00' AS cohort_period,
       '2026-10-03 00:00:00' AS cutoff_at,
       SUM(CASE WHEN status_at_cutoff = 'approved' THEN 1 ELSE 0 END) AS numerator,
       COUNT(*)                                                       AS denominator,
       ROUND(1.0 * SUM(CASE WHEN status_at_cutoff = 'approved' THEN 1 ELSE 0 END)
             / COUNT(*), 4)                                           AS ratio
FROM joined
WHERE is_test = 0
UNION ALL
SELECT 'final_decision_approval_rate',
       'v2',
       '2026-10-01 00:00:00 .. 2026-10-03 00:00:00',
       '2026-10-03 00:00:00',
       SUM(CASE WHEN status_at_cutoff = 'approved' THEN 1 ELSE 0 END),
       SUM(CASE WHEN status_at_cutoff IN ('approved', 'rejected') THEN 1 ELSE 0 END),
       ROUND(1.0 * SUM(CASE WHEN status_at_cutoff = 'approved' THEN 1 ELSE 0 END)
             / NULLIF(SUM(CASE WHEN status_at_cutoff IN ('approved', 'rejected') THEN 1 ELSE 0 END), 0), 4)
FROM joined
WHERE is_test = 0;

-- Разбивка по статусам: показывает, из чего складываются числитель и знаменатель.
WITH params AS (
    SELECT '2026-10-01 00:00:00' AS cohort_start_at,
           '2026-10-03 00:00:00' AS cohort_end_at,
           '2026-10-03 00:00:00' AS known_at
),
cohort AS (
    SELECT a.application_id
    FROM applications AS a CROSS JOIN params AS p
    WHERE a.created_at >= p.cohort_start_at
      AND a.created_at <  p.cohort_end_at
      AND a.is_test = 0
),
events_known AS (
    SELECT d.application_id, d.status,
           ROW_NUMBER() OVER (
               PARTITION BY d.application_id
               ORDER BY d.occurred_at DESC, d.event_id DESC
           ) AS rn
    FROM decision_events AS d CROSS JOIN params AS p
    WHERE d.occurred_at < p.known_at AND d.loaded_at < p.known_at
)
SELECT COALESCE(e.status, 'no_known_event') AS status_at_cutoff,
       COUNT(*)                             AS applications
FROM cohort AS c
LEFT JOIN events_known AS e
       ON e.application_id = c.application_id
      AND e.rn = 1
GROUP BY COALESCE(e.status, 'no_known_event')
ORDER BY applications DESC, status_at_cutoff;
