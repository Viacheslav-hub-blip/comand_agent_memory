-- 07_a006_timeline.sql
-- Временная линия A006 и разделение двух разных величин:
--   1) длительность бизнес-проверки — по occurred_at (бизнес-время);
--   2) задержка загрузки — по разнице loaded_at - occurred_at.
-- Подмена одной величины другой недопустима.
WITH params AS (
    SELECT '2026-10-03 00:00:00' AS known_at
),
a006 AS (
    SELECT a.application_id,
           a.created_at,
           a.requested_amount_rub,
           a.is_test,
           a.channel
    FROM applications AS a
    WHERE a.application_id = 'A006'
)
SELECT t.step_no,
       t.step_name,
       t.at_utc,
       t.source_column,
       t.relation_to_cutoff
FROM (
    SELECT 1 AS step_no,
           'application registered' AS step_name,
           x.created_at             AS at_utc,
           'applications.created_at' AS source_column,
           CASE WHEN x.created_at < p.known_at THEN 'before T' ELSE 'at/after T' END AS relation_to_cutoff
    FROM a006 AS x CROSS JOIN params AS p
    UNION ALL
    SELECT 2, 'manual_review occurred', d.occurred_at, 'decision_events.occurred_at (event_id=8)',
           CASE WHEN d.occurred_at < p.known_at THEN 'before T' ELSE 'at/after T' END
    FROM decision_events AS d CROSS JOIN params AS p
    WHERE d.application_id = 'A006' AND d.event_id = 8
    UNION ALL
    SELECT 3, 'manual_review loaded', d.loaded_at, 'decision_events.loaded_at (event_id=8)',
           CASE WHEN d.loaded_at < p.known_at THEN 'before T' ELSE 'at/after T' END
    FROM decision_events AS d CROSS JOIN params AS p
    WHERE d.application_id = 'A006' AND d.event_id = 8
    UNION ALL
    SELECT 4, 'approved occurred', d.occurred_at, 'decision_events.occurred_at (event_id=9)',
           CASE WHEN d.occurred_at < p.known_at THEN 'before T' ELSE 'at/after T' END
    FROM decision_events AS d CROSS JOIN params AS p
    WHERE d.application_id = 'A006' AND d.event_id = 9
    UNION ALL
    SELECT 5, 'approved loaded', d.loaded_at, 'decision_events.loaded_at (event_id=9)',
           CASE WHEN d.loaded_at < p.known_at THEN 'before T' ELSE 'at/after T' END
    FROM decision_events AS d CROSS JOIN params AS p
    WHERE d.application_id = 'A006' AND d.event_id = 9
) AS t
ORDER BY t.step_no;

-- Ключевые интервалы A006.
SELECT ROUND((julianday(approved.occurred_at) - julianday(review.occurred_at)) * 24, 3) AS business_review_hours,
       ROUND((julianday(approved.loaded_at)   - julianday(approved.occurred_at)) * 24, 3) AS load_lag_hours,
       ROUND((julianday(approved.loaded_at)   - julianday(review.occurred_at)) * 24, 3)  AS occurred_to_loaded_span_hours,
       approved.occurred_at AS approved_occurred_at,
       approved.loaded_at   AS approved_loaded_at
FROM decision_events AS review
CROSS JOIN decision_events AS approved
WHERE review.application_id   = 'A006' AND review.event_id   = 8
  AND approved.application_id = 'A006' AND approved.event_id = 9;
