-- 06_tiebreak_check.sql
-- Проверка tie-break: при равных occurred_at у одной заявки выбор версии
-- обязан быть детерминированным через event_id DESC.
-- Ожидается: A007, occurred_at = 2026-10-02 10:10:00, event_id 10 (approved) и 11 (rejected);
-- верным считается event_id=11 (rejected) — более позднее событие в порядке источника.
-- Без ORDER BY event_id DESC результат недетерминирован.
SELECT d.application_id,
       d.occurred_at,
       COUNT(*)                      AS events_at_same_time,
       MIN(d.event_id)               AS min_event_id,
       MAX(d.event_id)               AS max_event_id,
       GROUP_CONCAT(d.event_id, ',') AS event_ids
FROM decision_events AS d
GROUP BY d.application_id, d.occurred_at
HAVING COUNT(*) > 1
ORDER BY d.application_id, d.occurred_at;

-- Та же заявка с явным tie-break: показать, какая версия выбрана и почему.
SELECT d.application_id,
       d.event_id,
       d.status,
       d.occurred_at,
       ROW_NUMBER() OVER (
           PARTITION BY d.application_id
           ORDER BY d.occurred_at DESC, d.event_id DESC
       ) AS rn_by_time_and_event_id,
       ROW_NUMBER() OVER (
           PARTITION BY d.application_id
           ORDER BY d.occurred_at DESC
       ) AS rn_by_time_only_unsafe
FROM decision_events AS d
WHERE d.application_id IN (
    SELECT application_id
    FROM decision_events
    GROUP BY application_id, occurred_at
    HAVING COUNT(*) > 1
)
ORDER BY d.application_id, d.event_id;
