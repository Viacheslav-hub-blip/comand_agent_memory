-- 05_cutoff_variants_alternative_causes.sql
-- Проверка альтернативных причин расхождения A006.
-- Вопрос: расхождение вызвано именно поздней загрузкой, а не выбором границы,
-- не порядком событий и не отсутствием фильтра вообще?
-- VAR A = occurred_at < T AND loaded_at < T   (режим A, знание на T)
-- VAR B = occurred_at < T                     (режим B, пересчёт прошлого)
-- VAR C = loaded_at < T                       (только время появления записи)
-- VAR D = без фильтров по времени             (текущий снимок целиком)
WITH params AS (
    SELECT '2026-10-01 00:00:00' AS cohort_start_at,
           '2026-10-03 00:00:00' AS cohort_end_at,
           '2026-10-03 00:00:00' AS known_at
),
cohort AS (
    SELECT a.application_id
    FROM applications AS a
    CROSS JOIN params AS p
    WHERE a.created_at >= p.cohort_start_at
      AND a.created_at <  p.cohort_end_at
),
variant_a AS (
    SELECT d.application_id, d.status,
           ROW_NUMBER() OVER (PARTITION BY d.application_id
                              ORDER BY d.occurred_at DESC, d.event_id DESC) AS rn
    FROM decision_events AS d CROSS JOIN params AS p
    WHERE d.occurred_at < p.known_at AND d.loaded_at < p.known_at
),
variant_b AS (
    SELECT d.application_id, d.status,
           ROW_NUMBER() OVER (PARTITION BY d.application_id
                              ORDER BY d.occurred_at DESC, d.event_id DESC) AS rn
    FROM decision_events AS d CROSS JOIN params AS p
    WHERE d.occurred_at < p.known_at
),
variant_c AS (
    SELECT d.application_id, d.status,
           ROW_NUMBER() OVER (PARTITION BY d.application_id
                              ORDER BY d.occurred_at DESC, d.event_id DESC) AS rn
    FROM decision_events AS d CROSS JOIN params AS p
    WHERE d.loaded_at < p.known_at
),
variant_d AS (
    SELECT d.application_id, d.status,
           ROW_NUMBER() OVER (PARTITION BY d.application_id
                              ORDER BY d.occurred_at DESC, d.event_id DESC) AS rn
    FROM decision_events AS d
)
SELECT co.application_id,
       MAX(CASE WHEN va.rn = 1 THEN va.status END) AS var_a_occurred_and_loaded,
       MAX(CASE WHEN vb.rn = 1 THEN vb.status END) AS var_b_occurred_only,
       MAX(CASE WHEN vc.rn = 1 THEN vc.status END) AS var_c_loaded_only,
       MAX(CASE WHEN vd.rn = 1 THEN vd.status END) AS var_d_no_filter,
       CASE
           WHEN MAX(CASE WHEN va.rn = 1 THEN va.status END)
             IS NOT MAX(CASE WHEN vb.rn = 1 THEN vb.status END)
           THEN 'diff A vs B'
           ELSE 'same A vs B'
       END AS ab_comparison,
       CASE
           WHEN MAX(CASE WHEN va.rn = 1 THEN va.status END)
             IS NOT MAX(CASE WHEN vc.rn = 1 THEN vc.status END)
           THEN 'diff A vs C'
           ELSE 'same A vs C'
       END AS ac_comparison
FROM cohort AS co
LEFT JOIN variant_a AS va ON va.application_id = co.application_id AND va.rn = 1
LEFT JOIN variant_b AS vb ON vb.application_id = co.application_id AND vb.rn = 1
LEFT JOIN variant_c AS vc ON vc.application_id = co.application_id AND vc.rn = 1
LEFT JOIN variant_d AS vd ON vd.application_id = co.application_id AND vd.rn = 1
GROUP BY co.application_id
ORDER BY co.application_id;

-- Отдельно: инвентаризация событий относительно границы T.
-- Ожидается ровно одно событие с occurred_at < T <= loaded_at — event_id=9 (A006).
-- Параметр known_at задан явно, чтобы запрос был самодостаточным.
WITH params AS (
    SELECT '2026-10-03 00:00:00' AS known_at
)
SELECT d.event_id,
       d.application_id,
       d.status,
       d.occurred_at,
       d.loaded_at,
       ROUND((julianday(d.loaded_at) - julianday(d.occurred_at)) * 24, 3) AS load_lag_hours,
       CASE
           WHEN d.occurred_at <  p.known_at AND d.loaded_at >= p.known_at
               THEN 'late_loaded_inside_business_window'
           WHEN d.occurred_at >= p.known_at AND d.loaded_at >= p.known_at
               THEN 'outside_business_window'
           ELSE 'known_on_cutoff'
       END AS boundary_class
FROM decision_events AS d
CROSS JOIN params AS p
ORDER BY d.event_id;
