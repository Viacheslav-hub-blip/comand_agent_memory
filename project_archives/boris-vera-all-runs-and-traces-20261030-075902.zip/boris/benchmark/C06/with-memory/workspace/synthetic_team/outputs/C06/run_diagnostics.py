"""Воспроизводимый прогон диагностики C06 (A006: manual_review в истории, approved в пересчёте).

Только стандартная библиотека: csv, sqlite3, hashlib, pathlib.
Запуск из любого каталога:

    python synthetic_team\outputs\C06\run_diagnostics.py

Что делает:
  1) собирает временную SQLite-базу из sql/schema.sql и inputs/*.csv (исходники не изменяются);
  2) выполняет все .sql из synthetic_team/outputs/C06/sql в порядке имён;
  3) пишет каждый набор результата в artifacts/<NN_имя>__<k>.csv;
  4) пишет artifacts/checks_summary.csv и artifacts/manifest.json (SHA256 входов до/после,
     число строк каждого набора, версии окружения);
  5) завершается с ненулевым кодом, если обязательная проверка кардинальности не PASS.

Параметры среза зафиксированы в самих SQL-файлах (параметры указаны там явно):
  cohort_start_at = 2026-10-01 00:00:00, cohort_end_at = 2026-10-03 00:00:00,
  known_at        = 2026-10-03 00:00:00, верхняя граница не включается.
"""

from __future__ import annotations

import csv
import hashlib
import json
import sqlite3
import sys
from pathlib import Path

TABLES = ("applications", "decision_events", "payments", "fraud_labels", "rule_hits")
REQUIRED_PASS = (
    "CHECK 01 slice A 1:1",
    "CHECK 02 slice B 1:1",
    "CHECK 03 LEFT JOIN keeps cohort size",
    "CHECK 04 negative control naive JOIN",
    "CHECK 05 keys and orphans",
)


def find_base() -> Path:
    """Каталог synthetic_team: ищем вверх от файла скрипта, затем от текущего каталога."""
    here = Path(__file__).resolve()
    for parent in here.parents:
        if (parent / "sql" / "schema.sql").exists() and (parent / "inputs").is_dir():
            return parent
    cwd = Path.cwd()
    for parent in (cwd, *cwd.parents):
        candidate = parent / "synthetic_team"
        if (candidate / "sql" / "schema.sql").exists():
            return candidate
    raise SystemExit("не найден каталог synthetic_team с sql/schema.sql и inputs/")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def build_db(base: Path) -> sqlite3.Connection:
    con = sqlite3.connect(":memory:")
    con.executescript((base / "sql" / "schema.sql").read_text(encoding="utf-8"))
    for table in TABLES:
        path = base / "inputs" / f"{table}.csv"
        with path.open(encoding="utf-8", newline="") as handle:
            rows = list(csv.DictReader(handle))
        if not rows:
            continue
        columns = list(rows[0].keys())
        placeholders = ",".join("?" * len(columns))
        con.executemany(
            f"INSERT INTO {table} ({','.join(columns)}) VALUES ({placeholders})",
            [tuple(row[column] for column in columns) for row in rows],
        )
    con.commit()
    return con


def split_statements(sql_text: str) -> list[str]:
    """Схема не содержит процедур и триггеров, поэтому деление по ';' корректно."""
    statements = []
    buffer = []
    for line in sql_text.splitlines():
        if line.strip().startswith("--"):
            continue
        buffer.append(line)
        if ";" in line:
            chunk = "\n".join(buffer)
            head, _, tail = chunk.partition(";")
            if head.strip():
                statements.append(head.strip())
            buffer = [tail] if tail.strip() else []
    rest = "\n".join(buffer).strip()
    if rest:
        statements.append(rest)
    return statements


def write_csv(path: Path, header: list[str], rows: list[tuple]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(header)
        writer.writerows(rows)


def main() -> int:
    base = find_base()
    out_dir = base / "outputs" / "C06"
    sql_dir = out_dir / "sql"
    art_dir = out_dir / "artifacts"
    art_dir.mkdir(parents=True, exist_ok=True)
    for stale in art_dir.glob("*.csv"):
        stale.unlink()
    manifest_path = art_dir / "manifest.json"
    if manifest_path.exists():
        manifest_path.unlink()

    inputs_before = {t: sha256(base / "inputs" / f"{t}.csv") for t in TABLES}
    con = build_db(base)

    datasets: list[dict] = []
    checks_rows: list[list[str]] = []

    for sql_path in sorted(sql_dir.glob("*.sql")):
        statements = split_statements(sql_path.read_text(encoding="utf-8"))
        for index, statement in enumerate(statements, start=1):
            cursor = con.execute(statement)
            if cursor.description is None:
                continue
            header = [column[0] for column in cursor.description]
            rows = cursor.fetchall()
            csv_path = art_dir / f"{sql_path.stem}__set{index}.csv"
            write_csv(csv_path, header, rows)
            datasets.append(
                {
                    "sql": sql_path.name,
                    "statement": index,
                    "csv": csv_path.name,
                    "rows": len(rows),
                    "columns": header,
                }
            )
            if "CHECK " in statement:
                for row in rows:
                    checks_rows.append([str(value) for value in row])

    write_csv(
        art_dir / "checks_summary.csv",
        ["check_name", "observed", "status"],
        [tuple(row) for row in checks_rows],
    )

    inputs_after = {t: sha256(base / "inputs" / f"{t}.csv") for t in TABLES}

    failures = [
        row[0]
        for row in checks_rows
        if row[0] in REQUIRED_PASS and not row[2].startswith("PASS")
    ]
    present = {row[0] for row in checks_rows}
    missing = [name for name in REQUIRED_PASS if name not in present]

    manifest = {
        "scenario": "C06",
        "cutoff_at": "2026-10-03 00:00:00",
        "cohort_period": "2026-10-01 00:00:00 .. 2026-10-03 00:00:00 (верхняя граница не включается)",
        "sql_directory": str(sql_dir),
        "artifacts_directory": str(art_dir),
        "inputs_sha256_before": inputs_before,
        "inputs_sha256_after": inputs_after,
        "inputs_unchanged": inputs_before == inputs_after,
        "datasets": datasets,
        "checks": checks_rows,
        "required_checks": list(REQUIRED_PASS),
        "failed_checks": failures,
        "missing_checks": missing,
        "environment": {
            "python": sys.version.split()[0],
            "sqlite3": sqlite3.sqlite_version,
            "third_party_packages": [],
        },
    }
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )

    print(f"base: {base}")
    print(f"artifacts: {art_dir} ({len(datasets)} наборов результата)")
    for row in checks_rows:
        print(f"  {row[0]:42s} | {row[1]:44s} | {row[2]}")
    print(f"inputs unchanged: {manifest['inputs_unchanged']}")
    if missing:
        print(f"ОТСУТСТВУЮТ проверки: {missing}", file=sys.stderr)
    if failures:
        print(f"ПРОВАЛЕНЫ проверки: {failures}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
