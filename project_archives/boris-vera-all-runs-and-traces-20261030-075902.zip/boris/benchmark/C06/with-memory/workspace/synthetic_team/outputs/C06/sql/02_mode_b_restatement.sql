-- 02_mode_b_restatement.sql
-- Режим B: пересчёт прошлого на то же бизнес-время.
-- Отличие от режима A ровно одно: снято условие loaded_at < known_at.
-- Граница бизнес-времени остаётся той же: occurred_at < T.
-- Порядок выбора версии тот же: occurred_at DESC, event_id DESC.
WITH params AS (
    SELECT '2026-10-01 00:00:00' AS cohort_start_at,
           '2026-10-03 00:00:00' AS cohort_end_at,
           '2026-10-03 00:00:00' AS known_at
),
cohort AS (
    SELECT a.application_id,
           a.created_at,
           a.channel,
           a.is_test,
           a.requested_amount_rub
    FROM applications AS a
    CROSS JOIN params AS p
    WHERE a.created_at >= p.cohort_start_at
      AND a.created_at <  p.cohort_end_at
),
events_in_business_window AS (
    SELECT d.application_id,
           d.event_id,
           d.status,
           d.occurred_at,
           d.loaded_at
    FROM decision_events AS d
    CROSS JOIN params AS p
    WHERE d.occurred_at < p.known_at
),
ranked AS (
    SELECT e.application_id,
           e.event_id,
           e.status,
           e.occurred_at,
           e.loaded_at,
           ROW_NUMBER() OVER (
               PARTITION BY e.application_id
               ORDER BY e.occurred_at DESC, e.event_id DESC
           ) AS rn
    FROM events_in_business_window AS e
),
state_at_cutoff AS (
    SELECT application_id,
           status      AS status_at_cutoff,
           event_id    AS last_event_id,
           occurred_at AS status_occurred_at,
           loaded_at   AS status_loaded_at
    FROM ranked
    WHERE rn = 1
)
SELECT c.application_id,
       c.created_at,
       c.channel,
       c.is_test,
       c.requested_amount_rub,
       s.status_at_cutoff,
       s.last_event_id,
       s.status_occurred_at,
       s.status_loaded_at
FROM cohort AS c
LEFT JOIN state_at_cutoff AS s
       ON s.application_id = c.application_id
ORDER BY c.application_id;
