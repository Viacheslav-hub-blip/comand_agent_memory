-- 03_diff_modes.sql
-- Diff режимов A (знание на T) и B (пересчёт прошлого) на одной бизнес-границе.
-- Ожидаемый результат для снимка C06: одна строка — A006.
-- different_by = 'late_loaded_event' подтверждается условиями:
--   status_occurred_at < known_at  (событие по бизнес-времени внутри окна)
--   status_loaded_at   >= known_at (запись появилась после границы знания)
WITH params AS (
    SELECT '2026-10-01 00:00:00' AS cohort_start_at,
           '2026-10-03 00:00:00' AS cohort_end_at,
           '2026-10-03 00:00:00' AS known_at
),
cohort AS (
    SELECT a.application_id,
           a.created_at,
           a.is_test
    FROM applications AS a
    CROSS JOIN params AS p
    WHERE a.created_at >= p.cohort_start_at
      AND a.created_at <  p.cohort_end_at
),
events_known_a AS (
    SELECT d.application_id,
           d.event_id,
           d.status,
           d.occurred_at,
           d.loaded_at
    FROM decision_events AS d
    CROSS JOIN params AS p
    WHERE d.occurred_at < p.known_at
      AND d.loaded_at  < p.known_at
),
events_known_b AS (
    SELECT d.application_id,
           d.event_id,
           d.status,
           d.occurred_at,
           d.loaded_at
    FROM decision_events AS d
    CROSS JOIN params AS p
    WHERE d.occurred_at < p.known_at
),
ranked_a AS (
    SELECT e.application_id,
           e.event_id,
           e.status,
           e.occurred_at,
           e.loaded_at,
           ROW_NUMBER() OVER (
               PARTITION BY e.application_id
               ORDER BY e.occurred_at DESC, e.event_id DESC
           ) AS rn
    FROM events_known_a AS e
),
ranked_b AS (
    SELECT e.application_id,
           e.event_id,
           e.status,
           e.occurred_at,
           e.loaded_at,
           ROW_NUMBER() OVER (
               PARTITION BY e.application_id
               ORDER BY e.occurred_at DESC, e.event_id DESC
           ) AS rn
    FROM events_known_b AS e
),
state_a AS (
    SELECT application_id,
           status      AS status_historical,
           event_id    AS event_id_historical,
           occurred_at AS occurred_at_historical,
           loaded_at   AS loaded_at_historical
    FROM ranked_a
    WHERE rn = 1
),
state_b AS (
    SELECT application_id,
           status      AS status_restated,
           event_id    AS event_id_restated,
           occurred_at AS occurred_at_restated,
           loaded_at   AS loaded_at_restated
    FROM ranked_b
    WHERE rn = 1
)
SELECT c.application_id,
       c.created_at,
       c.is_test,
       a.status_historical,
       a.event_id_historical,
       a.occurred_at_historical,
       a.loaded_at_historical,
       b.status_restated,
       b.event_id_restated,
       b.occurred_at_restated,
       b.loaded_at_restated,
       a.status_historical || ' -> ' || b.status_restated AS status_changed,
       CASE
           WHEN b.occurred_at_restated IS NOT NULL
            AND b.occurred_at_restated <  (SELECT known_at FROM params)
            AND b.loaded_at_restated   >= (SELECT known_at FROM params)
           THEN 'late_loaded_event'
           ELSE 'other'
       END AS different_by
FROM cohort AS c
LEFT JOIN state_a AS a
       ON a.application_id = c.application_id
LEFT JOIN state_b AS b
       ON b.application_id = c.application_id
WHERE COALESCE(a.status_historical, '<none>') <> COALESCE(b.status_restated, '<none>')
ORDER BY c.application_id;
