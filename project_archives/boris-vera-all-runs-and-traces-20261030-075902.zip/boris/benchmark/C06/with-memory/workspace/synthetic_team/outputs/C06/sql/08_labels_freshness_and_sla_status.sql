-- 08_labels_freshness_and_sla_status.sql
-- Свежесть источника заключений расследования (fraud_labels) на дату среза T.
-- Назначение: отделить НАБЛЮДЕНИЕ по снимку от УТВЕРЖДЁННОГО норматива срока.
-- В материалах утверждённого SLA разметки нет (documents/pipeline_notes.md:
-- "обычно D+3" — наблюдение от 2026-10-05; "D+5" — черновик от 2026-10-06;
-- documents/fraud_evaluation.md: гарантированного срока завершения расследований нет).
-- Этот запрос не подтверждает SLA, а показывает, что наблюдалось в снимке.

-- 1) Задержка от регистрации заявки до появления версии заключения (часы и дни).
SELECT f.label_id,
       f.application_id,
       f.label,
       f.reason,
       a.created_at,
       f.recorded_at,
       ROUND((julianday(f.recorded_at) - julianday(a.created_at)) * 24, 3) AS lag_hours_from_created_at,
       ROUND((julianday(f.recorded_at) - julianday(a.created_at)), 3)      AS lag_days_from_created_at
FROM fraud_labels AS f
JOIN applications AS a
     ON a.application_id = f.application_id
ORDER BY f.application_id, f.recorded_at, f.label_id;

-- 2) Задержка от первого события по заявке (occurred_at, включая manual_review)
-- до появления версии заключения. Первое событие не всегда является решением.
SELECT a.application_id,
       MIN(d.occurred_at) AS first_event_occurred_at,
       f.label_id,
       f.label,
       f.recorded_at,
       ROUND((julianday(f.recorded_at) - julianday(MIN(d.occurred_at))) * 24, 3) AS lag_hours_from_first_event
FROM applications AS a
JOIN decision_events AS d
     ON d.application_id = a.application_id
JOIN fraud_labels AS f
     ON f.application_id = a.application_id
WHERE a.is_test = 0
GROUP BY a.application_id, f.label_id, f.label, f.recorded_at
ORDER BY a.application_id, f.recorded_at;

-- 3) Свежесть на дату знания T: сколько реальных заявок когорты имеют известное
-- заключение (последняя версия recorded_at < T, при равном времени label_id DESC).
-- Ранжирование выполняется В РАЗРЕЗЕ (application_id, known_at): иначе метка,
-- известная на позднюю дату, протекла бы в ранний срез.
-- Ожидается: на T = 2026-10-03 00:00:00 известных исходов ноль.
WITH knowledge_dates AS (
    SELECT '2026-10-03 00:00:00' AS known_at
    UNION ALL SELECT '2026-10-03 23:59:59'
    UNION ALL SELECT '2026-10-04 23:59:59'
    UNION ALL SELECT '2026-10-05 23:59:59'
    UNION ALL SELECT '2026-10-06 23:59:59'
    UNION ALL SELECT '2026-10-07 23:59:59'
),
cohort AS (
    SELECT a.application_id
    FROM applications AS a
    WHERE a.created_at >= '2026-10-01 00:00:00'
      AND a.created_at <  '2026-10-03 00:00:00'
      AND a.is_test = 0
),
latest_label AS (
    SELECT k.known_at,
           f.application_id,
           f.label,
           ROW_NUMBER() OVER (
               PARTITION BY k.known_at, f.application_id
               ORDER BY f.recorded_at DESC, f.label_id DESC
           ) AS rn
    FROM fraud_labels AS f
    JOIN knowledge_dates AS k
      ON f.recorded_at < k.known_at
)
SELECT k.known_at,
       COUNT(*)                                                        AS cohort_real_applications,
       SUM(CASE WHEN l.rn = 1 THEN 1 ELSE 0 END)                       AS labeled_known,
       SUM(CASE WHEN l.rn IS NULL THEN 1 ELSE 0 END)                   AS unknown_outcome,
       SUM(CASE WHEN l.rn = 1 AND l.label = 'confirmed_fraud' THEN 1 ELSE 0 END) AS confirmed_fraud,
       SUM(CASE WHEN l.rn = 1 AND l.label = 'legitimate'      THEN 1 ELSE 0 END) AS legitimate
FROM knowledge_dates AS k
CROSS JOIN cohort AS c
LEFT JOIN latest_label AS l
       ON l.application_id = c.application_id
      AND l.known_at       = k.known_at
      AND l.rn = 1
GROUP BY k.known_at
ORDER BY k.known_at;

-- 4) Заявки когорты без известного заключения на T = 2026-10-03 00:00:00
-- (отсутствие строки = неизвестный исход, не legitimate).
WITH cohort AS (
    SELECT a.application_id, a.created_at
    FROM applications AS a
    WHERE a.created_at >= '2026-10-01 00:00:00'
      AND a.created_at <  '2026-10-03 00:00:00'
      AND a.is_test = 0
)
SELECT c.application_id,
       c.created_at,
       f.label       AS label_known_on_cutoff,
       f.recorded_at AS recorded_at_known_on_cutoff
FROM cohort AS c
LEFT JOIN fraud_labels AS f
       ON f.application_id = c.application_id
      AND f.recorded_at < '2026-10-03 00:00:00'
ORDER BY c.application_id;
