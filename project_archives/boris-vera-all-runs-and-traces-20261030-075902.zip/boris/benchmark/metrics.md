# Новые прогоны Бориса

Повтор знакомых задач; по одному опыту на вариант.
Успех — решение модельного тестировщика. Стоимость неизвестна.
Построение памяти учитывается отдельно в memory-build/*.metrics.json.

| case | variant | role | state | user_turns | duration_seconds | model_calls | tool_calls | input_tokens | cached_tokens | new_input_tokens | output_tokens | usage_complete |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C02 | with-memory | tested_agent | completed | 2 | 156.35583079996286 | 36 | 51 | 989235 | 857210 | 132025 | 22246 | True |
| C02 | with-memory | tester | completed | 2 | 25.327129299985245 | 2 | 0 | 33328 | 9984 | 23344 | 3226 | True |
| C02 | without-memory | tested_agent | completed | 3 | 446.95141570008127 | 153 | 159 | 5366558 | 5007872 | 358686 | 48018 | True |
| C02 | without-memory | tester | completed | 3 | 49.96560449997196 | 3 | 0 | 67649 | 37120 | 30529 | 4040 | True |
| C06 | with-memory | tested_agent | completed | 3 | 352.1712973000831 | 82 | 93 | 3368974 | 3137394 | 231580 | 52990 | True |
| C06 | with-memory | tester | completed | 3 | 22.137600999965798 | 3 | 0 | 51295 | 15360 | 35935 | 3776 | True |
| C06 | without-memory | tested_agent | completed | 4 | 568.7583647000138 | 97 | 107 | 4598723 | 4444544 | 154179 | 65647 | True |
| C06 | without-memory | tester | completed | 4 | 62.382031499932054 | 4 | 0 | 67710 | 34816 | 32894 | 4994 | True |
