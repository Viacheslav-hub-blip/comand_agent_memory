# Индекс личной wiki

- [sever-project.md](sever-project.md) — учебный проект «Север»: предметная область, данные, окружение, договорённости.
- [sever-scenarios.md](sever-scenarios.md) — сценарии C02 и C06: результаты, артефакты, открытые вопросы.
- [../knowledge/INDEX.md](../knowledge/INDEX.md) — предметные определения, cases и сквозной Skill по сверке отчётности.
