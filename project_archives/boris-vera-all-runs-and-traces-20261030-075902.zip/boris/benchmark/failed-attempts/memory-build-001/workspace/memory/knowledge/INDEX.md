# Индекс знаний и опыта «Север»

Назначение материалов и проверенные внутренние пути. Личные правила и проектный контекст — в `../AGENTS.md`, `../USER_PREFERENCES.md`, `../user_llm_wiki/`.

## Wiki — предметные факты

- [wiki/metric-definitions.md](wiki/metric-definitions.md) — таблица `applications`, `decision_events` с раздельными `occurred_at`/`loaded_at`, режимы «знание на `T`» и «пересчёт прошлого», задержка загрузки против длительности бизнес-проверки, `payments`, `fraud_labels`, `rule_hits`, определения `approval_rate` v1/v2 и `final_decision_approval_rate`, статус утверждений по срокам разметки.

## Cases — переносимый опыт с исходным эпизодом

- [cases/late-loaded-decision.md](cases/late-loaded-decision.md) — A006: расхождение as-of-среза и пересчёта из-за загрузки события через 4 часа после границы; различающие проверки H1/H2/H3, tie-break на A007, H1 на A001.
- [cases/asof-slice-and-modes.md](cases/asof-slice-and-modes.md) — построение as-of среза против legacy-агрегата (`6 / 85 000` против `2 / 22 000`) и diff двух режимов (метрики v2 28.6 % против 42.9 %).
- [cases/cardinality-and-distinct.md](cases/cardinality-and-distinct.md) — пять проверок кардинальности с негативным контролем, размножение `13` строк на `8` заявок, fan-out по трём 1:N-таблицам (`3 × 2 × 2 = 12`), почему `DISTINCT` не исправляет историю.
- [cases/legacy-approval-audit.md](cases/legacy-approval-audit.md) — поимённый разбор лишних строк legacy-запроса: `A002`, `A007`, `A006`, тестовая `A004`.
- [cases/sla-status-check.md](cases/sla-status-check.md) — «D+3» как наблюдение и «D+5» как черновик против запроса на гарантию срока; unknown, ревизии, база дней.

## Skills — сквозные процессы

- [skills/cohort-report-reconciliation/SKILL.md](skills/cohort-report-reconciliation/SKILL.md) — от CSV и схемы до проверенного результата: импорт, as-of срез, пересчёт, diff, контроль кардинальности, метрики, исправление legacy, SQL и отчёт.
