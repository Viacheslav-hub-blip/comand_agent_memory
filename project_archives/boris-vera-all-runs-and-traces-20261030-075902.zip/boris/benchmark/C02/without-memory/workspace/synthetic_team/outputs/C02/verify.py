"""Финальная проверка воспроизводимости: полная пересборка БД из CSV + утверждения по срезу.

csv + sqlite3, без pandas и установки. Запуск:
    python synthetic_team/outputs/C02/verify.py
"""
import os
import sqlite3
import sys

sys.path.insert(0, os.path.join('synthetic_team', 'outputs', 'C02'))
from build_and_check import build  # noqa: E402

OUT = os.path.join('synthetic_team', 'outputs', 'C02')

con = build()  # пересоздаёт north.db из inputs
con.row_factory = sqlite3.Row
sql = open(os.path.join(OUT, 'state_at_2026-10-03.sql'), encoding='utf-8').read()
rows = [dict(r) for r in con.execute(sql)]

expected = {
    'A001': ('approved', 2),
    'A002': ('cancelled', 4),
    'A003': ('rejected', 5),
    'A004': ('approved', 6),
    'A005': ('approved', 7),
    'A006': ('manual_review', 8),
    'A007': ('rejected', 11),
    'A008': ('manual_review', 12),
}

problems = []
if len(rows) != len(expected):
    problems.append(f'строк {len(rows)}, ожидалось {len(expected)}')
if len({r['application_id'] for r in rows}) != len(rows):
    problems.append('дубли application_id в результате')
for r in rows:
    exp = expected.get(r['application_id'])
    if exp is None:
        problems.append(f"лишняя заявка {r['application_id']}")
        continue
    if (r['status_at_as_of'], r['last_event_id']) != exp:
        problems.append(f"{r['application_id']}: {(r['status_at_as_of'], r['last_event_id'])} != {exp}")

real = [r for r in rows if r['is_test'] == 0]
approved = sum(1 for r in real if r['status_at_as_of'] == 'approved')
final = sum(1 for r in real if r['status_at_as_of'] in ('approved', 'rejected'))
if (approved, len(real), final) != (2, 7, 4):
    problems.append(f'метрики: approved={approved}, real={len(real)}, final={final}')

cash = con.execute("""
    SELECT COALESCE(SUM(CASE WHEN payment_type='disbursement' THEN amount_rub ELSE 0 END), 0)
         - COALESCE(SUM(CASE WHEN payment_type='refund' THEN amount_rub ELSE 0 END), 0)
    FROM payments
    WHERE booked_at >= '2026-10-01 00:00:00' AND booked_at < '2026-10-03 00:00:00'
""").fetchone()[0]
if cash != 24000:
    problems.append(f'net_disbursement={cash}, ожидалось 24000')

# --- кардинальность: срез -> одна строка на заявку, LEFT JOIN не множит ---
AS_OF = "'2026-10-03 00:00:00'"
sliced = f"""
WITH params AS (SELECT {AS_OF} AS as_of_utc, '2026-10-01 00:00:00' AS cs, '2026-10-03 00:00:00' AS ce),
modes AS (SELECT 'as_known' AS mode UNION ALL SELECT 'restated'),
candidates AS (
    SELECT m.mode, d.event_id, d.application_id, d.status, d.occurred_at, d.loaded_at
    FROM decision_events AS d CROSS JOIN params AS p CROSS JOIN modes AS m
    WHERE d.occurred_at < p.as_of_utc
      AND (m.mode = 'restated' OR d.loaded_at < p.as_of_utc)
),
ranked AS (
    SELECT mode, application_id, event_id, status, occurred_at, loaded_at,
           ROW_NUMBER() OVER (PARTITION BY mode, application_id
                              ORDER BY occurred_at DESC, event_id DESC) AS rn
    FROM candidates
)
SELECT mode, application_id, event_id AS last_event_id, status, occurred_at, loaded_at
FROM ranked WHERE rn = 1
"""
rows_sliced = con.execute(sliced).fetchall()
per_mode = {}
for r in rows_sliced:
    per_mode.setdefault(r['mode'], []).append(r['application_id'])
for mode, apps in per_mode.items():
    if len(apps) != len(set(apps)):
        problems.append(f'{mode}: дубли application_id после среза')
    if len(apps) != 8:
        problems.append(f'{mode}: строк среза {len(apps)}, ожидалось 8')
rn1 = con.execute(f"WITH s AS ({sliced}) SELECT COUNT(*) FROM s").fetchone()[0]
if rn1 != 16:
    problems.append(f'выбранных строк среза {rn1}, ожидалось 16 (2 режима x 8)')

joined = con.execute(f"""
WITH params AS (SELECT '2026-10-01 00:00:00' AS cs, '2026-10-03 00:00:00' AS ce),
cohort AS (SELECT a.application_id FROM applications a CROSS JOIN params p
           WHERE a.created_at >= p.cs AND a.created_at < p.ce),
sliced AS ({sliced})
SELECT (SELECT COUNT(*) FROM cohort) AS cohort_rows,
       COUNT(*) AS joined_rows,
       COUNT(DISTINCT c.application_id) AS distinct_apps
FROM cohort c LEFT JOIN sliced s
       ON s.application_id = c.application_id AND s.mode = 'restated'
""").fetchone()
if not (joined['cohort_rows'] == joined['joined_rows'] == joined['distinct_apps'] == 8):
    problems.append(f"LEFT JOIN поменял кардинальность: {dict(joined)}")

con.close()
if problems:
    print('FAIL')
    for p in problems:
        print(' -', p)
    sys.exit(1)
print('OK: пересборка из CSV воспроизводит 8 строк среза, метрики 2/7 и 2/4, net=24000; '
      'срез даёт 1 строку на заявку в каждом режиме, LEFT JOIN сохраняет 8 заявок')
