"""Сборка локальной SQLite из CSV inputs и прогон проверок/запросов.

Только стандартная библиотека: csv + sqlite3.
"""
import csv
import sqlite3
import os

BASE = 'synthetic_team'
INPUTS = os.path.join(BASE, 'inputs')
OUT = os.path.join(BASE, 'outputs', 'C02')
DB = os.path.join(OUT, 'north.db')

TABLES = {
    'applications': ['application_id', 'created_at', 'requested_amount_rub', 'is_test', 'channel'],
    'decision_events': ['event_id', 'application_id', 'status', 'occurred_at', 'loaded_at'],
    'payments': ['payment_id', 'application_id', 'payment_type', 'amount_rub', 'booked_at'],
    'fraud_labels': ['label_id', 'application_id', 'label', 'recorded_at', 'reason'],
    'rule_hits': ['rule_id', 'application_id', 'hit_at'],
}


def build():
    if os.path.exists(DB):
        os.remove(DB)
    con = sqlite3.connect(DB)
    con.executescript(open(os.path.join(BASE, 'sql', 'schema.sql'), encoding='utf-8').read())
    for table, cols in TABLES.items():
        path = os.path.join(INPUTS, table + '.csv')
        rows = list(csv.DictReader(open(path, encoding='utf-8')))
        placeholders = ','.join('?' * len(cols))
        sql = f"INSERT INTO {table} ({','.join(cols)}) VALUES ({placeholders})"
        con.executemany(sql, [[r[c] for c in cols] for r in rows])
    con.commit()
    return con


def show(con, title, sql):
    print(f"\n--- {title}")
    cur = con.execute(sql)
    print(' | '.join(d[0] for d in cur.description))
    for row in cur.fetchall():
        print(' | '.join('' if v is None else str(v) for v in row))


if __name__ == '__main__':
    con = build()

    show(con, 'keys: applications', """
        SELECT COUNT(*) AS rows, COUNT(DISTINCT application_id) AS distinct_id,
               SUM(created_at IS NULL) AS null_created FROM applications""")
    show(con, 'keys: decision_events', """
        SELECT COUNT(*) AS rows, COUNT(DISTINCT event_id) AS distinct_event,
               COUNT(DISTINCT application_id) AS distinct_app,
               SUM(application_id IS NULL) AS null_app FROM decision_events""")
    show(con, 'multiplicity per application', """
        SELECT application_id, COUNT(*) AS events FROM decision_events
        GROUP BY application_id HAVING COUNT(*) > 1 ORDER BY application_id""")
    show(con, 'ties inside one application (same occurred_at)', """
        SELECT application_id, occurred_at, COUNT(*) AS n,
               MIN(event_id) AS min_event, MAX(event_id) AS max_event
        FROM decision_events GROUP BY application_id, occurred_at
        HAVING COUNT(*) > 1""")
    show(con, 'orphan FK checks (should be 0)', """
        SELECT 'decision_events' AS src, COUNT(*) AS orphans FROM decision_events d
            LEFT JOIN applications a USING (application_id) WHERE a.application_id IS NULL
        UNION ALL
        SELECT 'payments', COUNT(*) FROM payments p
            LEFT JOIN applications a USING (application_id) WHERE a.application_id IS NULL
        UNION ALL
        SELECT 'fraud_labels', COUNT(*) FROM fraud_labels f
            LEFT JOIN applications a USING (application_id) WHERE a.application_id IS NULL
        UNION ALL
        SELECT 'rule_hits', COUNT(*) FROM rule_hits r
            LEFT JOIN applications a USING (application_id) WHERE a.application_id IS NULL""")
    show(con, 'loaded_at < occurred_at (data-quality flags)', """
        SELECT event_id, application_id, occurred_at, loaded_at FROM decision_events
        WHERE loaded_at < occurred_at""")
    show(con, 'cohort composition', """
        SELECT COUNT(*) AS cohort_rows, SUM(is_test = 1) AS test_rows FROM applications
        WHERE created_at >= '2026-10-01 00:00:00' AND created_at < '2026-10-03 00:00:00'""")

    # старый запрос как есть
    show(con, 'LEGACY output (as written)', """
        SELECT COUNT(*) AS approved_count,
               SUM(a.requested_amount_rub) AS approved_amount_rub
        FROM applications AS a
        JOIN decision_events AS d ON d.application_id = a.application_id
        WHERE a.created_at >= '2026-10-01 00:00:00'
          AND a.created_at < '2026-10-03 00:00:00'
          AND d.status = 'approved'""")
    show(con, 'LEGACY matched rows (detail)', """
        SELECT a.application_id, a.created_at, a.is_test, d.event_id, d.status,
               d.occurred_at, d.loaded_at, a.requested_amount_rub
        FROM applications AS a
        JOIN decision_events AS d ON d.application_id = a.application_id
        WHERE a.created_at >= '2026-10-01 00:00:00'
          AND a.created_at < '2026-10-03 00:00:00'
          AND d.status = 'approved'
        ORDER BY a.application_id, d.event_id""")

    con.close()
