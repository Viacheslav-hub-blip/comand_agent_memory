"""Прогон сравнения двух режимов на локальном SQLite, собранном из CSV.

Режимы:
  as_known  — occurred_at < T AND loaded_at < T (исторически известное состояние)
  restated  — occurred_at < T, loaded_at не ограничен (пересчёт на то же бизнес-время)

Только стандартная библиотека: csv + sqlite3. Исходники не изменяются.
Запуск: python synthetic_team/outputs/C02/run_compare.py
"""
import os
import sqlite3
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from build_and_check import build  # пересборка north.db из /synthetic_team/inputs

OUT = HERE
con = build()
con.row_factory = sqlite3.Row

diff_sql = open(os.path.join(OUT, 'compare_modes.sql'), encoding='utf-8').read()
diff_rows = [dict(r) for r in con.execute(diff_sql)]

cols = ['application_id', 'created_at', 'requested_amount_rub', 'is_test', 'channel',
        'status_as_known', 'event_as_known', 'loaded_as_known',
        'status_restated', 'event_restated', 'loaded_restated']

lines = []
lines.append('=== Сравнение режимов на T = 2026-10-03 00:00:00 UTC')
lines.append('Когорта: 2026-10-01 00:00:00 <= created_at < 2026-10-03 00:00:00')
lines.append('as_known: occurred_at < T AND loaded_at < T')
lines.append('restated: occurred_at < T, loaded_at не ограничен')
lines.append('')
lines.append(f'Заявок, где режимы различаются: {len(diff_rows)}')
lines.append('')
lines.append(' | '.join(cols))
for r in diff_rows:
    lines.append(' | '.join('' if r[c] is None else str(r[c]) for c in cols))

# дополнительно: сколько событий вообще отсекает ограничение loaded_at
late = con.execute("""
    SELECT event_id, application_id, status, occurred_at, loaded_at
    FROM decision_events
    WHERE occurred_at < '2026-10-03 00:00:00'
      AND loaded_at  >= '2026-10-03 00:00:00'
    ORDER BY event_id
""").fetchall()
lines.append('')
lines.append(f'События с occurred_at < T, но loaded_at >= T (их видит только restated): {len(late)}')
for r in late:
    lines.append(f"  event_id={r['event_id']} {r['application_id']} {r['status']} "
                 f"occurred_at={r['occurred_at']} loaded_at={r['loaded_at']}")

# контроль полноты: в каждом режиме ровно одна строка на заявку когорты
for mode, cond in (('as_known', 'AND loaded_at < p.as_of_utc'), ('restated', '')):
    n = con.execute(f"""
        WITH params AS (SELECT '2026-10-03 00:00:00' AS as_of_utc)
        SELECT COUNT(DISTINCT application_id) FROM decision_events AS d
        CROSS JOIN params AS p WHERE d.occurred_at < p.as_of_utc {cond}
    """).fetchone()[0]
    lines.append(f'заявок с известным событием в режиме {mode}: {n}')

con.close()
text = '\n'.join(lines)
open(os.path.join(OUT, 'compare_result.txt'), 'w', encoding='utf-8').write(text + '\n')
print(text)
