"""Проверки кардинальности для воспроизводимой работы с историей.

1) уникальность application_id после выбора среза (полный срез, не diff-фильтр);
2) сохранение числа заявок когорты после LEFT JOIN среза к когорте;
3) почему простой DISTINCT не исправляет произвольное соединение с историей.

Только csv + sqlite3. Исходники не меняются: БД пересобирается из CSV.
"""
import os
import sqlite3
import sys

sys.path.insert(0, os.path.join('synthetic_team', 'outputs', 'C02'))
from build_and_check import build  # noqa: E402

OUT = os.path.join('synthetic_team', 'outputs', 'C02')

# Полный срез: оба режима, все заявки когорты, режимы развёрнуты в колонки.
FULL_SLICE = """
WITH params AS (
    SELECT '2026-10-03 00:00:00' AS as_of_utc,
           '2026-10-01 00:00:00' AS cohort_start_utc,
           '2026-10-03 00:00:00' AS cohort_end_utc
),
cohort AS (
    SELECT a.application_id, a.created_at, a.requested_amount_rub, a.is_test, a.channel
    FROM applications AS a CROSS JOIN params AS p
    WHERE a.created_at >= p.cohort_start_utc AND a.created_at < p.cohort_end_utc
),
modes AS (
    SELECT 'as_known' AS mode UNION ALL SELECT 'restated'
),
candidates AS (
    SELECT m.mode, d.event_id, d.application_id, d.status, d.occurred_at, d.loaded_at
    FROM decision_events AS d
    CROSS JOIN params AS p
    CROSS JOIN modes AS m
    WHERE d.occurred_at < p.as_of_utc
      AND (m.mode = 'restated' OR d.loaded_at < p.as_of_utc)
),
ranked AS (
    SELECT c.mode, c.application_id, c.event_id, c.status, c.occurred_at, c.loaded_at,
           ROW_NUMBER() OVER (PARTITION BY c.mode, c.application_id
                              ORDER BY c.occurred_at DESC, c.event_id DESC) AS rn
    FROM candidates AS c
),
sliced AS (
    SELECT r.mode, r.application_id, r.event_id AS last_event_id,
           r.status AS status_at_as_of, r.occurred_at AS status_occurred_at,
           r.loaded_at AS status_loaded_at
    FROM ranked AS r WHERE r.rn = 1
),
cohort_state AS (
    SELECT c.application_id, c.created_at, c.requested_amount_rub, c.is_test, c.channel,
           k.status_at_as_of AS status_as_known, k.last_event_id AS event_as_known,
           r.status_at_as_of AS status_restated, r.last_event_id AS event_restated
    FROM cohort AS c
    LEFT JOIN sliced AS k ON k.application_id = c.application_id AND k.mode = 'as_known'
    LEFT JOIN sliced AS r ON r.application_id = c.application_id AND r.mode = 'restated'
)
"""

con = build()
con.row_factory = sqlite3.Row
lines = []


def show(title, sql):
    cur = con.execute(sql)
    lines.append(f'--- {title}')
    lines.append(' | '.join(d[0] for d in cur.description))
    for row in cur.fetchall():
        lines.append(' | '.join('' if v is None else str(v) for v in row))
    lines.append('')


# ---------------------------------------------------------------- 1) срез
lines.append('=== 1) Уникальность application_id после выбора среза')
show('полный срез (оба режима, все заявки когорты): строк / distinct / дубли', FULL_SLICE + """
SELECT COUNT(*) AS rendered_rows,
       COUNT(DISTINCT application_id) AS distinct_apps,
       (SELECT COUNT(*) FROM (
           SELECT application_id FROM cohort_state GROUP BY application_id
           HAVING COUNT(*) > 1)) AS duplicate_apps,
       CASE WHEN COUNT(*) = COUNT(DISTINCT application_id)
            THEN 'OK: одна строка на заявку' ELSE 'FAIL' END AS verdict
FROM cohort_state
""")

show('кандидаты -> выбранные: строк истории много, выбранных ровно по одной на (mode, application_id)', """
WITH params AS (SELECT '2026-10-03 00:00:00' AS as_of_utc),
modes AS (SELECT 'as_known' AS mode UNION ALL SELECT 'restated'),
candidates AS (
    SELECT m.mode, d.event_id, d.application_id, d.status, d.occurred_at
    FROM decision_events AS d CROSS JOIN params AS p CROSS JOIN modes AS m
    WHERE d.occurred_at < p.as_of_utc
      AND (m.mode = 'restated' OR d.loaded_at < p.as_of_utc)
),
ranked AS (
    SELECT mode, application_id, event_id,
           ROW_NUMBER() OVER (PARTITION BY mode, application_id
                              ORDER BY occurred_at DESC, event_id DESC) AS rn
    FROM candidates
)
SELECT mode,
       COUNT(*) AS candidate_rows,
       SUM(rn = 1) AS selected_rows,
       COUNT(DISTINCT application_id) AS distinct_apps,
       MAX(rn) AS max_rn,
       CASE WHEN SUM(rn = 1) = COUNT(DISTINCT application_id)
            THEN 'OK: 1 выбранная строка на заявку' ELSE 'FAIL' END AS verdict
FROM ranked GROUP BY mode ORDER BY mode
""")

# ------------------------------------------------- 2) LEFT JOIN не множит
lines.append('=== 2) LEFT JOIN среза к когорте сохраняет число заявок')
show('когорта / результат LEFT JOIN / distinct / вердикт', FULL_SLICE + """
SELECT (SELECT COUNT(*) FROM cohort) AS cohort_rows,
       COUNT(*) AS joined_rows,
       COUNT(DISTINCT application_id) AS distinct_apps,
       CASE WHEN COUNT(*) = (SELECT COUNT(*) FROM cohort)
                 AND COUNT(*) = COUNT(DISTINCT application_id)
            THEN 'OK: кардинальность когорты сохранена' ELSE 'FAIL' END AS verdict
FROM cohort_state
""")

# ------------------------------- 3) DISTINCT не спасает произвольный JOIN
lines.append('=== 3) Почему простой DISTINCT не исправляет произвольное соединение с историей')
show('произвольный JOIN когорты со всеми событиями: веер строк и завышенная сумма', """
WITH cohort AS (
    SELECT a.application_id, a.requested_amount_rub
    FROM applications AS a
    WHERE a.created_at >= '2026-10-01 00:00:00' AND a.created_at < '2026-10-03 00:00:00'
)
SELECT COUNT(*) AS join_rows,
       COUNT(DISTINCT c.application_id) AS distinct_apps,
       SUM(c.requested_amount_rub) AS sum_amount_over_join,
       (SELECT SUM(requested_amount_rub) FROM cohort) AS sum_amount_correct
FROM cohort AS c JOIN decision_events AS d ON d.application_id = c.application_id
""")

show('DISTINCT по (application_id, requested_amount, status): на заявку всё ещё несколько строк', """
WITH cohort AS (
    SELECT a.application_id, a.requested_amount_rub
    FROM applications AS a
    WHERE a.created_at >= '2026-10-01 00:00:00' AND a.created_at < '2026-10-03 00:00:00'
)
SELECT application_id, COUNT(*) AS rows_after_distinct,
       GROUP_CONCAT(status, ' -> ') AS statuses_kept
FROM (
    SELECT DISTINCT c.application_id, c.requested_amount_rub, d.status
    FROM cohort AS c JOIN decision_events AS d ON d.application_id = c.application_id
)
GROUP BY application_id ORDER BY application_id
""")

show('SUM(DISTINCT amount) поверх JOIN: совпал случайно, статус всё равно произвольный', """
WITH cohort AS (
    SELECT a.application_id, a.requested_amount_rub
    FROM applications AS a
    WHERE a.created_at >= '2026-10-01 00:00:00' AND a.created_at < '2026-10-03 00:00:00'
)
SELECT SUM(DISTINCT c.requested_amount_rub) AS sum_distinct_amounts,
       (SELECT SUM(requested_amount_rub) FROM cohort) AS sum_correct,
       CASE WHEN SUM(DISTINCT c.requested_amount_rub) = (SELECT SUM(requested_amount_rub) FROM cohort)
            THEN 'совпало только потому, что все суммы в снимке разные'
            ELSE 'разошлось' END AS caveat
FROM cohort AS c JOIN decision_events AS d ON d.application_id = c.application_id
""")

show('DISTINCT по одной колонке: строк столько же, статус выбирается произвольно', """
SELECT COUNT(*) AS rows_after_distinct_appid, COUNT(DISTINCT application_id) AS distinct_apps
FROM (SELECT DISTINCT c.application_id, d.status
      FROM applications AS c JOIN decision_events AS d ON d.application_id = c.application_id
      WHERE c.created_at >= '2026-10-01 00:00:00' AND c.created_at < '2026-10-03 00:00:00')
""")

show('A001 как пример: 3 события в истории — без порядка «настоящее» не определено', """
SELECT d.event_id, d.status, d.occurred_at, d.loaded_at
FROM decision_events AS d
WHERE d.application_id = 'A001'
ORDER BY d.occurred_at, d.event_id
""")

text = '\n'.join(lines)
open(os.path.join(OUT, 'cardinality_checks.txt'), 'w', encoding='utf-8').write(text)
con.close()
print(text)
