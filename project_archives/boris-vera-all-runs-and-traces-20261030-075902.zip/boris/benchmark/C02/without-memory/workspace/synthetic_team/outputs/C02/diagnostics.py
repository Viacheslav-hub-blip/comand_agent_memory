"""Дополнительные проверки для разбора старого запроса."""
import os, sqlite3

OUT = os.path.join('synthetic_team', 'outputs', 'C02')
con = sqlite3.connect(os.path.join(OUT, 'north.db'))
con.row_factory = sqlite3.Row
L = []

def q(title, sql):
    L.append('--- ' + title)
    cur = con.execute(sql)
    L.append(' | '.join(d[0] for d in cur.description))
    for r in cur.fetchall():
        L.append(' | '.join('' if v is None else str(v) for v in r))
    L.append('')

q('1) старый запрос: сколько строк JOIN даёт по когорте', """
SELECT COUNT(*) AS joined_rows, COUNT(DISTINCT a.application_id) AS distinct_apps
FROM applications a JOIN decision_events d USING (application_id)
WHERE a.created_at >= '2026-10-01 00:00:00' AND a.created_at < '2026-10-03 00:00:00'""")

q('2) наивный JOIN без среза: SUM по строкам событий (двойной счёт по заявкам)', """
SELECT COUNT(*) n, SUM(a.requested_amount_rub) total
FROM applications a JOIN decision_events d USING (application_id)
WHERE a.created_at >= '2026-10-01 00:00:00' AND a.created_at < '2026-10-03 00:00:00'
  AND d.status = 'approved'""")

q('3) фильтр только occurred_at (без loaded_at) — срез 2026-10-03', """
WITH e AS (SELECT * FROM decision_events WHERE occurred_at < '2026-10-03 00:00:00'),
r AS (SELECT application_id, status, ROW_NUMBER() OVER (PARTITION BY application_id
      ORDER BY occurred_at DESC, event_id DESC) rn FROM e)
SELECT a.application_id, r.status FROM applications a JOIN r ON r.application_id = a.application_id AND r.rn = 1
WHERE a.created_at >= '2026-10-01 00:00:00' AND a.created_at < '2026-10-03 00:00:00'
ORDER BY a.application_id""")

q('4) фильтр только loaded_at (без occurred_at) — срез 2026-10-03', """
WITH e AS (SELECT * FROM decision_events WHERE loaded_at < '2026-10-03 00:00:00'),
r AS (SELECT application_id, status, ROW_NUMBER() OVER (PARTITION BY application_id
      ORDER BY occurred_at DESC, event_id DESC) rn FROM e)
SELECT a.application_id, r.status FROM applications a JOIN r ON r.application_id = a.application_id AND r.rn = 1
WHERE a.created_at >= '2026-10-01 00:00:00' AND a.created_at < '2026-10-03 00:00:00'
ORDER BY a.application_id""")

q('5) A007: разрешение ничьей по occurred_at (event_id 10 approved vs 11 rejected)', """
SELECT event_id, status, occurred_at, loaded_at FROM decision_events
WHERE application_id = 'A007' ORDER BY occurred_at DESC, event_id DESC""")

q('6) A001: позднее событие 13 (2026-10-04) не должно попасть в срез', """
SELECT event_id, status, occurred_at, loaded_at, occurred_at < '2026-10-03 00:00:00' AS occ_ok,
       loaded_at < '2026-10-03 00:00:00' AS load_ok
FROM decision_events WHERE application_id = 'A001' ORDER BY event_id""")

q('7) исходный срез: статусы по всем 8 заявкам когорты', """
WITH p AS (SELECT '2026-10-03 00:00:00' t),
e AS (SELECT d.* FROM decision_events d CROSS JOIN p WHERE d.occurred_at < p.t AND d.loaded_at < p.t),
r AS (SELECT application_id, status, ROW_NUMBER() OVER (PARTITION BY application_id
      ORDER BY occurred_at DESC, event_id DESC) rn FROM e)
SELECT a.application_id, a.is_test, COALESCE(r.status,'unknown') status
FROM applications a CROSS JOIN p
LEFT JOIN r ON r.application_id = a.application_id AND r.rn = 1
WHERE a.created_at >= '2026-10-01 00:00:00' AND a.created_at < p.t
ORDER BY a.application_id""")

open(os.path.join(OUT, 'diagnostics.txt'), 'w', encoding='utf-8').write('\n'.join(L))
