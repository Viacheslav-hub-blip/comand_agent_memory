-- Два режима воспроизведения состояния на одно бизнес-время T = 2026-10-03 00:00:00 UTC.
-- Когорта регистраций: 2026-10-01 00:00:00 <= created_at < 2026-10-03 00:00:00.
--
--   mode = 'as_known'  — исторически известное состояние на T:
--                        occurred_at < T AND loaded_at < T (поздние загрузки не видны).
--   mode = 'restated'  — пересчёт на то же бизнес-время с учётом всех уже загруженных
--                        в снимок поздних событий: occurred_at < T, loaded_at НЕ ограничен.
--
-- В обоих режимах: одна строка на заявку, выбор первой строки в порядке
-- occurred_at DESC, event_id DESC. Отличие только в фильтре loaded_at.
-- Показываются только заявки, у которых режимы разошлись по статусу и/или событию.

WITH params AS (
    SELECT '2026-10-03 00:00:00' AS as_of_utc,
           '2026-10-01 00:00:00' AS cohort_start_utc,
           '2026-10-03 00:00:00' AS cohort_end_utc
),
cohort AS (
    SELECT a.application_id,
           a.created_at,
           a.requested_amount_rub,
           a.is_test,
           a.channel
    FROM applications AS a
    CROSS JOIN params AS p
    WHERE a.created_at >= p.cohort_start_utc
      AND a.created_at <  p.cohort_end_utc
),
candidates AS (
    SELECT 'as_known' AS mode,
           d.event_id,
           d.application_id,
           d.status,
           d.occurred_at,
           d.loaded_at
    FROM decision_events AS d
    CROSS JOIN params AS p
    WHERE d.occurred_at < p.as_of_utc
      AND d.loaded_at   < p.as_of_utc

    UNION ALL

    SELECT 'restated' AS mode,
           d.event_id,
           d.application_id,
           d.status,
           d.occurred_at,
           d.loaded_at
    FROM decision_events AS d
    CROSS JOIN params AS p
    WHERE d.occurred_at < p.as_of_utc
),
ranked AS (
    SELECT c.mode,
           c.application_id,
           c.event_id,
           c.status,
           c.occurred_at,
           c.loaded_at,
           ROW_NUMBER() OVER (
               PARTITION BY c.mode, c.application_id
               ORDER BY c.occurred_at DESC, c.event_id DESC
           ) AS rn
    FROM candidates AS c
),
state_by_mode AS (
    SELECT r.mode,
           r.application_id,
           r.event_id    AS last_event_id,
           r.status      AS status_at_as_of,
           r.occurred_at AS status_occurred_at,
           r.loaded_at   AS status_loaded_at
    FROM ranked AS r
    WHERE r.rn = 1
),
pivoted AS (
    SELECT c.application_id,
           c.created_at,
           c.requested_amount_rub,
           c.is_test,
           c.channel,
           k.status_at_as_of  AS status_as_known,
           k.last_event_id    AS event_as_known,
           k.status_loaded_at AS loaded_as_known,
           r.status_at_as_of  AS status_restated,
           r.last_event_id    AS event_restated,
           r.status_loaded_at AS loaded_restated
    FROM cohort AS c
    LEFT JOIN state_by_mode AS k
           ON k.application_id = c.application_id AND k.mode = 'as_known'
    LEFT JOIN state_by_mode AS r
           ON r.application_id = c.application_id AND r.mode = 'restated'
)
SELECT p.application_id,
       p.created_at,
       p.requested_amount_rub,
       p.is_test,
       p.channel,
       COALESCE(p.status_as_known, 'unknown') AS status_as_known,
       p.event_as_known,
       p.loaded_as_known,
       COALESCE(p.status_restated, 'unknown') AS status_restated,
       p.event_restated,
       p.loaded_restated
FROM pivoted AS p
WHERE COALESCE(p.status_as_known, 'unknown') <> COALESCE(p.status_restated, 'unknown')
   OR COALESCE(p.event_as_known, -1) <> COALESCE(p.event_restated, -1)
ORDER BY p.application_id;
