"""Прогон воспроизводимого среза + сводка метрик v2. csv + sqlite3, без pandas."""
import os
import sqlite3

BASE = 'synthetic_team'
OUT = os.path.join(BASE, 'outputs', 'C02')
DB = os.path.join(OUT, 'north.db')
SQL = open(os.path.join(OUT, 'state_at_2026-10-03.sql'), encoding='utf-8').read()

con = sqlite3.connect(DB)
con.row_factory = sqlite3.Row
rows = [dict(r) for r in con.execute(SQL)]

lines = []
lines.append('=== Отчёт: состояние заявок на 2026-10-03 00:00:00 UTC')
lines.append('Когорта создана: 2026-10-01 00:00:00 <= created_at < 2026-10-03 00:00:00')
lines.append('')
cols = ['application_id', 'created_at', 'requested_amount_rub', 'is_test', 'channel',
        'last_event_id', 'status_at_as_of', 'status_occurred_at', 'status_loaded_at']
lines.append(' | '.join(cols))
for r in rows:
    lines.append(' | '.join('' if r[c] is None else str(r[c]) for c in cols))

# метрики v2
real = [r for r in rows if r['is_test'] == 0]
approved = [r for r in real if r['status_at_as_of'] == 'approved']
final = [r for r in real if r['status_at_as_of'] in ('approved', 'rejected')]
lines.append('')
lines.append('=== Метрики (reporting v2, срез 2026-10-03 00:00:00)')
lines.append(f"всего строк когорты: {len(rows)}")
lines.append(f"реальных (is_test=0): {len(real)}")
lines.append(f"тестовых (is_test=1): {len(rows) - len(real)}")
lines.append(f"approved на срез: {len(approved)}")
lines.append(f"approval_rate = {len(approved)}/{len(real)} = "
             f"{(len(approved)/len(real)) if real else float('nan'):.4f}")
if final:
    lines.append(f"final_decision_approval_rate: знаменатель (approved+rejected) = {len(final)}, "
                 f"значение = {len(approved)/len(final):.4f}")
else:
    lines.append('final_decision_approval_rate: знаменатель 0 — не определено')
lines.append('')
lines.append('Статусы на срез по всем строкам когорты (вкл. тест):')
from collections import Counter
for st, n in sorted(Counter(r['status_at_as_of'] for r in rows).items()):
    lines.append(f"  {st}: {n}")

# контроль: позднее событие A006 не должно просачиваться
a006 = [r for r in rows if r['application_id'] == 'A006']
lines.append('')
lines.append('Контроль A006: ' + str(a006))

# денежные показатели отдельно (booked_at, отдельный период)
pay = con.execute("""
WITH params AS (SELECT '2026-10-01 00:00:00' AS s, '2026-10-03 00:00:00' AS e)
SELECT p.payment_type, COUNT(*) n, SUM(p.amount_rub) amount
FROM payments p CROSS JOIN params
WHERE p.booked_at >= params.s AND p.booked_at < params.e
GROUP BY p.payment_type""").fetchall()
lines.append('')
lines.append('Денежные события booked_at в [2026-10-01, 2026-10-03) — отдельно от решений:')
for r in pay:
    lines.append(f"  {r['payment_type']}: n={r['n']}, сумма={r['amount']}")
d = {r['payment_type']: r['amount'] for r in pay}
lines.append(f"  net_disbursement = {d.get('disbursement', 0)} - {d.get('refund', 0)} = "
             f"{d.get('disbursement', 0) - d.get('refund', 0)}")

text = '\n'.join(lines)
open(os.path.join(OUT, 'report.txt'), 'w', encoding='utf-8').write(text)
print(text)
con.close()
