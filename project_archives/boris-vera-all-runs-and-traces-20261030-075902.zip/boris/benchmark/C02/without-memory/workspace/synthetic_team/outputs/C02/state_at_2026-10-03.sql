-- Воспроизводимый срез состояния заявок на 2026-10-03 00:00:00 UTC.
-- Когорта регистраций: created_at >= '2026-10-01 00:00:00' AND created_at < '2026-10-03 00:00:00'.
-- Одна строка на заявку. Срез знания: occurred_at < T AND loaded_at < T,
-- затем первая строка по (occurred_at DESC, event_id DESC) в рамках заявки.
-- Версия определения метрики: reporting v2 (is_test=1 исключается из approval_rate).
WITH params AS (
    SELECT '2026-10-03 00:00:00' AS as_of_utc,
           '2026-10-01 00:00:00' AS cohort_start_utc,
           '2026-10-03 00:00:00' AS cohort_end_utc
),
cohort AS (
    SELECT a.application_id,
           a.created_at,
           a.requested_amount_rub,
           a.is_test,
           a.channel
    FROM applications AS a
    CROSS JOIN params AS p
    WHERE a.created_at >= p.cohort_start_utc
      AND a.created_at <  p.cohort_end_utc
),
known_events AS (
    SELECT d.event_id,
           d.application_id,
           d.status,
           d.occurred_at,
           d.loaded_at
    FROM decision_events AS d
    CROSS JOIN params AS p
    WHERE d.occurred_at < p.as_of_utc
      AND d.loaded_at   < p.as_of_utc
),
ranked_events AS (
    SELECT e.application_id,
           e.event_id,
           e.status,
           e.occurred_at,
           e.loaded_at,
           ROW_NUMBER() OVER (
               PARTITION BY e.application_id
               ORDER BY e.occurred_at DESC, e.event_id DESC
           ) AS rn
    FROM known_events AS e
),
last_known_state AS (
    SELECT r.application_id,
           r.event_id   AS last_event_id,
           r.status     AS status_at_as_of,
           r.occurred_at AS status_occurred_at,
           r.loaded_at   AS status_loaded_at
    FROM ranked_events AS r
    WHERE r.rn = 1
)
SELECT c.application_id,
       c.created_at,
       c.requested_amount_rub,
       c.is_test,
       c.channel,
       s.last_event_id,
       COALESCE(s.status_at_as_of, 'unknown') AS status_at_as_of,
       s.status_occurred_at,
       s.status_loaded_at
FROM cohort AS c
LEFT JOIN last_known_state AS s
       ON s.application_id = c.application_id
ORDER BY c.application_id;
