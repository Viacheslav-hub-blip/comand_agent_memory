"""C02: режим A (знание на T) vs режим B (пересчёт на то же бизнес-время).

Запуск из рабочего каталога: python tmp/c02_run.py
Исходные CSV не изменяются; результат печатается в stdout для сверки.
"""
import csv
import sqlite3
from pathlib import Path

BASE = Path.cwd() / "synthetic_team"
TABLES = ["applications", "decision_events", "payments", "fraud_labels", "rule_hits"]

COHORT_START = "2026-10-01 00:00:00"
COHORT_END = "2026-10-03 00:00:00"
KNOWN_AT = "2026-10-03 00:00:00"

MODE_A = """-- Режим A: состояние, известное на T (occurred_at < T AND loaded_at < T).
WITH params AS (
    SELECT '{cohort_start}' AS cohort_start_at,
           '{cohort_end}'   AS cohort_end_at,
           '{known_at}'     AS known_at
),
cohort AS (
    SELECT a.application_id,
           a.created_at,
           a.channel,
           a.is_test,
           a.requested_amount_rub
    FROM applications AS a
    CROSS JOIN params AS p
    WHERE a.created_at >= p.cohort_start_at
      AND a.created_at <  p.cohort_end_at
),
events_known AS (
    SELECT d.application_id,
           d.event_id,
           d.status,
           d.occurred_at,
           d.loaded_at
    FROM decision_events AS d
    CROSS JOIN params AS p
    WHERE d.occurred_at < p.known_at
      AND d.loaded_at  < p.known_at
),
ranked AS (
    SELECT e.application_id,
           e.event_id,
           e.status,
           e.occurred_at,
           e.loaded_at,
           ROW_NUMBER() OVER (
               PARTITION BY e.application_id
               ORDER BY e.occurred_at DESC, e.event_id DESC
           ) AS rn
    FROM events_known AS e
),
state_at_cutoff AS (
    SELECT application_id,
           status      AS status_at_cutoff,
           event_id    AS last_event_id,
           occurred_at AS status_occurred_at,
           loaded_at   AS status_loaded_at
    FROM ranked
    WHERE rn = 1
)
SELECT c.application_id,
       c.created_at,
       c.channel,
       c.is_test,
       c.requested_amount_rub,
       s.status_at_cutoff,
       s.last_event_id,
       s.status_occurred_at,
       s.status_loaded_at
FROM cohort AS c
LEFT JOIN state_at_cutoff AS s
       ON s.application_id = c.application_id
ORDER BY c.application_id;
"""

# Режим B отличается только CTE events_known: условие loaded_at снято.
MODE_B = MODE_A.replace(
    """-- Режим A: состояние, известное на T (occurred_at < T AND loaded_at < T).""",
    """-- Режим B: пересчёт на то же бизнес-время (occurred_at < T), loaded_at не ограничен.""",
).replace(
    """    WHERE d.occurred_at < p.known_at
      AND d.loaded_at  < p.known_at""",
    """    WHERE d.occurred_at < p.known_at""",
)

DIFF = """-- Diff режимов A и B: только заявки, где состояние на срез отличается.
WITH params AS (
    SELECT '{cohort_start}' AS cohort_start_at,
           '{cohort_end}'   AS cohort_end_at,
           '{known_at}'     AS known_at
),
cohort AS (
    SELECT a.application_id,
           a.created_at,
           a.is_test,
           a.requested_amount_rub
    FROM applications AS a
    CROSS JOIN params AS p
    WHERE a.created_at >= p.cohort_start_at
      AND a.created_at <  p.cohort_end_at
),
events_in_window AS (
    SELECT d.application_id,
           d.event_id,
           d.status,
           d.occurred_at,
           d.loaded_at
    FROM decision_events AS d
    CROSS JOIN params AS p
    WHERE d.occurred_at < p.known_at
),
ranked_historical AS (
    SELECT e.application_id,
           e.event_id,
           e.status,
           ROW_NUMBER() OVER (
               PARTITION BY e.application_id
               ORDER BY e.occurred_at DESC, e.event_id DESC
           ) AS rn
    FROM events_in_window AS e
    CROSS JOIN params AS p
    WHERE e.loaded_at < p.known_at
),
ranked_restated AS (
    SELECT e.application_id,
           e.event_id,
           e.status,
           ROW_NUMBER() OVER (
               PARTITION BY e.application_id
               ORDER BY e.occurred_at DESC, e.event_id DESC
           ) AS rn
    FROM events_in_window AS e
),
state_historical AS (
    SELECT application_id,
           status   AS status_historical,
           event_id AS event_historical
    FROM ranked_historical
    WHERE rn = 1
),
state_restated AS (
    SELECT application_id,
           status   AS status_restated,
           event_id AS event_restated
    FROM ranked_restated
    WHERE rn = 1
)
SELECT c.application_id,
       c.created_at,
       c.is_test,
       c.requested_amount_rub,
       h.status_historical,
       h.event_historical,
       r.status_restated,
       r.event_restated,
       CASE
           WHEN h.status_historical IS NULL AND r.status_restated IS NOT NULL
               THEN 'event_became_known'
           WHEN h.status_historical IS NOT NULL AND r.status_restated IS NOT NULL
               THEN 'late_loaded_event'
           ELSE 'other'
       END AS different_by
FROM cohort AS c
LEFT JOIN state_historical AS h
       ON h.application_id = c.application_id
LEFT JOIN state_restated AS r
       ON r.application_id = c.application_id
WHERE h.status_historical IS NOT r.status_restated
ORDER BY c.application_id;
"""


def load(con: sqlite3.Connection) -> None:
    con.executescript((BASE / "sql" / "schema.sql").read_text(encoding="utf-8"))
    for t in TABLES:
        with (BASE / "inputs" / f"{t}.csv").open(encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f)
            cols = reader.fieldnames
            con.executemany(
                f"INSERT INTO {t} ({','.join(cols)}) VALUES ({','.join('?' * len(cols))})",
                [[row[c] for c in cols] for row in reader],
            )
    con.commit()


def fmt(sql: str) -> str:
    return sql.format(cohort_start=COHORT_START, cohort_end=COHORT_END, known_at=KNOWN_AT)


def main() -> None:
    con = sqlite3.connect(":memory:")
    load(con)

    a_cur = con.execute(fmt(MODE_A))
    a_cols = [d[0] for d in a_cur.description]
    a_rows = a_cur.fetchall()
    b_cur = con.execute(fmt(MODE_B))
    b_cols = [d[0] for d in b_cur.description]
    b_rows = b_cur.fetchall()
    d_cur = con.execute(fmt(DIFF))
    d_cols = [d[0] for d in d_cur.description]
    d_rows = d_cur.fetchall()

    print("=== MODE A: known at T ===")
    print(",".join(a_cols))
    for r in a_rows:
        print(",".join("" if v is None else str(v) for v in r))
    print("rows =", len(a_rows), "distinct =", len({r[0] for r in a_rows}))

    print("\n=== MODE B: restated ===")
    print(",".join(b_cols))
    for r in b_rows:
        print(",".join("" if v is None else str(v) for v in r))
    print("rows =", len(b_rows), "distinct =", len({r[0] for r in b_rows}))

    print("\n=== DIFF (A != B) ===")
    print(",".join(d_cols))
    for r in d_rows:
        print(",".join("" if v is None else str(v) for v in r))
    print("rows =", len(d_rows))

    print("\n=== CHECKS ===")
    print("A 1:1:", len(a_rows) == len({r[0] for r in a_rows}))
    print("B 1:1:", len(b_rows) == len({r[0] for r in b_rows}))
    print("A rows == cohort:",
          len(a_rows) == con.execute(
              "SELECT COUNT(*) FROM applications WHERE created_at >= ? AND created_at < ?",
              (COHORT_START, COHORT_END)).fetchone()[0])
    print("late-loaded evidence (occurred_at < T, loaded_at >= T):")
    for r in con.execute("""
        SELECT d.application_id, d.event_id, d.status, d.occurred_at, d.loaded_at
        FROM decision_events AS d
        WHERE d.occurred_at < ? AND d.loaded_at >= ?
        ORDER BY d.application_id, d.event_id""", (KNOWN_AT, KNOWN_AT)):
        print("  ", r)

    a_csv = ",".join(a_cols) + "\n" + "\n".join(
        ",".join("" if v is None else str(v) for v in r) for r in a_rows) + "\n"
    b_csv = ",".join(b_cols) + "\n" + "\n".join(
        ",".join("" if v is None else str(v) for v in r) for r in b_rows) + "\n"
    d_csv = ",".join(d_cols) + "\n" + "\n".join(
        ",".join("" if v is None else str(v) for v in r) for r in d_rows) + "\n"
    out = Path("tmp")
    (out / "mode_a.csv").write_text(a_csv, encoding="utf-8", newline="")
    (out / "mode_b.csv").write_text(b_csv, encoding="utf-8", newline="")
    (out / "diff.csv").write_text(d_csv, encoding="utf-8", newline="")


if __name__ == "__main__":
    main()
