import csv, sqlite3
from pathlib import Path

b = Path.cwd() / "synthetic_team"
con = sqlite3.connect(":memory:")
con.executescript((b / "sql" / "schema.sql").read_text(encoding="utf-8"))
for t in ["applications", "decision_events"]:
    with (b / "inputs" / f"{t}.csv").open(encoding="utf-8", newline="") as f:
        r = csv.DictReader(f); cols = r.fieldnames
        con.executemany(
            f"INSERT INTO {t} ({','.join(cols)}) VALUES ({','.join('?' * len(cols))})",
            [[row[c] for c in cols] for row in r])

sql = """
SELECT COUNT(*), SUM(requested_amount_rub) FROM (
  SELECT DISTINCT a.application_id, a.requested_amount_rub
  FROM applications AS a
  JOIN decision_events AS d ON d.application_id = a.application_id
  WHERE a.created_at >= '2026-10-01 00:00:00'
    AND a.created_at <  '2026-10-03 00:00:00'
    AND d.status = 'approved'
)
"""
print("DISTINCT demo (count, sum):", con.execute(sql).fetchone())
print("naive count distinct:", con.execute("""
SELECT COUNT(*), COUNT(DISTINCT a.application_id)
FROM applications AS a JOIN decision_events AS d ON d.application_id = a.application_id
WHERE a.created_at >= '2026-10-01 00:00:00' AND a.created_at < '2026-10-03 00:00:00'
""").fetchone())
