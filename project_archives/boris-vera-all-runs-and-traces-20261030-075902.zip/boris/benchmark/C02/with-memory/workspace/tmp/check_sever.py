import csv, sqlite3
from pathlib import Path

base = Path.cwd() / "synthetic_team"
print("base =", base, base.exists())
con = sqlite3.connect(":memory:")
con.executescript((base / "sql" / "schema.sql").read_text(encoding="utf-8"))

tables = ["applications", "decision_events", "payments", "fraud_labels", "rule_hits"]
for t in tables:
    with (base / "inputs" / f"{t}.csv").open(encoding="utf-8", newline="") as f:
        r = csv.DictReader(f)
        cols = r.fieldnames
        rows = [[row[c] for c in cols] for row in r]
    con.executemany(f"INSERT INTO {t} ({','.join(cols)}) VALUES ({','.join('?'*len(cols))})", rows)
    print(t, "rows =", len(rows))
con.commit()

print("\n--- KEY CHECKS ---")
q = {
 "applications dup application_id": "SELECT COUNT(*) FROM (SELECT application_id FROM applications GROUP BY 1 HAVING COUNT(*)>1)",
 "applications PK count": "SELECT COUNT(*) FROM applications",
 "decision_events dup event_id": "SELECT COUNT(*) FROM (SELECT event_id FROM decision_events GROUP BY 1 HAVING COUNT(*)>1)",
 "decision_events rows": "SELECT COUNT(*) FROM decision_events",
 "payments dup payment_id": "SELECT COUNT(*) FROM (SELECT payment_id FROM payments GROUP BY 1 HAVING COUNT(*)>1)",
 "fraud_labels dup label_id": "SELECT COUNT(*) FROM (SELECT label_id FROM fraud_labels GROUP BY 1 HAVING COUNT(*)>1)",
 "rule_hits dup (rule_id,application_id)": "SELECT COUNT(*) FROM (SELECT 1 FROM rule_hits GROUP BY rule_id, application_id HAVING COUNT(*)>1)",
}
for k, s in q.items():
    print(f"{k}: {con.execute(s).fetchone()[0]}")

print("\n--- ORPHAN FK ---")
for t in ["decision_events", "payments", "fraud_labels", "rule_hits"]:
    n = con.execute(f"SELECT COUNT(*) FROM {t} x LEFT JOIN applications a ON a.application_id=x.application_id WHERE a.application_id IS NULL").fetchone()[0]
    print(t, "orphans =", n)

print("\n--- COUNT(DISTINCT application_id) per table ---")
for t in tables:
    n, d = con.execute(f"SELECT COUNT(*), COUNT(DISTINCT application_id) FROM {t}").fetchone()
    print(t, n, d)

print("\n--- LEGACY ---")
legacy = (base / "sql" / "legacy_approval.sql").read_text(encoding="utf-8")
print(con.execute(legacy).fetchone())
print("legacy rows detail:")
rows = con.execute("""
SELECT a.application_id, a.created_at, a.is_test, a.requested_amount_rub,
       d.event_id, d.status, d.occurred_at, d.loaded_at
FROM applications a JOIN decision_events d ON d.application_id=a.application_id
WHERE a.created_at >= '2026-10-01 00:00:00' AND a.created_at < '2026-10-03 00:00:00'
  AND d.status='approved'
ORDER BY a.application_id, d.event_id""").fetchall()
for r in rows: print(r)

params = dict(cohort_start_at="2026-10-01 00:00:00", cohort_end_at="2026-10-03 00:00:00", known_at="2026-10-03 00:00:00")

mode_a = """
WITH params AS (SELECT '2026-10-01 00:00:00' AS cohort_start_at,
                       '2026-10-03 00:00:00' AS cohort_end_at,
                       '2026-10-03 00:00:00' AS known_at),
cohort AS (
  SELECT a.application_id, a.created_at, a.channel, a.is_test, a.requested_amount_rub
  FROM applications a CROSS JOIN params p
  WHERE a.created_at >= p.cohort_start_at AND a.created_at < p.cohort_end_at),
events_known AS (
  SELECT d.application_id, d.event_id, d.status, d.occurred_at, d.loaded_at
  FROM decision_events d CROSS JOIN params p
  WHERE d.occurred_at < p.known_at AND d.loaded_at < p.known_at),
ranked AS (
  SELECT e.application_id, e.event_id, e.status, e.occurred_at, e.loaded_at,
         ROW_NUMBER() OVER (PARTITION BY e.application_id
                            ORDER BY e.occurred_at DESC, e.event_id DESC) AS rn
  FROM events_known e),
state_at_cutoff AS (
  SELECT application_id, status AS status_at_cutoff, event_id AS last_event_id,
         occurred_at AS status_occurred_at, loaded_at AS status_loaded_at
  FROM ranked WHERE rn = 1)
SELECT c.application_id, c.created_at, c.channel, c.is_test, c.requested_amount_rub,
       s.status_at_cutoff, s.last_event_id, s.status_occurred_at, s.status_loaded_at
FROM cohort c LEFT JOIN state_at_cutoff s ON s.application_id = c.application_id
ORDER BY c.application_id"""

print("\n--- MODE A (known at T) ---")
a_rows = con.execute(mode_a).fetchall()
for r in a_rows: print(r)
print("rows =", len(a_rows), "distinct apps =", len({r[0] for r in a_rows}))

mode_b = mode_a.replace("WHERE d.occurred_at < p.known_at AND d.loaded_at < p.known_at",
                        "WHERE d.occurred_at < p.known_at")
print("\n--- MODE B (restated) ---")
b_rows = con.execute(mode_b).fetchall()
for r in b_rows: print(r[:6])

print("\n--- DIFF ---")
A = {r[0]: r for r in a_rows}
B = {r[0]: r for r in b_rows}
for aid in sorted(A):
    if A[aid][5] != B[aid][5]:
        print(aid, "A:", A[aid][5], "event", A[aid][6], "| B:", B[aid][5], "event", B[aid][6])

print("\n--- COUNTS ---")
for st in ["approved", "rejected", "cancelled", "manual_review", None]:
    print(st, sum(1 for r in a_rows if r[5] == st))
print("sum requested_amount all:", sum(r[4] for r in a_rows))
print("sum requested_amount approved A:", sum(r[4] for r in a_rows if r[5] == "approved"))
print("sum requested_amount approved non-test:", sum(r[4] for r in a_rows if r[5] == "approved" and r[3] == 0))

n = len(a_rows); non_test = [r for r in a_rows if r[3] == 0]
print("v1 approval_rate:", sum(1 for r in a_rows if r[5]=="approved"), "/", n)
print("v2 approval_rate:", sum(1 for r in non_test if r[5]=="approved"), "/", len(non_test))
fin = [r for r in non_test if r[5] in ("approved","rejected")]
print("final_decision_approval_rate:", sum(1 for r in fin if r[5]=="approved"), "/", len(fin))

print("\n--- NAIVE JOIN CONTROL ---")
print(con.execute("""SELECT COUNT(*), COUNT(DISTINCT a.application_id)
FROM applications a JOIN decision_events d ON d.application_id=a.application_id
WHERE a.created_at >= '2026-10-01 00:00:00' AND a.created_at < '2026-10-03 00:00:00'""").fetchone())

print("\n--- DISTINCT DEMO ---")
print(con.execute("""SELECT COUNT(*), SUM(a.requested_amount_rub)
FROM (SELECT DISTINCT a.application_id, a.requested_amount_rub
      FROM applications a JOIN decision_events d ON d.application_id=a.application_id
      WHERE a.created_at >= '2026-10-01 00:00:00' AND a.created_at < '2026-10-03 00:00:00'
        AND d.status='approved')""").fetchone())
