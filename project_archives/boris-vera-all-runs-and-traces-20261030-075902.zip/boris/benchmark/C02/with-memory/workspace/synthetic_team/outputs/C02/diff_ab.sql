-- C02 / diff режимов: только заявки, у которых состояние на срез различается.
-- Состояние A = знание на T (occurred_at < T AND loaded_at < T);
-- состояние B = пересчёт на то же бизнес-время (occurred_at < T, loaded_at не ограничен).
-- different_by: late_loaded_event — событие произошло до T, но загружено после T;
--               event_became_known — в A событий не было, в B появилось;
--               other — прочие причины (в этом снимке не встречаются).
WITH params AS (
    SELECT '2026-10-01 00:00:00' AS cohort_start_at,
           '2026-10-03 00:00:00' AS cohort_end_at,
           '2026-10-03 00:00:00' AS known_at
),
cohort AS (
    SELECT a.application_id,
           a.created_at,
           a.is_test,
           a.requested_amount_rub
    FROM applications AS a
    CROSS JOIN params AS p
    WHERE a.created_at >= p.cohort_start_at
      AND a.created_at <  p.cohort_end_at
),
events_in_business_time AS (
    SELECT d.application_id,
           d.event_id,
           d.status,
           d.occurred_at,
           d.loaded_at
    FROM decision_events AS d
    CROSS JOIN params AS p
    WHERE d.occurred_at < p.known_at
),
ranked_historical AS (
    SELECT e.application_id,
           e.event_id,
           e.status,
           ROW_NUMBER() OVER (
               PARTITION BY e.application_id
               ORDER BY e.occurred_at DESC, e.event_id DESC
           ) AS rn
    FROM events_in_business_time AS e
    CROSS JOIN params AS p
    WHERE e.loaded_at < p.known_at
),
ranked_restated AS (
    SELECT e.application_id,
           e.event_id,
           e.status,
           ROW_NUMBER() OVER (
               PARTITION BY e.application_id
               ORDER BY e.occurred_at DESC, e.event_id DESC
           ) AS rn
    FROM events_in_business_time AS e
),
state_historical AS (
    SELECT application_id,
           status   AS status_historical,
           event_id AS event_historical
    FROM ranked_historical
    WHERE rn = 1
),
state_restated AS (
    SELECT application_id,
           status   AS status_restated,
           event_id AS event_restated
    FROM ranked_restated
    WHERE rn = 1
)
SELECT c.application_id,
       c.created_at,
       c.is_test,
       c.requested_amount_rub,
       h.status_historical,
       h.event_historical,
       r.status_restated,
       r.event_restated,
       CASE
           WHEN h.status_historical IS NULL AND r.status_restated IS NOT NULL
               THEN 'event_became_known'
           WHEN h.status_historical IS NOT NULL AND r.status_restated IS NOT NULL
               THEN 'late_loaded_event'
           ELSE 'other'
       END AS different_by
FROM cohort AS c
LEFT JOIN state_historical AS h
       ON h.application_id = c.application_id
LEFT JOIN state_restated AS r
       ON r.application_id = c.application_id
WHERE h.status_historical IS NOT r.status_restated
ORDER BY c.application_id;
