-- Схема учебных CSV команды «Север» для SQLite.
-- Вход: CSV из inputs. Выход: пустые таблицы для локального импорта.
-- Функций и процедур нет. application_id в историях намеренно не уникален.
CREATE TABLE applications (
    application_id TEXT PRIMARY KEY,
    created_at TEXT NOT NULL,
    requested_amount_rub INTEGER NOT NULL,
    is_test INTEGER NOT NULL CHECK (is_test IN (0, 1)),
    channel TEXT NOT NULL
);
CREATE TABLE decision_events (
    event_id INTEGER PRIMARY KEY,
    application_id TEXT NOT NULL REFERENCES applications(application_id),
    status TEXT NOT NULL,
    occurred_at TEXT NOT NULL,
    loaded_at TEXT NOT NULL
);
CREATE TABLE payments (
    payment_id TEXT PRIMARY KEY,
    application_id TEXT NOT NULL REFERENCES applications(application_id),
    payment_type TEXT NOT NULL CHECK (payment_type IN ('disbursement', 'refund')),
    amount_rub INTEGER NOT NULL CHECK (amount_rub > 0),
    booked_at TEXT NOT NULL
);
CREATE TABLE fraud_labels (
    label_id TEXT PRIMARY KEY,
    application_id TEXT NOT NULL REFERENCES applications(application_id),
    label TEXT NOT NULL CHECK (label IN ('confirmed_fraud', 'legitimate')),
    recorded_at TEXT NOT NULL,
    reason TEXT NOT NULL
);
CREATE TABLE rule_hits (
    rule_id TEXT NOT NULL,
    application_id TEXT NOT NULL REFERENCES applications(application_id),
    hit_at TEXT NOT NULL,
    PRIMARY KEY (rule_id, application_id)
);
