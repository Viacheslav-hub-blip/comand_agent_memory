-- Старый запрос для диагностики, корректность не подтверждена.
-- Вход: applications и decision_events. Выход: число строк approved и сумма.
-- Функций и процедур нет. Этот запрос необходимо проверить по документации.
SELECT
    COUNT(*) AS approved_count,
    SUM(a.requested_amount_rub) AS approved_amount_rub
FROM applications AS a
JOIN decision_events AS d ON d.application_id = a.application_id
WHERE a.created_at >= '2026-10-01 00:00:00'
  AND a.created_at < '2026-10-03 00:00:00'
  AND d.status = 'approved';
