"""C02: воспроизводимый прогон режимов A/B и diff в локальном SQLite на CSV.

Запуск из рабочего каталога (каталог, содержащий synthetic_team):
    python synthetic_team/outputs/C02/run_c02.py

Что делает:
  1) создаёт временную in-memory SQLite по synthetic_team/sql/schema.sql;
  2) импортирует CSV из synthetic_team/inputs (только чтение, исходники не меняются);
  3) выполняет три SQL-файла из этого каталога: mode_a_known_at_cutoff.sql,
     mode_b_restated.sql, diff_ab.sql;
  4) печатает результат в формате CSV и выполняет проверки кардинальности и
     негативный контроль;
  5) прогоняет запросы повторно и убеждается, что результат идентичен.

Зависимости: только стандартные csv и sqlite3 (pandas и сторонние пакеты не нужны).
"""
import csv
import hashlib
import sqlite3
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = HERE.parents[1]  # .../synthetic_team
TABLES = ["applications", "decision_events", "payments", "fraud_labels", "rule_hits"]

COHORT_START = "2026-10-01 00:00:00"
COHORT_END = "2026-10-03 00:00:00"

SQL_FILES = {
    "mode_a": HERE / "mode_a_known_at_cutoff.sql",
    "mode_b": HERE / "mode_b_restated.sql",
    "diff": HERE / "diff_ab.sql",
}


def load(con: sqlite3.Connection) -> None:
    con.executescript((BASE / "sql" / "schema.sql").read_text(encoding="utf-8"))
    for table in TABLES:
        with (BASE / "inputs" / f"{table}.csv").open(encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f)
            cols = reader.fieldnames
            con.executemany(
                f"INSERT INTO {table} ({', '.join(cols)}) "
                f"VALUES ({', '.join('?' * len(cols))})",
                [[row[c] for c in cols] for row in reader],
            )
    con.commit()


def run(con: sqlite3.Connection, name: str):
    sql = SQL_FILES[name].read_text(encoding="utf-8")
    cur = con.execute(sql)
    cols = [d[0] for d in cur.description]
    return cols, cur.fetchall()


def to_csv(cols, rows) -> str:
    lines = [",".join(cols)]
    lines += [",".join("" if v is None else str(v) for v in r) for r in rows]
    return "\n".join(lines) + "\n"


def main() -> None:
    con = sqlite3.connect(":memory:")
    load(con)

    results = {name: run(con, name) for name in ("mode_a", "mode_b", "diff")}
    again = {name: run(con, name) for name in ("mode_a", "mode_b", "diff")}

    out_names = {"mode_a": "mode_a_known_at_cutoff.csv",
                 "mode_b": "mode_b_restated.csv",
                 "diff": "diff_ab.csv"}
    for name, (cols, rows) in results.items():
        text = to_csv(cols, rows)
        (HERE / out_names[name]).write_text(text, encoding="utf-8", newline="")
        print(f"=== {name} ===")
        print(text, end="")
        print(f"rows = {len(rows)}\n")

    print("=== checks ===")
    a_cols, a_rows = results["mode_a"]
    b_cols, b_rows = results["mode_b"]
    cohort_size = con.execute(
        "SELECT COUNT(*) FROM applications WHERE created_at >= ? AND created_at < ?",
        (COHORT_START, COHORT_END),
    ).fetchone()[0]
    print(f"CHECK 01 mode_a 1:1: {len(a_rows)} строк / "
          f"{len({r[0] for r in a_rows})} заявок -> "
          f"{'PASS' if len(a_rows) == len({r[0] for r in a_rows}) else 'FAIL'}")
    print(f"CHECK 02 mode_b 1:1: {len(b_rows)} строк / "
          f"{len({r[0] for r in b_rows})} заявок -> "
          f"{'PASS' if len(b_rows) == len({r[0] for r in b_rows}) else 'FAIL'}")
    print(f"CHECK 03 cohort preserved: {len(a_rows)} = {cohort_size} -> "
          f"{'PASS' if len(a_rows) == cohort_size else 'FAIL'}")
    print(f"CHECK 04 diff only changed apps -> "
          f"{'PASS' if all(r[4] != r[6] for r in results['diff'][1]) else 'FAIL'}")
    naive = con.execute(
        """
        SELECT COUNT(*), COUNT(DISTINCT a.application_id)
        FROM applications AS a
        JOIN decision_events AS d ON d.application_id = a.application_id
        WHERE a.created_at >= ? AND a.created_at < ?
        """,
        (COHORT_START, COHORT_END),
    ).fetchone()
    print(f"CHECK 05 negative control naive JOIN: {naive[0]} строк на {naive[1]} заявок -> "
          f"{'FAIL (ожидаемо)' if naive[0] != naive[1] else 'PASS — проверка нечувствительна!'}")
    print(f"CHECK 06 reproducible: "
          f"{'PASS' if results == again else 'FAIL'}")

    print("CHECK 07 source files unchanged (SHA256):")
    sources = [BASE / "inputs" / f"{t}.csv" for t in TABLES] + [BASE / "sql" / "schema.sql"]
    for path in sources:
        print(f"  {path.relative_to(BASE).as_posix()}  "
              f"{hashlib.sha256(path.read_bytes()).hexdigest()}")


if __name__ == "__main__":
    main()
