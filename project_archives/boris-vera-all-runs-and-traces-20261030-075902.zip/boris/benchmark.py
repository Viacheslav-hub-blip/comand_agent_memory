"""Сравнение новых воспроизведений C02 и C06 с памятью и без неё.

Функции: run_case — один изолированный диалог и Markdown-трасса;
save_metrics — сводка измерений агента и тестировщика; main — подготовка
новой памяти с ревью, запуск четырёх диалогов и сохранение статуса;
recover_memory — восстановление личной части после нарушения границ знаний.
finalize_review — исправление формата сохранённого решения и проверка снимков.
Вход: завершённые отчёты анализа и исходные сценарии проекта.
Выход: benchmark/memory, трассы, результаты и metrics.json/metrics.md.
"""
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
from pathlib import Path
import shutil
import sys

from command_agent_memory.memory.file_storage import MemoryLayout
from command_agent_memory.memory.personal_memory import (
    MemoryProposal, consolidate_with_review, publish_memory, read_memory,
    review_memory, write_snapshot, parse_review_decision,
)
from command_agent_memory.memory_evaluation.dialogue_runner import run_dialogue
from command_agent_memory.memory_evaluation.replay_evaluation import load_replay_scenario
from command_agent_memory.pipeline_config import StageRuntime
from command_agent_memory.project_paths import ROOT, get_skill_path
from command_agent_memory.run_reports import read_reports


MODEL = "deepseek/deepseek-v4.1-flash-1017"
BASE = Path(__file__).resolve().parent
OUTPUT = BASE / "benchmark"


def run_case(case: str, enabled: bool) -> dict:
    """Принимает C02/C06 и флаг памяти; возвращает итог опыта с путями файлов.

    Создаёт независимую копию входов. Ошибку диалога сохраняет как failed,
    сохраняя частичную трассу и измерения; другие опыты продолжаются.
    """
    variant = "with-memory" if enabled else "without-memory"
    directory = OUTPUT / case / variant
    workspace = directory / "workspace"
    workspace.mkdir(parents=True)
    shutil.copytree(OUTPUT / "inputs/synthetic_team", workspace / "synthetic_team")
    if enabled:
        shutil.copytree(OUTPUT / "memory", workspace, dirs_exist_ok=True)
    scenario = load_replay_scenario(OUTPUT / f"scenarios/{case}.json")
    error = None
    try:
        run_dialogue(workspace, scenario, directory / "result", MODEL,
                     user_id="102", memory_enabled=enabled)
    except Exception as failure:
        error = f"{type(failure).__name__}: {failure}"
    trace = directory / "result/transcript.jsonl"
    if trace.exists():
        with (directory / "trace.md").open("w", encoding="utf-8") as output:
            output.write(f"# {case}: {variant}\n\nПолная трасса сообщений и инструментов.\n")
            for number, line in enumerate(trace.read_text(encoding="utf-8").splitlines(), 1):
                message = json.loads(line)
                output.write(f"\n## {number}: {message.get('type', 'message')}\n\n")
                output.write("```json\n" + json.dumps(message, ensure_ascii=False, indent=2) + "\n```\n")
    return {"case": case, "variant": variant, "error": error,
            "metrics": str(directory / "result/metrics.json"), "trace": str(trace)}


def save_metrics(results: list[dict]) -> None:
    """Принимает завершённые опыты; сохраняет JSON и таблицу доступных измерений.

    Неизвестные токены остаются null. Стоимость не вычисляется без фактического
    биллинга провайдера. Измерения тестировщика отделены от решающего агента.
    """
    rows = []
    for result in sorted(results, key=lambda item: (item["case"], item["variant"])):
        path = Path(result["metrics"])
        metrics = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
        for role in ("tested_agent", "tester"):
            values = metrics.get(role) or {}
            usage = list((values.get("usage") or {}).values())
            inputs = sum(item.get("input_tokens", 0) for item in usage) if usage else None
            cached = sum((item.get("input_token_details") or {}).get("cache_read", 0) for item in usage) if usage else None
            outputs = sum(item.get("output_tokens", 0) for item in usage) if usage else None
            rows.append({**result, "role": role, "state": metrics.get("state", "failed"),
                         "user_turns": metrics.get("user_turns"), **values,
                         "input_tokens": inputs, "cached_tokens": cached,
                         "new_input_tokens": inputs - cached if inputs is not None else None,
                         "output_tokens": outputs, "cost_usd": None})
    (OUTPUT / "metrics.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    columns = ["case", "variant", "role", "state", "user_turns", "duration_seconds",
               "model_calls", "tool_calls", "input_tokens", "cached_tokens", "new_input_tokens",
               "output_tokens", "usage_complete"]
    table = ["| " + " | ".join(columns) + " |", "| " + " | ".join("---" for _ in columns) + " |"]
    table += ["| " + " | ".join(str(row.get(column)) for column in columns) + " |" for row in rows]
    (OUTPUT / "metrics.md").write_text(
        "# Новые прогоны Бориса\n\nПовтор знакомых задач; по одному опыту на вариант.\n"
        "Успех — решение модельного тестировщика. Стоимость неизвестна.\n"
        "Построение памяти учитывается отдельно в memory-build/*.metrics.json.\n\n"
        + "\n".join(table) + "\n", encoding="utf-8")


def recover_memory(target: Path, layout: MemoryLayout, runtime: StageRuntime) -> None:
    """Принимает цель и настройки; отменяет чужие изменения и публикует после ревью.

    Личные файлы восстанавливает из полного diff их создания, предметные файлы
    берёт из черновика. Исходную неудачную попытку целиком сохраняет отдельно.
    Возвращает None; при неполном diff или отказе ревью вызывает исключение.
    """
    run = OUTPUT / "memory-build"
    failed = OUTPUT / "failed-attempts/memory-build-001"
    if not run.resolve().is_relative_to(OUTPUT.resolve()) or not failed.resolve().is_relative_to(OUTPUT.resolve()):
        raise ValueError("Каталоги восстановления должны находиться внутри опыта.")
    if failed.exists():
        raise ValueError("Эта попытка восстановления уже выполнялась.")
    original = read_memory(run / "workspace/memory", "personal", layout)
    recovered = {name: content for name, content in original.items() if name.startswith("knowledge/")}
    name = None
    for line in (run / "report/personal.diff").read_text(encoding="utf-8").splitlines(keepends=True):
        if line.startswith("+++ after/"):
            name = line.removeprefix("+++ after/").strip()
            if not any(Path(name).is_relative_to(Path(entry)) for entry in layout.personal):
                raise ValueError("Личный diff содержит посторонний путь.")
            recovered[name] = b""
        elif line.startswith("@@"):
            if not line.startswith("@@ -0,0 "):
                raise ValueError("Восстановление поддерживает только полный diff создания.")
        elif line.startswith("+") and name is not None:
            recovered[name] += line[1:].encode("utf-8")
    if not recovered.get("USER_PREFERENCES.md") or not recovered.get("AGENTS.md"):
        raise ValueError("Личный снимок неполон.")
    failed.parent.mkdir(exist_ok=True)
    run.rename(failed)
    run.mkdir()
    for filename in ("materials.md", "rules.md", "memory_review_instructions.md", "memory_review_examples.md"):
        shutil.copy2(failed / filename, run / filename)
    before = read_memory(target, "personal", layout)
    write_snapshot(run / "before", before)
    write_snapshot(run / "before-review", recovered)
    write_snapshot(run / "workspace/memory", recovered)
    (run / "reviews").mkdir()
    runtime.save(run / "configuration")
    proposal = MemoryProposal(target, "personal", run, before, recovered, layout)
    proposal, decision = review_memory(proposal, "", MODEL, runner=runtime.runner("review"))
    if decision["decision"] != "accepted":
        raise RuntimeError(f"Ревью не приняло память: {decision['summary']}")
    publish_memory(target, before, proposal.after, "personal", run, layout)
    (run / "status.json").write_text(json.dumps({"state": "published", "recovered_from": str(failed),
        "review": decision}, ensure_ascii=False, indent=2), encoding="utf-8")


def finalize_review(target: Path, layout: MemoryLayout, runtime: StageRuntime) -> None:
    """Принимает цель и настройки; уточняет формат решения без повторного редактирования.

    Сверяет исходную память и личный снимок, требует строгого принятия без
    findings, сохраняет проверенный снимок и публикует его. Возвращает None.
    """
    run = OUTPUT / "memory-build"
    failed = OUTPUT / "failed-attempts/memory-build-001"
    original = read_memory(failed / "workspace/memory", "personal", layout)
    expected = {name: content for name, content in original.items() if name.startswith("knowledge/")}
    name = None
    for line in (failed / "report/personal.diff").read_text(encoding="utf-8").splitlines(keepends=True):
        if line.startswith("+++ after/"):
            name = line.removeprefix("+++ after/").strip()
            expected[name] = b""
        elif line.startswith("+") and name is not None:
            expected[name] += line[1:].encode("utf-8")
    before = read_memory(run / "before", "personal", layout)
    if before != read_memory(target, "personal", layout) or before:
        raise RuntimeError("Исходная пустая память изменилась.")
    if expected != read_memory(run / "before-review", "personal", layout):
        raise RuntimeError("Снимок до ревью изменился.")
    previous = (run / "reviews/review-001.last.txt").read_text(encoding="utf-8")
    reply = runtime.run("review", "Исправь только формат сохранённого решения ревью. "
        "Не меняй вывод и не придумывай новые findings. Верни ровно JSON с полями "
        "decision (accepted|changes_requested|needs_resolution), summary (строка), "
        "findings (список объектов file/problem/change). Если в заключении остались "
        "нерешённые проблемы, перечисли их; если прямо подтверждено их отсутствие, "
        "верни пустой список. Сохранённое решение:\n" + previous,
        run, run / "reviews/review-format")
    decision = parse_review_decision(reply)
    if decision["decision"] != "accepted" or decision["findings"]:
        raise RuntimeError("Уточнённое решение не подтверждает принятие памяти.")
    draft = run / "workspace/memory"
    after = read_memory(draft, "personal", layout)
    if set(read_memory(draft, "knowledge")) - set(after):
        raise RuntimeError("Ревьюер создал файлы вне настроенной памяти.")
    (run / "reviews/review-001.json").write_text(json.dumps(decision, ensure_ascii=False, indent=2), encoding="utf-8")
    write_snapshot(run / "after", after)
    publish_memory(target, before, after, "personal", run, layout)
    (run / "status.json").write_text(json.dumps({"state": "published", "review": decision,
        "format_repair": True}, ensure_ascii=False, indent=2), encoding="utf-8")


def main(resume: bool = False, finish_review: bool = False) -> None:
    """Принимает флаги восстановления; собирает память и сравнивает четыре диалога.

    Возвращает None. Сохраняет текущий этап в status.json, ошибки отдельных
    опытов — в сводке; ошибка подготовки памяти останавливает весь опыт.
    """
    continuing = resume or finish_review
    OUTPUT.mkdir(exist_ok=continuing)
    status = {"state": "running", "stage": "memory-build", "results": []}
    status_path = OUTPUT / "status.json"
    status_path.write_text(json.dumps(status), encoding="utf-8")
    try:
        if not continuing:
            shutil.copytree(ROOT / "user_workspace/synthetic_team", OUTPUT / "inputs/synthetic_team")
            shutil.copytree(ROOT / "data/memory-benchmark-v4-20261028/reference", OUTPUT / "reference")
        (OUTPUT / "scenarios").mkdir(exist_ok=continuing)
        for case, source in (("C02", "02-boris-history.md"), ("C06", "06-boris-investigation.md")):
            scenario = {"dialogue_source": str(ROOT / "docs/examples/synthetic_team_dialogues/chats" / source),
                        "inputs": "../inputs/synthetic_team", "reference": "../reference",
                        "goal": "Выполнить все требования исходных реплик сценария, сохранить требуемые артефакты и проверить правильность по относящейся к нему части эталона."}
            (OUTPUT / f"scenarios/{case}.json").write_text(json.dumps(scenario, ensure_ascii=False, indent=2), encoding="utf-8")
        reports = Path(json.loads((BASE / "status.json").read_text(encoding="utf-8"))["reports"])
        context, procedures, count = read_reports(reports, user_id="102")
        if count != 2:
            raise ValueError("Ожидались завершённые отчёты двух чатов Бориса.")
        target = OUTPUT / "memory"
        target.mkdir(exist_ok=continuing)
        runtime = StageRuntime({"defaults": {"provider": "openrouter", "model": MODEL}}, OUTPUT)
        layout = MemoryLayout(("AGENTS.md", "USER_PREFERENCES.md", "user_llm_wiki"), ("knowledge",))
        if finish_review:
            finalize_review(target, layout, runtime)
        elif resume:
            recover_memory(target, layout, runtime)
        else:
            consolidate_with_review(target, "personal", context, get_skill_path("personal-memory-consolidation"),
                                    "", MODEL, OUTPUT / "memory-build", knowledge_materials=procedures,
                                    user_id="102", replay_context=reports, layout=layout, runtime=runtime)
        status["stage"] = "replay"
        status_path.write_text(json.dumps(status), encoding="utf-8")
        with ThreadPoolExecutor(max_workers=2) as pool:
            pending = [pool.submit(run_case, case, enabled) for case in ("C02", "C06") for enabled in (False, True)]
            for future in as_completed(pending):
                status["results"].append(future.result())
                save_metrics(status["results"])
                status_path.write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding="utf-8")
        status["state"] = "completed" if all(not item["error"] for item in status["results"]) else "failed"
        status["stage"] = "finished"
    except BaseException as error:
        status.update(state="failed", error=f"{type(error).__name__}: {error}")
        raise
    finally:
        status_path.write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main("--resume" in sys.argv[1:], "--finish-review" in sys.argv[1:])
