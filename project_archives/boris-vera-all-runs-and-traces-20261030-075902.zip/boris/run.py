"""Повторный анализ двух чатов Бориса установленными скилами.

Функции: main — проверяет источник, сохраняет версии скилов, запускает анализ
и записывает итоговый статус. Вход: configuration.json; выход: отчёты и status.json.
"""
import hashlib
import json
from pathlib import Path

from command_agent_memory.memory_pipeline import analyze_source, validate_users
from command_agent_memory.pipeline_config import StageRuntime, read_configuration
from command_agent_memory.project_paths import SKILLS_ROOT


def main() -> None:
    """Без аргументов читает настройки рядом со скриптом и сохраняет отчёты.

    Возвращает None; при ошибке записывает failed в status.json и повторно
    вызывает исключение, чтобы процесс завершился с ненулевым кодом.
    """
    root = Path(__file__).resolve().parent
    status = {"state": "running"}
    status_path = root / "status.json"
    status_path.write_text(json.dumps(status), encoding="utf-8")
    try:
        configuration = read_configuration(root / "configuration.json")
        runtime = StageRuntime(configuration, root)
        users = validate_users(configuration, root)
        runtime.validate({"context", "procedures"}, load_providers=True)
        versions = {
            path.relative_to(SKILLS_ROOT).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(SKILLS_ROOT.rglob("*.md"))
        }
        (root / "skills-sha256.json").write_text(
            json.dumps(versions, indent=2), encoding="utf-8")
        reports = analyze_source(users[0], runtime)
        status.update(state="completed", reports=str(reports))
    except BaseException as error:
        status.update(state="failed", error=str(error))
        raise
    finally:
        status_path.write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
