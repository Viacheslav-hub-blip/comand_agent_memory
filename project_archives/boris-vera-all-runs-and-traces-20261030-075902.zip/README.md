# Все результаты новых прогонов Бориса и Веры

В архив полностью скопированы два каталога завершённых опытов:
- boris/ — data/boris-analysis-20261029-1558
- vera/ — data/vera-analysis-20261030

Включены все файлы исходных каталогов: отчёты анализа чатов, подготовленная
память и её снимки, ревью, полные JSONL- и Markdown-трассы, исходные данные,
созданные SQL/CSV и другие артефакты, метрики, конфигурации, скрипты запусков,
журналы, неудачные попытки и ранее собранные отдельные ZIP-архивы.
Оригинальные файлы сохранены на прежних местах.

Основные отчёты:
- boris/benchmark/comparison.md
- boris/benchmark/comparison.json
- vera/benchmark/comparison.md
- vera/benchmark/comparison.json

Трассы Бориса: boris/benchmark/C02/ и boris/benchmark/C06/.
Трассы Веры: vera/benchmark/C03/ и vera/benchmark/C07/.
В каждом сценарии есть with-memory/ и without-memory/.
Полная трасса — trace.md и result/transcript.jsonl, метрики — result/metrics.json.

MANIFEST-SHA256.json содержит путь, размер и SHA-256 каждого скопированного файла.
Содержимое каждой записи архива проверено по SHA-256 после упаковки.
