"""Сравнение памяти Анны, Бориса и Веры на исходных сценариях.

Вход: --output, settings.py и шесть исходных диалогов; выход: истории, анализы,
личная и командная память, трассы и сводные метрики. Функции: save_json — запись
состояния; execute — возобновляемый запуск команды; merge_histories — сбор баз;
summarize — таблица измерений; main — последовательность эксперимента.
Выключение ПК выполняет монитор после анализа результатов, а не этот скрипт.
"""
import argparse
from contextlib import closing
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import traceback

from command_agent_memory.runtime.agent import open_chat_database
from command_agent_memory.experiments.scenarios import load_dialogues
from command_agent_memory.experiments.dialogue import token_totals


from command_agent_memory.paths import ROOT
USERS = {"101": "Анна", "102": "Борис", "103": "Вера"}


def save_json(path: Path, value: dict) -> None:
    """Принимает путь и словарь; атомарно сохраняет JSON, возвращает None."""
    temporary = path.with_suffix(".pending")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


def execute(run: Path, state: dict, name: str, arguments: list[str]) -> None:
    """Принимает состояние, имя и CLI; выполняет незавершённый этап с журналом.

    Успешные этапы пропускаются. Сбой передаётся монитору; частичные результаты
    сохраняются и автоматически не удаляются. Возвращает None.
    """
    if name in state["completed"]:
        return
    state.pop("error", None)
    state.update(state="running", stage=name, updated_at=datetime.now(timezone.utc).isoformat())
    save_json(run / "status.json", state)
    command = [sys.executable, "-X", "utf8", "-u", *arguments]
    save_json(run / "logs" / f"{name}.command.json", {"command": command})
    with (run / "logs" / f"{name}.log").open("a", encoding="utf-8") as output:
        subprocess.run(command, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT, check=True)
    state["completed"].append(name)
    save_json(run / "status.json", state)


def merge_histories(run: Path, dialogues: list[dict]) -> None:
    """Принимает запуск и сценарии; собирает реальные baseline-сообщения по владельцу.

    Создаёт только отсутствующие базы. Не дописывает вымышленные ответы и не
    переносит результаты задач в память. Возвращает None.
    """
    for user_id in USERS:
        workspace = run / "users" / user_id
        workspace.mkdir(parents=True, exist_ok=True)
        database = workspace / "chat_logs.db"
        if database.exists():
            continue
        with closing(open_chat_database(database)) as target:
            for dialogue in dialogues:
                if dialogue["user_id"] != user_id:
                    continue
                source = run / "baseline" / dialogue["scenario"] / "no-memory/result/chat_logs.db"
                with closing(sqlite3.connect(source.as_uri() + "?mode=ro", uri=True)) as connection:
                    rows = connection.execute(
                        "SELECT session_id, created_at, role, content, message_json FROM messages ORDER BY id"
                    ).fetchall()
                target.executemany(
                    "INSERT INTO messages (session_id,user_id,created_at,role,content,message_json) "
                    "VALUES (?,?,?,?,?,?)",
                    [(session, user_id, created, role, content, message) for session, created, role, content, message in rows],
                )
            target.commit()


def summarize(run: Path, dialogues: list[dict]) -> None:
    """Принимает запуск и сценарии; сохраняет метрики обеих ролей и флаги ухудшения.

    Рост токенов или времени — повод прочитать логи, а не автоматический вывод
    о качестве. Построение памяти учитывается отдельно. Возвращает None.
    """
    rows = []
    warnings = []
    lines = ["# Сравнение с памятью и без памяти", "",
             "Повтор знакомых задач; проверка переноса на новые данные не выполнялась.", "",
             "| Сценарий | Память | Исход | Реплики | Роль | Время, с | Вызовы модели | Инструменты | Вход | Кеш | Новый вход | Выход | Полный учёт |",
             "|---|---|---|---:|---|---:|---:|---:|---:|---:|---:|---:|---|"]
    for dialogue in dialogues:
        pair = {}
        scenario = dialogue["scenario"]
        for variant, folder in (("no-memory", "baseline"), ("full", "replay")):
            path = run / folder / scenario / variant / "result/metrics.json"
            if not path.is_file():
                continue
            metrics = json.loads(path.read_text(encoding="utf-8"))
            pair[variant] = metrics
            for role in ("tested_agent", "tester"):
                item = metrics.get(role) or {}
                inputs, cached, outputs = token_totals(item)
                row = {"scenario": scenario, "user_id": dialogue["user_id"], "variant": variant,
                       "state": metrics["state"], "user_turns": metrics["user_turns"], "role": role,
                       "input_tokens": inputs, "cached_tokens": cached, "new_input_tokens": inputs - cached,
                       "output_tokens": outputs, **item}
                rows.append(row)
                lines.append(f"| {scenario} | {variant} | {metrics['state']} | {metrics['user_turns']} | {role} | "
                             f"{item.get('duration_seconds', 0):.1f} | {item.get('model_calls')} | {item.get('tool_calls')} | "
                             f"{inputs} | {cached} | {inputs-cached} | {outputs} | {item.get('usage_complete')} |")
        if "full" in pair:
            baseline, candidate = pair.get("no-memory", {}), pair["full"]
            if candidate["state"] != "completed":
                warnings.append(f"{scenario}: память — {candidate['state']}")
            before_input, _, before_output = token_totals(baseline.get("tested_agent") or {})
            after_input, _, after_output = token_totals(candidate.get("tested_agent") or {})
            before, after = before_input + before_output, after_input + after_output
            if before and after > before:
                warnings.append(f"{scenario}: вырос объём токенов; требуется проверка причин и качества")
    save_json(run / "metrics.json", {"rows": rows, "review_required": warnings})
    lines.extend(["", "## Проверка по логам", "", *(warnings or ["Сводные флаги ухудшения отсутствуют; правильность проверяется по результатам."]),
                  "", "Затраты построения памяти: analysis/, personal/ и team/; они не включены в replay."])
    (run / "metrics.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main(argv: list[str] | None = None) -> None:
    """Принимает CLI; возобновляет baseline, анализ, память, replay и объединение.

    Выход — status.json со state=awaiting_review либо needs_attention и все
    промежуточные артефакты. Ошибки не маскируются успешным завершением.
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    run = args.output.resolve()
    if not run.is_relative_to(ROOT / "data"):
        parser.error("Результаты должны находиться в data/ проекта.")
    run.mkdir(parents=True, exist_ok=True)
    for folder in ("logs", "scenarios", "reference"):
        (run / folder).mkdir(exist_ok=True)
    from command_agent_memory.configuration import read_local_settings

    model = os.environ.get("OPENROUTER_MODEL") or read_local_settings().get("model", "")
    if not model:
        raise ValueError("Задай OPENROUTER_MODEL или model в config/settings.py.")

    state_path = run / "status.json"
    state = json.loads(state_path.read_text(encoding="utf-8")) if state_path.exists() else {
        "state": "preparing", "model": model, "completed": [], "personal_runs": {},
        "shutdown_authorized": True, "monitor_interval_minutes": 6,
    }
    dialogues = [item for item in load_dialogues(ROOT) if item["user_id"] in USERS]
    shutil.copy2(ROOT / "docs/examples/synthetic-team/expected-results.md", run / "reference/answer.md")
    for dialogue in dialogues:
        save_json(run / "scenarios" / f"{dialogue['scenario']}.json", {
            "dialogue_source": str(ROOT / "docs/examples/synthetic-team/chats" / dialogue["source"]),
            "inputs": str(ROOT / "user_workspace/synthetic_team"), "reference": str(run / "reference"),
            "goal": "Выполнить все требования исходных реплик этого сценария, сохранить требуемые артефакты и проверить правильность по относящейся к нему части эталона.",
        })
    from command_agent_memory.evaluation.replay import load_replay_scenario

    for dialogue in dialogues:
        load_replay_scenario(run / "scenarios" / f"{dialogue['scenario']}.json")
    save_json(state_path, state)
    try:
        for dialogue in dialogues:
            scenario = dialogue["scenario"]
            execute(run, state, f"baseline-{scenario}", ["-m", "command_agent_memory", "replay", "--scenario",
                    str(run / "scenarios" / f"{scenario}.json"), "--model", state["model"],
                    "--variant", "no-memory", "--output", str(run / "baseline" / scenario)])
            summarize(run, dialogues)
        merge_histories(run, dialogues)
        for user_id in USERS:
            execute(run, state, f"analysis-{user_id}", ["-m", "command_agent_memory", "analyze", "--backend", "openrouter", "--user-id", user_id,
                    "--workspace", str(run / "users" / user_id), "--output-dir", str(run / "analysis" / user_id),
                    "--model", state["model"], "--resume"])
        for user_id in USERS:
            code = ("from pathlib import Path; from command_agent_memory.memory.cli import main; "
                    f"result=main({['--backend','openrouter','--stage','personal','--user-id',user_id,'--workspace',str(run/'users'/user_id),'--reports-dir',str(run/'analysis'/user_id),'--model',state['model']]!r}); "
                    f"Path({str(run / f'personal-{user_id}.txt')!r}).write_text(str(result/'personal'),encoding='utf-8')")
            execute(run, state, f"personal-{user_id}", ["-c", code])
            personal_run = Path((run / f"personal-{user_id}.txt").read_text(encoding="utf-8"))
            metadata = json.loads((personal_run / "status.json").read_text(encoding="utf-8"))
            if metadata["state"] not in ("published", "unchanged"):
                raise RuntimeError(f"Личная память {user_id} не принята: {metadata['state']}")
            state["personal_runs"][user_id] = str(personal_run)
            save_json(state_path, state)
        for dialogue in dialogues:
            scenario = dialogue["scenario"]
            memory_source = Path(state.get("memory_overrides", {}).get(
                scenario, str(run / "users" / dialogue["user_id"])))
            execute(run, state, f"replay-{scenario}", ["-m", "command_agent_memory", "replay", "--scenario",
                    str(run / "scenarios" / f"{scenario}.json"), "--model", state["model"], "--variant", "full",
                    "--memory-source", str(memory_source), "--output", str(run / "replay" / scenario)])
            summarize(run, dialogues)
        arguments = ["--backend", "openrouter", "--stage", "knowledge", "--model", state["model"]]
        for personal_run in state["personal_runs"].values():
            arguments.extend(["--accepted-run", personal_run])
        code = "from command_agent_memory.memory.cli import main; main(" + repr(arguments) + ")"
        execute(run, state, "team", ["-c", code])
        state.update(state="awaiting_review", stage="review-metrics-and-quality")
    except BaseException as error:
        state.update(state="needs_attention", error=f"{type(error).__name__}: {error}")
        (run / "error.txt").write_text(traceback.format_exc(), encoding="utf-8")
        raise
    finally:
        summarize(run, dialogues)
        save_json(state_path, state)


if __name__ == "__main__":
    main()
