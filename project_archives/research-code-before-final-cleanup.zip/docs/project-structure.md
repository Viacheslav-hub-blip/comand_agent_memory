# Структура проекта

Актуальные схема исполнения, контракты и ограничения описаны в
[архитектуре](architecture.md), [README](../README.md) и
[руководстве по расширению](extending.md).

```text
command_agent_memory/
  adapters/           # Контракт модели, Codex CLI, OpenRouter, реестр
  analysis/           # Чтение входов, анализ сессий, версии отчётов
  sources/            # SQL DB-API и утилиты Codex
  history.py          # Общий формат событий и адаптеры источников
  configuration.py    # Модели этапов и общие пожелания
  connections.py      # Переносимый цикл по JSON-конфигурации
  memory/
    store.py          # MemoryLayout и FileMemoryStore
    backends.py       # MemoryStore и регистрация хранилищ
    sqlite.py         # Транзакционное хранилище документов
    personal.py       # Копия → консолидация → review → принятие
    team.py           # Принятые знания → командная память
    cli.py            # Прежние команды personal / knowledge / both
  evaluation/         # Сценарии, диалог, сравнение и исполнители replay
  runtime/            # Необязательный DeepAgents и файловые инструменты
  runs/               # Каталоги запусков и отчёты этапов
  synthetic/          # Синтетические сценарии
  paths.py            # Поиск инструкций в checkout и wheel
  pipeline.py         # CLI с режимами config и legacy
  __main__.py         # python -m command_agent_memory
agents/               # Единственный исходник инструкций; копируется в wheel
```

Корневые исполняемые команды сохранены. Общие реализации `agent_runtime`,
`codex_client`, `openrouter_client`, `codex_history`, `codex_replay_adapter`,
`memory_pipeline`, `robust_local_shell`, `replay_worker`, `replay_codex` и
`run_reports` перенесены в пакет; прежние модули ссылаются на эти реализации.

`knowledge/` содержит знания проекта, `docs/` — описание и примеры,
`tests/` — локальные проверки, а `data/`, `tmp/`, `build/`, `dist/` —
неотслеживаемые данные и результаты. Локальные секреты не входят в пакет.

Учёт независимых подтверждений, pending и conflicts остаётся отложенным.
Рефакторинг не вводит новый жизненный цикл принятия памяти.
